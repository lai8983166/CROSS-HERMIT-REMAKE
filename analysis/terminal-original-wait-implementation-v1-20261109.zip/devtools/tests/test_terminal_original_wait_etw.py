import ctypes as C
from pathlib import Path
import unittest
from unittest.mock import patch

from devtools import terminal_original_wait_etw as probe


class OriginalWaitCollectorTests(unittest.TestCase):
    def test_host_rejected_before_kernel_API_or_output(self):
        with patch('devtools.native_input_isolation.require_qualified_guest',side_effect=ValueError('not guest')):
            with patch.object(probe,'kernel_wait_identity',side_effect=AssertionError('native must not run')):
                with self.assertRaisesRegex(ValueError,'not guest'):
                    probe.run(Path('not-created.json.gz'))
            with self.assertRaisesRegex(ValueError,'not guest'):
                probe.kernel_wait_identity()

    def test_kernel_path_is_exact_not_generic_driver(self):
        self.assertEqual(probe.kernel_path(r'\SystemRoot\system32\ntoskrnl.exe','C:/Windows'),
                         Path('C:/Windows/System32/ntoskrnl.exe').resolve())
        for value in ('C:/other/ntoskrnl.exe','C:/Windows/System32/drivers/other.sys',
                      r'\SystemRoot\..\other\ntoskrnl.exe'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                probe.kernel_path(value,'C:/Windows')

    def test_clock_uses_precise_FILETIME_without_offset_guess(self):
        class Kernel:
            @staticmethod
            def GetSystemTimePreciseAsFileTime(p):
                C.cast(p,C.POINTER(C.c_uint64)).contents.value=116444736012345678
        self.assertEqual(probe.utc_now_ns(Kernel()),1234567800)

    def test_trace_keeps_thread_syscall_switch_and_original_loss_limits(self):
        buf, p = probe.trace_properties(Path('C:/owned/trace.etl'))
        self.assertEqual(p.EnableFlags,0x92)
        self.assertEqual((p.MaximumFileSize,p.MinimumBuffers,p.MaximumBuffers),(4,4,8))
        self.assertEqual(p.Wnode.ClientContext,1)

    def test_raw_stack_ranges_preserve_links_and_original_wait_parameters(self):
        reads=[]
        class Reader:
            @staticmethod
            def get(p,n):
                reads.append((p,n));return bytes(n)
        frame=dict(ESP=0x1000,chain=[dict(bp=0x1100,saved_bp=0x1200,return_va=0x42240D),
                                  dict(bp=0x1200,saved_bp=0x1300,return_va=0x45E9D0)])
        rows=probe.stack_regions(Reader(),frame)
        self.assertIn((0x1100,16),reads)
        self.assertIn((0x11A0,0x70),reads)
        self.assertIn((0x1200,8),reads)
        self.assertEqual(sum(len(bytes.fromhex(r['hex']))for r in rows),sum(n for p,n in reads))


if __name__=='__main__':unittest.main()
