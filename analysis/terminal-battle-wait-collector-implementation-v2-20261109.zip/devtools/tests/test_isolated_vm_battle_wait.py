import copy
import unittest
from devtools import isolated_vm_battle_wait as host


class BattleWindowGateTests(unittest.TestCase):
    def setUp(self):
        self.proof=dict(long_capture_preflight_passed=True,errors=[],accepted=False)
        self.window=dict(bytes=10,sha256='a'*64)
        self.source=dict(phase='startup_preflight',error=None,input_isolation=dict(current_guest_uuid='abc',
            current_guest_boot_utc='2026-11-09T00:00:00Z',current_guest_resources=dict(logical_processors=2,memory_bytes=4*1024**3)),
            window_implementations=[dict(self.window,path='C:/ChaomofaWorker/project/devtools/terminal_battle_wait_window.py')])
        self.current=dict(uuid='ABC',boot='2026-11-09T00:00:00Z',cpu=2,memory=4*1024**3)

    def test_only_explicit_capability_allows_next_bounded_capture(self):
        host.preflight_gate(self.proof,self.source,self.current,self.window)
        for change in ({'long_capture_preflight_passed':False},{'errors':['missing wait']},{'accepted':True}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                host.preflight_gate(dict(self.proof,**change),self.source,self.current,self.window)

    def test_old_boot_wrong_machine_or_resources_cannot_reuse_preflight(self):
        for change in ({'boot':'another'},{'uuid':'wrong'},{'cpu':4},{'memory':8*1024**3}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                host.preflight_gate(self.proof,self.source,dict(self.current,**change),self.window)

    def test_changed_collector_or_non_preflight_source_rejected(self):
        with self.assertRaises(ValueError):host.preflight_gate(self.proof,self.source,self.current,dict(self.window,sha256='b'*64))
        with self.assertRaises(ValueError):host.preflight_gate(self.proof,dict(self.source,phase='battle_retreat'),self.current,self.window)


if __name__=='__main__':unittest.main()
