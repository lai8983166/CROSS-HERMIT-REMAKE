import hashlib,json,zipfile
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
names=['preflight-result-tail-v1.py','run-result-tail-v1.py','check-result-tail-guest-v1.py','check-result-tail-guest-v2.py',
       'prepare-result-tail-tests-v2.py','review-result-tail-main-v1.py','prepare-result-tail-retirement-v1.py',
       'retire-result-tail-transfers-v1.py','inventory-result-tail-guest-v1.py','check-result-tail-preservation-v1.py',
       'closeout-result-tail-v1.py','package-result-tail-v1.py','result-tail-headless-preflight-v1-20261109.json',
       'terminal-result-tail-v1-20261109.run.json','result-tail-unit-checks-v2-20261109.json','result-tail-preservation-v1-20261109.json',
       'result-tail-transfer-retirement-v1-20261109.json','battle-wait-guest-storage-result-tail-v1-20261109.json']
rows=[];out=R/'analysis/terminal-result-tail-support-v1-20261109.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n in names:
        p=W/n;b=p.read_bytes();z.writestr(n,b);rows.append(dict(member=n,path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    z.writestr('manifest.json',json.dumps(dict(scope='current small reproduction helpers and receipts only; original source/image/DLL reused via fixed references',files=rows),indent=2))
print(json.dumps(dict(path=out.relative_to(R).as_posix(),bytes=out.stat().st_size,members=len(rows)+1)))
