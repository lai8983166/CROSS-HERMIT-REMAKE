import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('F:/project/chaomofa');WORKER=ROOT/'.venv-audit/native-worker'
parent=ROOT/'analysis/reverse-validation-preservation-v1-20261106.json'
data=json.loads(parent.read_text());bad=[]
small=data['small_frozen_fresh_SHA'];large=data.get('large_size_only',data.get('large_frozen_size_only',[]))
if len(small)!=832 or len(large)!=13:raise ValueError('frozen preservation categories changed')
for row in small:
 p=ROOT/row['path']
 if not p.exists()or p.stat().st_size!=row['bytes']or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:bad.append(row['path'])
for row in large:
 p=ROOT/row['path']
 if not p.exists()or p.stat().st_size!=row['bytes']:bad.append(row['path'])
r=dict(checked_utc=datetime.now(timezone.utc).isoformat(),parent=dict(path=parent.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(parent.read_bytes()).hexdigest()),small_fresh_SHA_count=len(small),large_size_only_count=len(large),large_fresh_SHA=False,mismatches=bad)
with (WORKER/'result-tail-preservation-v1-20261109.json').open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r));
if bad:raise SystemExit(1)
