"""Close one conditional result-propagation increment; no formal gate passed."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_bytes())
if list(W.rglob('*.vmem')):raise ValueError('VM memory file remains')
parent=R/'analysis/terminal-battle-wait-context-heap-closeout-v1-20261109.json';prior=read(parent)
proof=R/'analysis/terminal-result-tail-proof-v1-20261109.json';p=read(proof)
review=R/'analysis/terminal-result-tail-independent-review-v1-20261109.json'
need_review=read(review)
if not need_review['passed']or p['accepted']or not p['second_fresh_Unicorn_exact_match']:raise ValueError('finite result and independent review required')
tests_path=W/'result-tail-unit-checks-v2-20261109.json';tests=read(tests_path)
if len(tests)!=2 or any(x['returncode']or 'Ran 8 tests'not in x['output']for x in tests):raise ValueError('ordinary and optimized guest regressions required')
guest_path=W/'battle-wait-guest-storage-result-tail-v1-20261109.json';guest=read(guest_path)
cleanup_path=W/'result-tail-transfer-retirement-v1-20261109.json';cleanup=read(cleanup_path)
if guest['game_and_python_processes']or not cleanup['all_removed']:raise ValueError('guest idle and duplicate cleanup required')
for row in cleanup['removed']:
    if row['guest']in{x['path'].replace('\\','/')for x in guest['files']}:raise ValueError('retired duplicate remains')
paths=[x for x in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=A','-z'],cwd=R).decode().split('\0')if x]
analysis=[ident(R/p)for p in paths if p.startswith('analysis/')]
files=[];environment=[];worker_bytes=0
for f in W.rglob('*'):
    if not f.is_file():continue
    st=f.stat();worker_bytes+=st.st_size
    if st.st_mtime<1794232439:continue
    if f.suffix.lower()in{'.vmdk','.vmem','.vmx','.vmxf','.nvram','.vmsd','.vmss','.lck'}or f.name.startswith('vmware'):
        environment.append(dict(path=f.relative_to(R).as_posix(),bytes=st.st_size));continue
    if 'credentials'in f.name.lower()or '.private.'in f.name.lower():continue
    if st.st_size>256*1024*1024:raise ValueError('unexpected large evidence')
    files.append(ident(f))
disk=sum(f.stat().st_size for f in W.glob('*.vmdk'))
report=dict(kind='three_gate_plan_and_conditional_original_result_tail_increment',created_utc=datetime.now(timezone.utc).isoformat(),parent=ident(parent),
    accepted=False,formal_tasks_completed=2,formal_tasks_total=8,formal_gates_passed=0,formal_gates_total=3,
    gate_status=dict(A='conditional third-wait tail executed; native continuity/first consumer/three handshakes unproved',B='original resource and PTD lifetime unproved',C='two fresh complete native cases not started'),
    existing_acceptance_contract_unchanged=True,fullABI=False,fullstate=False,PTDcleanup=False,
    continuous_native_result_consumption_proved=False,two_fresh_full_native_cases_verified=False,
    functional_progress=dict(original_pending_EIP='77D13BFC',original_pending_EAX=0,no_return_value_substitution=True,
        original_result_creation='453CDD MOV EAX,1',natural_original_consumers=['451ABC -> 027FFE60 = 1','451716 -> 027FFED4 = 1'],
        original_wait_node_flag_cleared=True,instruction_callbacks_per_instance=118,original_writes_per_instance=36,
        same_implementation_fresh_Unicorn_instances=2,full_independent_replay=False,
        stop_before_instruction='451723 MOV ECX,[7A49FC]',missing_global_not_read=True,old_native_handles_called=False),
    limitations=p['limitations']+['Source SS=2B is not restored; explicit synthetic flat SS=18 is a conditional platform input.',
        'Original 453CB5, 4967B0 and three complete handshakes were not executed. Original result-tail writes do not certify the actual post-kernel ABI.'],
    references=[ident(proof),ident(review),ident(W/'terminal-result-tail-v1-20261109.run.json'),ident(W/'result-tail-headless-preflight-v1-20261109.json')],
    efficiency=dict(original_game_launches=0,new_full_battle_prefixes=0,new_native_game_captures=0,formal_long_replays=0,
        existing_battle_v6_source_and_prior_wait_proof_reused=True,first_guest_tail_attempt_succeeded=True,
        regression_transport_first_attempt='missing guest devtools/tests directory before tests; create directory, use new v2 outputs; no collector or source rerun',
        no_claim_of_complete_path_speedup=True),
    tests=dict(receipt=ident(tests_path),ordinary_count=8,optimized_count=8,executed_inside_VM=True,ordinary_seconds=tests[0]['elapsed'],optimized_seconds=tests[1]['elapsed'],passed=True),
    preservation=read(W/'result-tail-preservation-v1-20261109.json'),strict_OpenSpec_valid=True,
    host_evidence_files=files,analysis_evidence_files_before_closeout=analysis,
    guest_inventory=ident(guest_path),guest_retained_files=guest['files'],
    cleanup=dict(receipt=ident(cleanup_path),guest_duplicate_files_removed=len(cleanup['removed']),guest_duplicate_bytes_removed=cleanup['total_bytes'],
        all_current_planned_transfers_removed=True,host_originals_retained=True,historical_assets_sources_or_checkpoints_removed=False,
        previous_kernel_duplicate_retained_bytes=11597168,previous_kernel_deletion_not_retried=True),
    environment=dict(host_drive='F',guest_logical_C_inside_F_disk=True,cpu=2,memory_bytes=guest['memory'],VM_soft_stopped=True,VMEM_files_remaining=0,
        original_game_started=False,interactive_desktop_or_autologon_used=False,host_input_actions=0,continuous_host_performance_unaffected_proved=False,
        VM_disk_bytes=disk,baseline_VM_disk_bytes=prior['environment']['VM_disk_bytes'],VM_disk_growth_bytes=disk-prior['environment']['VM_disk_bytes'],
        baseline_worker_logical_bytes=prior['environment']['worker_logical_bytes_at_inventory'],worker_logical_bytes_at_inventory=worker_bytes,mutable_environment_files=environment),
    storage_scope='Logical evidence since parent commit 2026-11-09T13:53:59Z, including all new helpers/reports/receipts/capsule and retained guest code copies. Parent source files reused without host duplication. VM disk growth is separate; repository implementation counted in Git.',
    same_disk_backup_is_independent_disaster_recovery=False,staged_code_and_evidence_equal_executed_bytes=True,private_credential_scan_passed=True,
    host_new_evidence_bytes_including_closeout=0,total_new_local_evidence_bytes_including_guest_and_backups=0,Git_added_file_bytes_including_closeout=0,closeout_bytes=0)
base=sum(x['bytes']for x in files+analysis);git_base=sum((R/x).stat().st_size for x in paths)
for _ in range(12):
    report['host_new_evidence_bytes_including_closeout']=base+report['closeout_bytes']
    report['total_new_local_evidence_bytes_including_guest_and_backups']=base+report['closeout_bytes']+guest['remaining_current_round_guest_files_bytes']
    report['Git_added_file_bytes_including_closeout']=git_base+report['closeout_bytes']
    raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
    if len(raw)==report['closeout_bytes']:break
    report['closeout_bytes']=len(raw)
else:raise ValueError('manifest size')
if report['total_new_local_evidence_bytes_including_guest_and_backups']>256*1024*1024:raise ValueError('evidence budget')
out=R/'analysis/terminal-result-tail-closeout-v1-20261109.json'
with out.open('xb')as f:f.write(raw)
print(json.dumps(dict(report=ident(out),local_evidence_bytes=report['total_new_local_evidence_bytes_including_guest_and_backups'],Git_added_file_bytes=report['Git_added_file_bytes_including_closeout'],VM_disk_growth_bytes=report['environment']['VM_disk_growth_bytes'])))
