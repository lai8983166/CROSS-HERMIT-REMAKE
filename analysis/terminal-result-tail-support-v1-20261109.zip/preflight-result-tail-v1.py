import json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_windows_vm import WORKER,identity
script=r"""$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'});if($p.Count){throw 'guest busy'};
if($m.NumberOfLogicalProcessors -ne 2 -or $m.TotalPhysicalMemory -lt 4000000000 -or $m.TotalPhysicalMemory -gt 4500000000){throw 'wrong bounded resources'};
$env:TEMP='C:\ChaomofaWorker\temp';$env:TMP=$env:TEMP;
& C:\ChaomofaWorker\Python\python.exe -B -c 'import unicorn,capstone,pefile,json; print(json.dumps(dict(unicorn=unicorn.__version__,capstone=capstone.__version__,pefile=pefile.__version__)))';if($LASTEXITCODE -ne 0){throw 'offline replay dependencies unavailable'};
"""
versions=json.loads(run_script(script));state=json.loads(run_script(STATUS))
out=WORKER/'result-tail-headless-preflight-v1-20261109.json'
r=dict(kind='headless_offline_original_instruction_replay_preflight',versions=versions,guest=state,
       accepted=False,graphical_or_input_preflight=False,original_game_started=False,host_input_actions=0,
       scope='Authenticated F-drive VM; no UI/session login or game input is needed for bounded offline instruction execution.',
       implementation=identity(Path(__file__)))
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(dict(report=identity(out),versions=versions,cpu=state['cpu'],memory=state['memory'],explorer=state['explorer'],accepted=False)))
