from pathlib import Path
w=Path('F:/project/chaomofa/.venv-audit/native-worker')
source=(w/'check-result-tail-guest-v1.py').read_text()
source=source.replace('result-tail-unit-checks-v1-20261109','result-tail-unit-checks-v2-20261109')
source=source.replace("vmrun(['CopyFileFromHostToGuest',VMX,test,", "run_script(\"New-Item -ItemType Directory -Path C:\\\\ChaomofaWorker\\\\project\\\\devtools\\\\tests -Force|Out-Null;'ready'\")\nvmrun(['CopyFileFromHostToGuest',VMX,test,")
with (w/'check-result-tail-guest-v2.py').open('x',encoding='utf8')as f:f.write(source)
