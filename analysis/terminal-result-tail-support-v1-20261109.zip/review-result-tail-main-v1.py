"""Independent main-agent check of raw result propagation and scope boundaries."""
import gzip,hashlib,json,struct
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def word(b,n=0):return struct.unpack_from('<I',b,n)[0]
path=W/'terminal-result-tail-v1-20261109.json';p=json.loads(path.read_bytes());r=p['result']
window_path=W/'terminal-battle-wait-window-battle-v6-20261109.json.gz'
need(ident(window_path)['sha256']=='9874fb2e589aafb1b3190c9a2a5aac7c7ee0e0a3179923cd10d463bee3fd680e','fixed original source')
s=json.loads(gzip.decompress(window_path.read_bytes()));snap=s['window_snapshots'][15];context=bytes.fromhex(snap['frame']['context_hex'])
image_path=R/'analysis/hermit_game.exe';image=image_path.read_bytes()
need(ident(image_path)['sha256']=='588b4288e4c737dc489d2b9bc0652cca85e3d668b1784942ef4b4bda916f1005','original image')
need(r['initial_integer_CPU']['EAX']==word(context,176)==0 and r['initial_integer_CPU']['EIP']==word(context,184)==0x77D13BFC,'no substituted pending integer return')
need(r['final_integer_CPU']['EAX']==1 and r['final_integer_CPU']['EIP']==0x451723,'natural bounded tail endpoint')
code=[x['PC']for x in r['instructions']]
for row in r['instructions']:
    if 0x400000<=row['PC']<0x592000:
        raw=bytes.fromhex(row['hex']);need(raw==image[row['PC']-0x400000:row['PC']-0x400000+len(raw)],'original game instruction bytes')
need(code.index(0x453CDD)<code.index(0x451ABC)<code.index(0x451716)and code[-1]==0x45171F,'result creation and consumers execute in original order')
need(image[0x53CDD:0x53CE2]==bytes.fromhex('b801000000'),'original MOV EAX,1 source')
need(0x453CB5 not in code and not any(0x4967B0<=x<0x4968A9 for x in code),'first consumer and recording branch not executed')
stack={}
for region in snap['stack_regions']:
    for a,b in enumerate(bytes.fromhex(region['hex']),region['pointer']):
        need(a not in stack or stack[a]==b,'actual overlapping original stack bytes');stack[a]=b
expected=[]
for pc,ret,offset in ((0x451ABC,0x451716,8),(0x451716,0x421F8A,12)):
    frame=next(f for f in snap['frame']['chain']if f['return_va']==ret);address=frame['bp']-offset
    before=bytes(stack[a]for a in range(address,address+4)).hex()
    match=[x for x in r['writes']if x['PC']==pc and x['address']==address]
    need(len(match)==1 and match[0]['before_hex']==before and match[0]['after_hex']=='01000000','actual saved-frame local is written by original consumer')
    expected.append(match[0])
need(r['original_result_consumer_writes']==expected,'complete consumer write report')
returns={(x['PC'],x['target'])for x in r['natural_returns']}
need({(0x77D13BFC,0x77B68229),(0x422431,0x453CDD),(0x453CFB,0x451ABC),(0x451B0E,0x451716)}<=returns,'natural original stack return chain')
flags=next(x for x in r['writes']if x['PC']==0x4225CE)
need(flags['address']==s['subject']['node']+4 and word(bytes.fromhex(flags['before_hex']))==0x10001 and flags['after_hex']=='01000000','original wait flag clearing')
front=r['frontier'];need(front['PC']==0x451723 and front['address']==0x7A49FC and front['instruction_executed']is False and r['write_count']==front['writes_before']==36,'missing GAME global stops before execution')
for key in ('accepted','fullABI','fullstate','original_native_continuity','independent_full_replay','original_wait_completed_proved',
            'continuous_native_result_consumption_proved','wrapper_live_code_authenticated','pending_context_is_actual_post_syscall_context',
            'first_result_consumer_453CB5_executed','replay_record_4967B0_executed','three_handshakes_executed'):
    need(p[key]is False,'required non-acceptance boundary '+key)
need(p['second_fresh_Unicorn_exact_match']and r['segment_platform_inputs']['effective_selectors']['SS']==0x18 and r['segment_platform_inputs']['original_selectors']['SS']==0x2B,'finite repeatability and disclosed SS model mismatch')
run=W/'terminal-result-tail-v1-20261109.run.json';receipt=json.loads(run.read_bytes())
need(receipt['errors']==[]and receipt['implementation_unchanged']and receipt['sources_unchanged']and receipt['headless']and receipt['host_input_actions']==0,'guest execution receipt')
target=R/'analysis/terminal-result-tail-proof-v1-20261109.json'
with target.open('xb')as f:f.write(path.read_bytes())
report=dict(kind='independent_main_review_of_conditional_original_result_tail',passed=True,accepted=False,
    references=[ident(target),ident(window_path),ident(run),ident(R/'devtools/terminal_result_tail_replay.py')],
    independently_checked_original_consumer_writes=expected,original_wait_flag_write=flags,
    callback_count=118,writes=36,first_missing_read=front,
    no_live_or_full_ABI_acceptance=True,three_complete_gates_passed=0,legacy_formal_tasks_completed=2,
    code_review='Sparse source bytes only; original integer registers copied once, no substituted EAX/result/call stack. Operand guards stop unknown reads before executing; RX source pages and known writable spans. Synthetic flat SS differs from native source and remains explicitly unproved. Two executions use the same implementation and are not independent full replay.',
    next_dependencies=['Actual post-wait CPU/ABI and contemporaneous memory remain unproved.',
        'Current snapshot lacks raw GAME pointer at 7A49FC; ready/other-action pointer cannot silently replace this instant.',
        '415420 resets GAME+B1E8/B1EC/B1F4 then 415530 reads GAME+B1D0 and timer fields B188/B18C before real clock API; no disk defaults or prior clock values may fill these reads.'],
    limits='Only the conditional tail after the third wait reaches outer callback result propagation. 453CB5, 4967B0, three handshakes, full memory/segments, actual resources/PTD and original native continuation remain unproved.')
out=R/'analysis/terminal-result-tail-independent-review-v1-20261109.json'
with out.open('x',encoding='utf8')as f:json.dump(report,f,indent=2)
print(json.dumps(dict(review=ident(out),proof=ident(target),original_consumer_writes=expected,accepted=False)))
