"""Bounded real-input regressions on the dedicated guest, ordinary and -O."""
import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script
guest=PureWindowsPath('C:/ChaomofaWorker/project');folder=guest/'analysis'/'result-tail-inputs-v1-20261109'
test=R/'devtools/tests/test_terminal_result_tail_replay.py';before=identity(test)
out=WORKER/'result-tail-unit-checks-v1-20261109.json';driver=WORKER/'result-tail-unit-checks-v1-20261109-driver.py'
remote_driver=PureWindowsPath('C:/ChaomofaWorker')/driver.name;remote=guest/'analysis'/out.name
if out.exists()or driver.exists():raise ValueError('fresh regression receipt')
if run_script("$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -like 'python*' -or $_.Name -eq 'CROSS HERMIT.EXE'});if($p.Count){throw 'busy'};'idle'").strip()!='idle':raise ValueError('guest busy')
env=dict(TAIL_REPLAY_TEST_WINDOW=str(folder/'terminal-battle-wait-window-battle-v6-20261109.json.gz'),
         TAIL_REPLAY_TEST_PROOF=str(folder/'terminal-battle-wait-diagnostic-v1-20261109.json'),
         TAIL_REPLAY_TEST_IMAGE=str(guest/'analysis/hermit_game.exe'),TAIL_REPLAY_TEST_DLL=r'C:\Windows\SysWOW64\KERNELBASE.dll',
         TEMP='C:/ChaomofaWorker/temp',TMP='C:/ChaomofaWorker/temp')
script='import os,sys,json,subprocess,time\nos.chdir('+repr(str(guest))+');os.environ.update('+repr(env)+')\nrows=[]\n'
script+='for optimized in (False,True):\n start=time.monotonic()\n cmd=[sys.executable,"-B"]+(["-O"]if optimized else [])+["-X","utf8","-m","unittest","devtools.tests.test_terminal_result_tail_replay"]\n r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)\n rows.append(dict(optimized=optimized,returncode=r.returncode,elapsed=time.monotonic()-start,output=r.stdout+r.stderr))\n if r.returncode:break\n'
script+='with open('+repr(str(remote))+',"x",encoding="utf8")as f:json.dump(rows,f,indent=2)\nif len(rows)!=2 or any(r["returncode"]for r in rows):raise SystemExit(1)\n'
with driver.open('x',encoding='utf8')as f:f.write(script)
vmrun(['CopyFileFromHostToGuest',VMX,test,guest/'devtools/tests'/test.name],guest=True)
vmrun(['CopyFileFromHostToGuest',VMX,driver,remote_driver],guest=True)
try:
    run_script("& C:\\ChaomofaWorker\\Python\\python.exe -B '"+str(remote_driver)+"';if($LASTEXITCODE -ne 0){throw 'tail regressions failed'};'done'")
finally:vmrun(['CopyFileFromGuestToHost',VMX,remote,out],guest=True)
rows=json.loads(out.read_bytes())
if before!=identity(test)or len(rows)!=2 or any(r['returncode']or 'Ran 8 tests'not in r['output']for r in rows):raise ValueError('complete immutable regressions')
print(json.dumps(dict(report=identity(out),test_implementation=before,ordinary=8,optimized=8,seconds=[r['elapsed']for r in rows])))
