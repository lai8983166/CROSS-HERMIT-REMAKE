"""Run the finite original-instruction tail only in the dedicated headless VM."""
import argparse,json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import ROOT,WORKER,VMX,identity,vmrun
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_vm_original_wait_decode import restore_guest_artifact,transferred

def run(label):
    if not label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-'for c in label):raise ValueError('new simple label')
    stem='terminal-result-tail-'+label
    out=WORKER/(stem+'.json');receipt=WORKER/(stem+'.run.json');driver=WORKER/(stem+'-driver.py');log=WORKER/(stem+'.log')
    if any(p.exists()for p in (out,receipt,driver,log)):raise ValueError('fresh immutable outputs')
    idle="$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'});if($p.Count){throw 'guest busy'};'idle'"
    if run_script(idle).strip()!='idle':raise ValueError('guest busy')
    state=json.loads(run_script(STATUS));pre=json.loads((WORKER/'result-tail-headless-preflight-v1-20261109.json').read_bytes())
    if state!=pre['guest']:raise ValueError('headless preflight current boot/resources/session changed')
    guest=PureWindowsPath('C:/ChaomofaWorker/project');folder=guest/'analysis'/'result-tail-inputs-v1-20261109'
    sources=[WORKER/'terminal-battle-wait-window-battle-v6-20261109.json.gz',ROOT/'analysis/terminal-battle-wait-diagnostic-v1-20261109.json']
    inputs=[restore_guest_artifact(p,folder/p.name,identity(p))for p in sources]
    source_ids=[identity(p)for p in sources]
    module=ROOT/'devtools/terminal_result_tail_replay.py';before=identity(module)
    remote=guest/'analysis'/out.name;remote_driver=PureWindowsPath('C:/ChaomofaWorker')/driver.name;remote_log=remote_driver.parent/log.name
    args=['devtools.terminal_result_tail_replay','--window',str(folder/sources[0].name),'--diagnostic-proof',str(folder/sources[1].name),
          '--image',str(guest/'analysis/hermit_game.exe'),'--guest-dll',r'C:\Windows\SysWOW64\KERNELBASE.dll','--out',str(remote)]
    script=('import os,sys,runpy,traceback\nos.environ["TEMP"]=os.environ["TMP"]="C:/ChaomofaWorker/temp"\nos.chdir('+repr(str(guest))+');sys.path.insert(0,'+repr(str(guest))+')\n'
        'sys.argv='+repr(args)+'\nwith open('+repr(str(remote_log))+',"x",encoding="utf8")as f:\n'
        ' sys.stdout=sys.stderr=f\n try:runpy.run_module(sys.argv[0],run_name="__main__")\n'
        ' except SystemExit as exc:\n  print("diagnostic_exit",exc.code)\n  if exc.code!=2:raise\n'
        ' except BaseException:traceback.print_exc();raise\n')
    with driver.open('x',encoding='utf8')as f:f.write(script)
    result=dict(accepted=False,original_game_started=False,headless=True,host_input_actions=0,guest=state,
                input_transfers=inputs,source_identities=source_ids,implementation=before,driver=identity(driver),errors=[])
    try:
        vmrun(['CopyFileFromHostToGuest',VMX,module,guest/'devtools'/module.name],guest=True)
        vmrun(['CopyFileFromHostToGuest',VMX,driver,remote_driver],guest=True)
        command="$env:TEMP='C:\\ChaomofaWorker\\temp';$env:TMP=$env:TEMP;& C:\\ChaomofaWorker\\Python\\python.exe -B -X utf8 '"+str(remote_driver)+"';if($LASTEXITCODE -ne 0){throw 'bounded original tail failed'};'completed'"
        result['execution']=run_script(command)
    except Exception as exc:result['errors'].append(str(exc))
    finally:
        for a,b in ((remote,out),(remote_log,log)):
            try:vmrun(['CopyFileFromGuestToHost',VMX,a,b],guest=True)
            except Exception as exc:result['errors'].append('retrieve: '+str(exc))
        if out.exists():
            if out.stat().st_size>256*1024:raise ValueError('bounded diagnostic report')
            result['report']=identity(out)
        result['implementation_unchanged']=before==identity(module)
        result['sources_unchanged']=source_ids==[identity(p)for p in sources]
        with receipt.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items()if k not in ('input_transfers','source_identities','guest')},indent=2))
    if result['errors']or not result['implementation_unchanged']or not result['sources_unchanged']:raise SystemExit(1)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);run(p.parse_args().label)
