import json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
script=r"""$busy=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'});if($busy.Count){throw 'guest busy'};
$cut=[DateTime]::Parse('2026-11-09T13:53:59Z').ToUniversalTime();$rows=@();
Get-ChildItem -LiteralPath C:\ChaomofaWorker -Recurse -File|Where-Object {$_.LastWriteTimeUtc -ge $cut -and $_.Name -notlike '*credentials*' -and $_.Name -notlike '*.private.*'}|ForEach-Object {
if($_.Length -gt 536870912){throw 'unexpected large current-round guest file'};
$rows+=[pscustomobject]@{path=$_.FullName;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}};
[pscustomobject]@{guest=$env:COMPUTERNAME;uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID;cpu=$m.NumberOfLogicalProcessors;memory=$m.TotalPhysicalMemory;game_and_python_processes=0;files=$rows}|ConvertTo-Json -Depth 4 -Compress"""
data=json.loads(run_script(script));data['remaining_current_round_guest_files_bytes']=sum(x['bytes']for x in data['files'])
data['scope']='modified files under dedicated guest C:/ChaomofaWorker since 2026-11-09T13:53:59Z; guest OS filesystem growth counted separately by F-drive VM disk'
out=R/'.venv-audit/native-worker/battle-wait-guest-storage-result-tail-v1-20261109.json'
with out.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
print(json.dumps({k:v for k,v in data.items()if k!='files'}))
