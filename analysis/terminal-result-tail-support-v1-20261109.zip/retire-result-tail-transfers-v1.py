"""Bounded transport requests; exact guest duplicate files only."""
import base64,hashlib,json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
W=R/'.venv-audit/native-worker'
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
idle="$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'});if($p.Count){throw 'guest busy'};"
def request(rows,remove=False):
    encoded=base64.b64encode(json.dumps(rows).encode()).decode()
    script=idle+"$rows=ConvertFrom-Json ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+encoded+r"')));$out=@();$checked=@();foreach($r in $rows){$p=$r.guest;if(Test-Path -LiteralPath $p -PathType Leaf){$f=Get-Item -LiteralPath $p;$hash=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant();if($f.Length -ne $r.retained_host.bytes -or $hash -ne $r.retained_host.sha256){throw 'identity mismatch'};$full=(Resolve-Path -LiteralPath $p).Path;if($full -ne $p.Replace('/','\') -or !$full.StartsWith('C:\ChaomofaWorker\') -or $full.Contains('..')){throw 'target escaped'};$checked+=$full;$out+=[pscustomobject]@{guest=$p;resolved_guest=$full;bytes=$f.Length;sha256=$hash}}else{"
    script+=("throw 'missing checked duplicate'" if remove else "")+"}};"
    if remove:script+="foreach($p in $checked){Remove-Item -LiteralPath $p -Force;if(Test-Path -LiteralPath $p){throw 'removal failed'}};"
    script+="ConvertTo-Json -InputObject @($out) -Depth 4 -Compress"
    if len(script)>2700:raise ValueError('bounded transport script')
    result=json.loads(run_script("try {"+script+"} catch { [pscustomobject]@{failure=$_.Exception.Message}|ConvertTo-Json -Compress }"))
    if isinstance(result,dict) and 'failure'in result:raise ValueError(result['failure'])
    return result

apply='--apply'in sys.argv[1:]
plan=R/'analysis/terminal-result-tail-transfer-retirement-v1-20261109.json'
if not apply:
    pairs=[
        ('C:/ChaomofaWorker/project/analysis/result-tail-inputs-v1-20261109/terminal-battle-wait-window-battle-v6-20261109.json.gz',W/'terminal-battle-wait-window-battle-v6-20261109.json.gz'),
        ('C:/ChaomofaWorker/project/analysis/result-tail-inputs-v1-20261109/terminal-battle-wait-diagnostic-v1-20261109.json',R/'analysis/terminal-battle-wait-diagnostic-v1-20261109.json'),
        ('C:/ChaomofaWorker/project/analysis/terminal-result-tail-v1-20261109.json',W/'terminal-result-tail-v1-20261109.json'),
        ('C:/ChaomofaWorker/terminal-result-tail-v1-20261109.log',W/'terminal-result-tail-v1-20261109.log'),
        ('C:/ChaomofaWorker/terminal-result-tail-v1-20261109-driver.py',W/'terminal-result-tail-v1-20261109-driver.py'),
        ('C:/ChaomofaWorker/project/analysis/result-tail-unit-checks-v2-20261109.json',W/'result-tail-unit-checks-v2-20261109.json'),
        ('C:/ChaomofaWorker/result-tail-unit-checks-v2-20261109-driver.py',W/'result-tail-unit-checks-v2-20261109-driver.py')]
    rows=[dict(guest=g,retained_host=ident(p))for g,p in pairs]
    for row in rows:
        found=request([row])
        if len(found)!=1:raise ValueError('required current-round duplicate missing')
        row['resolved_guest']=found[0]['resolved_guest']
    data=dict(kind='exact_current_round_guest_transport_retirement',rows=rows,total_bytes=sum(r['retained_host']['bytes']for r in rows),host_files_removed=False,historical_sources_or_assets_removed=False,reason='only this round restored/created guest transfer copies; F originals retained',execution='pending')
    with plan.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
    print(json.dumps(dict(plan=ident(plan),files=len(rows),bytes=data['total_bytes'])))
else:
    data=json.loads(plan.read_bytes());rows=data['rows']
    for row in rows:
        if ident(R/row['retained_host']['path'])!=row['retained_host']or len(request([row]))!=1:raise ValueError('original or duplicate changed before cleanup')
    removed=[]
    for row in rows:removed+=request([row],True)
    out=W/'result-tail-transfer-retirement-v1-20261109.json'
    result=dict(plan=ident(plan),removed=removed,total_bytes=data['total_bytes'],all_removed=True,host_originals_retained=True)
    with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(receipt=ident(out),files=len(removed),bytes=data['total_bytes'])))
