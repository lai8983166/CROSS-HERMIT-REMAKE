from pathlib import Path
w=Path('F:/project/chaomofa/.venv-audit/native-worker')
old=(w/'retire-context-heap-transfers-v1.py').read_text()
header=old.split('label=sys.argv[1]')[0]
header=header.replace("$_.Name -like 'python*'", "$_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'")
body="""
apply='--apply'in sys.argv[1:]
plan=R/'analysis/terminal-result-tail-transfer-retirement-v1-20261109.json'
if not apply:
    pairs=[
        ('C:/ChaomofaWorker/project/analysis/result-tail-inputs-v1-20261109/terminal-battle-wait-window-battle-v6-20261109.json.gz',W/'terminal-battle-wait-window-battle-v6-20261109.json.gz'),
        ('C:/ChaomofaWorker/project/analysis/result-tail-inputs-v1-20261109/terminal-battle-wait-diagnostic-v1-20261109.json',R/'analysis/terminal-battle-wait-diagnostic-v1-20261109.json'),
        ('C:/ChaomofaWorker/project/analysis/terminal-result-tail-v1-20261109.json',W/'terminal-result-tail-v1-20261109.json'),
        ('C:/ChaomofaWorker/terminal-result-tail-v1-20261109.log',W/'terminal-result-tail-v1-20261109.log'),
        ('C:/ChaomofaWorker/terminal-result-tail-v1-20261109-driver.py',W/'terminal-result-tail-v1-20261109-driver.py'),
        ('C:/ChaomofaWorker/project/analysis/result-tail-unit-checks-v2-20261109.json',W/'result-tail-unit-checks-v2-20261109.json'),
        ('C:/ChaomofaWorker/result-tail-unit-checks-v2-20261109-driver.py',W/'result-tail-unit-checks-v2-20261109-driver.py')]
    rows=[dict(guest=g,retained_host=ident(p))for g,p in pairs]
    for row in rows:
        found=request([row])
        if len(found)!=1:raise ValueError('required current-round duplicate missing')
        row['resolved_guest']=found[0]['resolved_guest']
    data=dict(kind='exact_current_round_guest_transport_retirement',rows=rows,total_bytes=sum(r['retained_host']['bytes']for r in rows),host_files_removed=False,historical_sources_or_assets_removed=False,reason='only this round restored/created guest transfer copies; F originals retained',execution='pending')
    with plan.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
    print(json.dumps(dict(plan=ident(plan),files=len(rows),bytes=data['total_bytes'])))
else:
    data=json.loads(plan.read_bytes());rows=data['rows']
    for row in rows:
        if ident(R/row['retained_host']['path'])!=row['retained_host']or len(request([row]))!=1:raise ValueError('original or duplicate changed before cleanup')
    removed=[]
    for row in rows:removed+=request([row],True)
    out=W/'result-tail-transfer-retirement-v1-20261109.json'
    result=dict(plan=ident(plan),removed=removed,total_bytes=data['total_bytes'],all_removed=True,host_originals_retained=True)
    with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(receipt=ident(out),files=len(removed),bytes=data['total_bytes'])))
"""
with (w/'retire-result-tail-transfers-v1.py').open('x',encoding='utf8')as f:f.write(header+body)
s=(w/'inventory-battle-wait-guest-clock-v1.py').read_text().replace('2026-11-09T11:41:37Z','2026-11-09T13:53:59Z').replace('storage-clock-v1','storage-result-tail-v1').replace("$_.Name -like 'python*'", "$_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'")
with (w/'inventory-result-tail-guest-v1.py').open('x',encoding='utf8')as f:f.write(s)
s=(w/'check-battle-wait-preservation-v3.py').read_text().replace('battle-wait-preservation-v3.json','result-tail-preservation-v1-20261109.json')
with (w/'check-result-tail-preservation-v1.py').open('x',encoding='utf8')as f:f.write(s)
