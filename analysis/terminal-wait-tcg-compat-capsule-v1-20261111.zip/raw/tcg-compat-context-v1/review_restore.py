"""Independent bounded offline review; no VM entry points are called."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys
from devtools import terminal_tcg_compat_context as c

ROOT = Path.cwd()
WORK = ROOT / '.venv-audit/native-worker/tcg-compat-restore-v3'
def need(value, message):
    if not value:
        raise ValueError(message)
def ident(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p.relative_to(ROOT)) if p.is_absolute() and p.is_relative_to(ROOT) else str(p),
                bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def verify_identity(row):
    got = ident(row['path'])
    need((got['bytes'], got['sha256']) == (row['bytes'], row['sha256']), 'identity: '+row['path'])
    return got

def common_frames(data):
    out = []
    for m in re.finditer(rb'\x04(.{4})\x0acpu_common', data, re.S):
        p = m.end()
        instance, version, halted, irq = struct.unpack_from('>IIII', data, p)
        section = int.from_bytes(m[1], 'big')
        # The fixture exception_index=-1, so no optional exception subsection.
        need(data[p+16] == 0x7e and int.from_bytes(data[p+17:p+21], 'big') == section, 'common footer')
        out.append(dict(offset=m.start(), instance=instance, version=version,
                        halted=halted, interrupt_request=irq, bytes_hex=data[m.start():p+21].hex()))
    need(len(out) == 2 and [x['instance'] for x in out] == [0, 1], 'exact two framed cpu_common')
    need(all(x['version'] == 1 for x in out), 'common version')
    return out

def event_frames(data):
    name = b'cpu/chaomofa-tcg-event-context-v1'
    marker = bytes([5, len(name)])+name
    out = []
    for m in re.finditer(re.escape(marker), data):
        version, error, is_int, next_eip, old = struct.unpack_from('>IiiQi', data, m.end())
        need(version == 1, 'event subsection version')
        out.append(dict(offset=m.start(), version=version, error_code=error,
                        exception_is_int=is_int, exception_next_eip=f'{next_eip:016x}',old_exception=old))
    need(len(out) == 2, 'exact two event subsections')
    return out

def trajectory(path, a, b):
    rows = []
    for line in path.read_text().splitlines():
        m = re.match(r'Trace (\d+): .* \[([0-9a-f]+)/([0-9a-f]+)/([0-9a-f]+)/([0-9a-f]+)\]', line)
        if m:
            rows.append([int(m[1]), *[int(m[i], 16) for i in (2, 3, 4, 5)]])
    ai = [i for i, row in enumerate(rows) if row[2] == a]
    bi = [i for i, row in enumerate(rows) if row[2] == b]
    need(len(ai) == len(bi) == 1 and ai[0] < bi[0], 'unique ordered A/B trace endpoints')
    return rows[ai[0]:bi[0]], rows[bi[0]:]

rp = WORK/'report.json'
need(ident(rp)['sha256'] == sys.argv[1], 'external report hash')
r = json.loads(rp.read_text())
need(r['bounded_case_passed'] is True and not r['errors'] and r['all_processes_exited'] is True,
     'native result did not pass')
need(r['accepted'] is False and r['windows_admitted'] is False, 'qualification')
need(all(type(v) is bool and v for v in r['checks'].values()), 'check rejected')
raw_files = [verify_identity(x) for x in r['files']]
verify_identity(r['checkpoint']); verify_identity(r['binary'])
mf = ROOT/'.venv-audit/native-worker/tcg-checkpoint-build-v11b/manifest.json'
manifest = json.loads(mf.read_text())
need(manifest['binary'] == r['binary'], 'binary manifest identity')
manifest_files = [verify_identity(row) for name in ('modified_source','build_config') for row in manifest[name]]
for name in ('parent_manifest','source_delta','patch','binary'):
    manifest_files.append(verify_identity(manifest[name]))

need(r['source_a'] == r['saved_a_after'] == r['target_a'], 'save-before/after/targetA')
need(r['source_b'] == r['target_b'], 'targetB')
for point, pc in [('a',0x100600),('b',0x100780)]:
    v = r['source_'+point]
    need(len(v['states']) == 2 and int(v['states'][0]['eip'],16) == pc, 'CPU topology/PC')
    need(len(v['observation']['events']) == 2, 'events topology')
    need(len(v['observation']['ram_blocks']) == 8, 'RAM topology')
    need(sum(x['bytes'] for x in v['observation']['ram_blocks']) == 4312342528, 'RAM size')
    need(all(x['migratable'] for x in v['observation']['ram_blocks']), 'RAM coverage')
need(r['source_a']['observation']['ram_blocks'] != r['source_b']['observation']['ram_blocks'], 'no actual RAM change')

anchor = dict(expected_cpu=0, expected_vcpus=2,
              expected_source_sha256=c.source_digest(r['source_a']['states'][0]))
envelope = c.pack(r['source_a']['states'][0], **anchor)
need(c.unpack(envelope, **anchor) == r['target_a']['states'][0], 'actual compatibility envelope roundtrip')
try:
    c.pack(r['source_b']['states'][0], expected_cpu=0, expected_vcpus=2,
           expected_source_sha256=c.source_digest(r['source_b']['states'][0]))
except c.CompatContextError:
    pass
else:
    raise ValueError('long64 B was wrongly admitted as compatibility32')

stream = (WORK/'checkpoint.bin').read_bytes()
cf = common_frames(stream); ef = event_frames(stream)
for i, event in enumerate(r['source_a']['observation']['events']):
    need(cf[i]['interrupt_request'] == event['interrupt_request'] and cf[i]['halted'] == event['halted'], 'stream common differs A')
    for key in ('error_code','exception_is_int','exception_next_eip','old_exception'):
        need(ef[i][key] == event[key], 'stream event differs A: '+key)

# Verify actual ELF header/program-load mapping, then fixed original machine bytes.
elf = (WORK/'guest.elf').read_bytes()
need(elf[:7] == b'\x7fELF\x01\x01\x01' and len(elf) == 8192, 'ELF32 identity')
phoff = struct.unpack_from('<I', elf, 28)[0]
phtype, file_offset, vaddr, paddr, filesz, memsz, flags, align = struct.unpack_from('<8I', elf, phoff)
need((phtype,file_offset,vaddr,paddr,filesz) == (1,4096,0x100000,0x100000,4096), 'ELF PT_LOAD')
need(elf[4096+0x600:4096+0x608] == bytes.fromhex('90ea000710001800'), 'compat NOP/far JMP64')
consumer = bytes.fromhex('4c8904250090100064488b0425800910004889042508901000f3440f7f3c2510901000b9000100c00f3248c1e2204809d04889042520901000480fae042500911000')
need(elf[4096+0x700:4096+0x700+len(consumer)] == consumer, 'original64 consumer bytes')
output = (WORK/'source.bin').read_bytes()
need(output == (WORK/'target.bin').read_bytes() and len(output) == 552, 'consumer actual output')
r8, high = struct.unpack_from('<QQ', output)
fsbase = struct.unpack_from('<Q',output,32)[0]
fip, fdp = struct.unpack_from('<QQ',output,48)
need((r8,high,fsbase,fip,fdp) == (0x123456789abcdef0,0x13579bdf2468ace0,0x100000000,0x10010039f,0x100100904), 'raw consumer numeric fields')
need(output[16:32].hex() == '13579bdf2468ace00123456789abcdef', 'actual XMM15')
need(r['source_exit'] == r['target_exit'] == 33, 'natural source/target exit')

# Cross-check receipt data, not merely summary booleans.
save = [q for q in r['source_qmp'] if q['request']['execute'] == 'x-save-tcg-checkpoint']
need(len(save) == 1, 'one same-command save')
saved = json.loads(save[0]['response']['return']['state'])
need(saved == {'before':r['source_a'], 'after':r['saved_a_after']}, 'QMP save receipt differs report')
for role in ('source','target'):
    states=[]; observations=[]
    for q in r[role+'_qmp']:
        cmd=q['request']['execute']
        if cmd in ('x-query-tcg-state','x-query-tcg-checkpoint'):
            obj=json.loads(q['response']['return']['state'])
            (states if cmd=='x-query-tcg-state' else observations).append(obj)
    expected_points = ('b',) if role=='source' else ('a','b')
    need(states == [s for p in expected_points for s in r[role+'_'+p]['states']], 'QMP CPU receipts')
    need(observations == [r[role+'_'+p]['observation'] for p in expected_points], 'QMP observer receipts')

st, ss = trajectory(WORK/'source.trace',0x100600,0x100780)
tt, ts = trajectory(WORK/'target.trace',0x100600,0x100780)
need(st == tt and all(row[0] == 0 for row in st), 'A-B all trace fields/VP0')
need(any(row[2] == 0x100708 for row in st) and any(row[2] == 0x100739 for row in st), 'original consumer trace missing')

report = dict(schema='terminal-tcg-compat-restore-independent-review-v1',date='2026-11-11',
    source_report=ident(rp),build_manifest=ident(mf),binary=r['binary'],
    raw_files=raw_files,manifest_entries_verified=len(manifest_files),
    bounded_case_passed=True,windows_admitted=False,full_machine_acceptance=False,
    capture_lossless_verified=True,unicorn32_replay_admitted=False,
    independent_checks=dict(same_command_before_after=True,restored_a_all_cpu_events_ram=True,
        restored_b_all_cpu_events_ram=True,all_ram_blocks=8,total_ramblock_bytes=4312342528,
        actual_ram_change=True,actual_source_target_output_equal=True,exit_codes=[33,33],
        qmp_raw_receipts_match_summary=True,original_elf_header_consumer_bytes=True,
        compatibility_envelope_exact_raw_reconstruction=True,long64_b_rejected_by_compat_adapter=True),
    stream_cpu_common=cf,stream_event_context=ef,
    actual_consumer=dict(r8=f'{r8:016x}',fs_load_value=f'{high:016x}',low_decoy='fedcba9876543210',
        fs_base=f'{fsbase:016x}',xmm15_bytes=output[16:32].hex(),fip=f'{fip:016x}',fdp=f'{fdp:016x}',
        instruction_sites={'R8_store':'100700','FS_high_address_load':'100708','XMM15_store':'100719',
                           'FS_BASE_RDMSR':'100728','FXSAVE64':'100739'},
        compatibility_a_cs='0008',long64_b_cs='0018'),
    trace=dict(interval='[A=0x100600,B=0x100780)',entries=len(st),fields='VP,CSbase,PC,hflags,cflags; host TB pointer excluded',
        equal=True,rows=st,exit_suffix_equal=ss==ts,
        limits='TB entry log is not retirement. VP0 executed; 2VP configured/stopped is not SMP handshake. Post-B teardown is outside interval.'),
    adapter=dict(source=ident('devtools/terminal_tcg_compat_context.py'),
        tests=ident('devtools/tests/test_terminal_tcg_compat_context.py'),
        contract=ident('analysis/terminal-wait-tcg-compat-context-contract-v1-20261111.json'),
        record_anchor=anchor,normal_tests=10,optimized_tests=10),
    lifecycle_review=[
        'Same QMP command captures before, synchronously saves a full stream with global_state_store, captures after. No guest register/RAM/IRQ writes added.',
        'O_EXCL refuses overwrite; QIO reference is released after QEMUFile takes it; qemu_fclose runs after save, including save failure. Failed partial streams are not accepted.',
        'Entry capture requires stopped TCG and every VP stopped. Attached BlockBackend storage, network clients and user IOThread objects are rejected.',
        'qmp_query_iothreads only enumerates object_get_objects_root; internal-root IOThreads are not excluded by this guard. Current fixed diskless PC topology only; no general device-quiescence claim.',
        'ram_save_setup releases BQL around multifd synchronization even with multifd disabled. Same-command does not mean BQL continuously held. Observed pre/post and independently restored events match this actual case.',
        'save_snapshot generic migration/replay blockers and block drain are not reproduced by this project helper. It explicitly refuses attached disks and must not be used as a Windows disk checkpoint API.'
    ],
    prior_failures=[
        'compat_restore_v1 lacked identity second2MiB mapping; fixture page fault before target, not a TCG CPU defect.',
        'compat_restore_v2 asynchronous save serialized CPU0 HARD2 although earlier A sampled0; source/target consumer and RAM equality did not waive failed event equality.',
        'v9 build used nonexistent system/bql.h. v10 needed query_iothreads declaration from qapi-commands-misc.h. Those builds were not accepted native sources; final actual source is v11b.'
    ],
    remaining_gates=[
        'Lossless envelope covers all original tcg-state-v1 fields, not all possible x86 MSRs/XSAVE or whole-machine state.',
        'No compatible Unicorn32 loader exists for high hidden bases/extended registers. The new57-name view is not the frozen raw API format.',
        'Actual compatibility-to-long64 microguest is not Windows/WOW64 ABI, kernel resource lifetime or original-game acceptance.',
        'No Windows boot was performed in this reviewed evidence; disks/network/asynchronous devices and active two-VP execution remain unqualified.',
        'RAM SHA comparison uses original observer outputs and fresh restore; this reviewer does not independently decode every compressed migration RAM page.',
        'Original game still requires complete state/ABI/resources, independent replay, tamper rejection and two fresh native lifetimes under unchanged acceptance rules.'
    ],native_runs_by_reviewer=0)
out=ROOT/'analysis/terminal-wait-tcg-compat-restore-review-v1-20261111.json'
need(not out.exists(), 'review output already frozen')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(ident(out)))
