from pathlib import Path
import hashlib
import json
import struct
from devtools import terminal_tcg_compat_context as c

ROOT = Path.cwd()
OUT = ROOT / '.venv-audit/native-worker/tcg-compat-context-v1'
def identity(path):
    p = ROOT / path
    b = p.read_bytes()
    return dict(path=path, bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def write(path, value):
    p = ROOT / path
    if p.exists():
        raise RuntimeError('frozen output already exists: '+str(p))
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

source = '.venv-audit/native-worker/tcg-compatibility-v8b/report.json'
if identity(source)['sha256'] != '34b5d318f69c011644088c5843107d945311e5f05df69daf3ea6e64421321d1c':
    raise RuntimeError('capture identity changed')
raw = json.loads((ROOT / source).read_text())['state']
anchor = dict(expected_cpu=0, expected_vcpus=2, expected_source_sha256=c.source_digest(raw))
envelope = c.pack(raw, **anchor)
restored = c.unpack(json.loads(json.dumps(envelope)), **anchor)
if restored != raw or type(restored) is not dict:
    raise RuntimeError('lossless reconstruction failed')
write('.venv-audit/native-worker/tcg-compat-context-v1/actual-envelope.json', envelope)

# Independent raw stream framing, not a textual VMDESC name match.
cp = '.venv-audit/native-worker/tcg-compat-restore-v2/checkpoint.bin'
b = (ROOT / cp).read_bytes()
frames = []
for offset in (10127513, 10129768):
    if b[offset-6] != 4 or b[offset-1] != 10 or b[offset:offset+10] != b'cpu_common':
        raise RuntimeError('cpu_common section header mismatch')
    section = struct.unpack_from('>I', b, offset-5)[0]
    instance, version, halted, irq = struct.unpack_from('>IIII', b, offset+10)
    if version != 1 or b[offset+26] != 0x7e or struct.unpack_from('>I', b, offset+27)[0] != section:
        raise RuntimeError('cpu_common footer/version mismatch')
    frames.append(dict(name_offset=offset, section_id=section, instance=instance,
                       version=version, halted=halted, interrupt_request=irq,
                       framed_bytes_hex=b[offset-6:offset+31].hex()))
if [(x['instance'], x['halted'], x['interrupt_request']) for x in frames] != [(0,0,2),(1,1,0)]:
    raise RuntimeError('unexpected stream CPU common values')
write('.venv-audit/native-worker/tcg-compat-context-v1/async-stream-boundary.json', dict(
    schema='tcg-compat-async-stream-boundary-v1', stream=identity(cp), frames=frames,
    source_observed_cpu0_irq=0, target_observed_cpu0_irq=2,
    conclusion='HARD2 already serialized; source observation predates actual asynchronous save boundary',
    checkpoint_equivalence_accepted=False))

files = ['devtools/terminal_tcg_compat_context.py',
         'devtools/tests/test_terminal_tcg_compat_context.py',
         'devtools/terminal_tcg_canonical57_v2.py',
         '.venv-audit/native-worker/tcg-compat-context-v1/frozen-before-execution.sha256',
         '.venv-audit/native-worker/tcg-compat-context-v1/tests-normal.log',
         '.venv-audit/native-worker/tcg-compat-context-v1/tests-optimized.log',
         '.venv-audit/native-worker/tcg-compat-context-v1/actual-envelope.json',
         '.venv-audit/native-worker/tcg-compat-context-v1/async-stream-boundary.json']
report = dict(schema='terminal-tcg-compat-context-contract-v1', date='2026-11-11',
    scope='Offline lossless compatibility32 envelope; no VM/native execution by this reviewer',
    source=identity(source), external_record_anchor=anchor, files=[identity(x) for x in files],
    schemas=dict(envelope=c.SCHEMA, view=c.VIEW_SCHEMA),
    actual_capture_roundtrip=dict(exact_original_dictionary=True, original_json_whitespace_preserved=False,
        cpu=0, stopped_vcpus=2, names=57, retained_high_r8=raw['gpr'][8],
        retained_high_fs_base=raw['segments_es_cs_ss_ds_fs_gs_ldt_tr_gdt_idt'][4][1],
        retained_fip=raw['fip'], retained_fdp=raw['fdp'], retained_xmm15=raw['xmm_low64_high64'][15]),
    contracts=[
        'raw64 is a detached exact copy of every tcg-state-v1 field; unknown/missing source fields reject rather than disappear.',
        'view32 has exactly the existing 57 register NAMES with its own versioned semantics. GPRs EAX..EDI expose low32 only; raw64 and retained_context keep upper32, R8..15 and XMM8..15.',
        'Control/debug registers and descriptor bases stay full64; visible segment selectors stay16 while every hidden cache remains original in raw64 and the retained_context.',
        'Physical FP0..7 are not TOP-rotated; FPTAG derives physical emptiness plus FP80 classification. Logical ST(i) is physical R((TOP+i)&7). FIP/FDP retain64 independently of current CS mode.',
        'CR4.DE=0 aliases DR4/5 to DR6/7, not old Unicorn raw API padding. DE=1 is losslessly capturable but view entries explicitly mark unreadable/#UD; no numeric zero is invented.',
        'pack requires stopped64 target, active PE/PG/PAE/LME/LMA, present32 compatibility CS.L0/D1, consistent mode/cache hflags, exact topology/width/type/TOP.',
        'unpack uses an externally pinned canonical source digest then re-derives the entire view, metadata and qualification fields with strict type equality. A changed raw record cannot be authorized by changing only its internal digest.',
        'Caller must authenticate artifact/build/capture before deriving expected_source_sha256. The envelope is not a signature and the hash alone does not establish an actual capture.',
        'All legacy-Unicorn32-format, Unicorn32-replay, full-machine and Windows-admission flags remain false. There is no engine loader or restore setter.',
    ],
    regression=dict(normal_passed=10, optimized_passed=10,
        includes=['actual fixed capture reconstruction','JSON roundtrip','detached ownership',
                  'synthetic highGPR/control/MMR width retention explicitly distinct from real capture',
                  'DE1 unreadable semantics','DR alias distinction','external-anchor mismatch',
                  'derived view/qualification tamper','mode/cache/topology rejection','strict types and widths']),
    current_async_restore_failure=dict(report=identity('.venv-audit/native-worker/tcg-compat-restore-v2/report.json'),
        decoded_cpu_common=frames,
        conclusion='CPU0 HARD2 is already in saved stream, whereas earlier source A observed0. Do not waive this event mismatch because CPU/RAM/consumer values match.',
        source_reference='e470268ff446ec56728215a987ed166d5ed8fb64 hw/core/cpu-system.c:259 UINT32 halted, UINT32 interrupt_request; post_load clears only obsolete EXIT0x01.',
        next_condition='Same stopped boundary capture/save plus pre/post event check, and actual restored all-events equality; BQL alone does not certify device postload or asynchronous I/O quiescence.'),
    remaining_gates=[
        'This module admits one compatibility-mode CPU record only. Other VP modes require their own appropriate view; do not relabel a long-mode B record as compatibility32.',
        'tcg-state-v1 is a selected source export, not every possible x86 machine/MSR/XSAVE field. Lossless here means no loss of that original record.',
        'Full-machine memory/devices/events/build identity and execution behavior need independent evidence; current asynchronous compat restore event mismatch remains rejected.',
        'UC_MODE32 cannot faithfully restore these high hidden bases/extended registers. No new Unicorn replay adapter is claimed.',
        'No actual Windows/WOW64 call boundary, original game lifetime/resource/ABI replay or final acceptance has been established.'
    ], native_runs_by_reviewer=0, windows_admitted=False, full_machine_accepted=False)
write('analysis/terminal-wait-tcg-compat-context-contract-v1-20261111.json', report)
print(json.dumps(identity('analysis/terminal-wait-tcg-compat-context-contract-v1-20261111.json')))
