"""Independent bounded offline review; no VM entry points are called."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys
from devtools import terminal_tcg_compat_context as c

ROOT = Path.cwd()
WORK = ROOT / '.venv-audit/native-worker/tcg-compat-restore-v3'
def need(value, message):
    if not value:
        raise ValueError(message)
def ident(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p.relative_to(ROOT)) if p.is_absolute() and p.is_relative_to(ROOT) else str(p),
                bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def verify_identity(row):
    got = ident(row['path'])
    need((got['bytes'], got['sha256']) == (row['bytes'], row['sha256']), 'identity: '+row['path'])
    return got

def common_frames(data):
    out = []
    for m in re.finditer(rb'\x04(.{4})\x0acpu_common', data, re.S):
        p = m.end()
        instance, version, halted, irq = struct.unpack_from('>IIII', data, p)
        section = int.from_bytes(m[1], 'big')
        # The fixture exception_index=-1, so no optional exception subsection.
        need(data[p+16] == 0x7e and int.from_bytes(data[p+17:p+21], 'big') == section, 'common footer')
        out.append(dict(offset=m.start(), instance=instance, version=version,
                        halted=halted, interrupt_request=irq, bytes_hex=data[m.start():p+21].hex()))
    need(len(out) == 2 and [x['instance'] for x in out] == [0, 1], 'exact two framed cpu_common')
    need(all(x['version'] == 1 for x in out), 'common version')
    return out

def event_frames(data):
    name = b'cpu/chaomofa-tcg-event-context-v1'
    marker = bytes([5, len(name)])+name
    out = []
    for m in re.finditer(re.escape(marker), data):
        version, error, is_int, next_eip, old = struct.unpack_from('>IiiQi', data, m.end())
        need(version == 1, 'event subsection version')
        out.append(dict(offset=m.start(), version=version, error_code=error,
                        exception_is_int=is_int, exception_next_eip=f'{next_eip:016x}',old_exception=old))
    need(len(out) == 2, 'exact two event subsections')
    return out

def trajectory(path, a, b):
    rows = []
    for line in path.read_text().splitlines():
        m = re.match(r'Trace (\d+): .* \[([0-9a-f]+)/([0-9a-f]+)/([0-9a-f]+)/([0-9a-f]+)\]', line)
        if m:
            rows.append([int(m[1]), *[int(m[i], 16) for i in (2, 3, 4, 5)]])
    ai = [i for i, row in enumerate(rows) if row[2] == a]
    bi = [i for i, row in enumerate(rows) if row[2] == b]
    need(len(ai) == len(bi) == 1 and ai[0] < bi[0], 'unique ordered A/B trace endpoints')
    return rows[ai[0]:bi[0]], rows[bi[0]:]

import subprocess
WORK=ROOT/'.venv-audit/native-worker/tcg-compat-restore-v4'
rp=WORK/'report.json'; mf=ROOT/'.venv-audit/native-worker/tcg-checkpoint-build-v12/manifest.json'
need(ident(rp)['sha256']=='5cbe7e01ff70387ffe1bcbe4f1c56f79eecd33c34d78a3d4fe6c1901696c3c3c','report anchor')
need(ident(mf)['sha256']=='63eec02cd230cb3c62751ab4fea3fc80af795ae4cf16d3364876a1b4dad05d56','manifest anchor')
r=json.loads(rp.read_text());m=json.loads(mf.read_text())
need(r['bounded_case_passed'] is True and not r['errors'] and r['all_processes_exited'] is True,'native status')
need(all(v is True for v in r['checks'].values()),'native checks')
need(r['accepted'] is False and r['windows_admitted'] is False,'qualification')
files=[verify_identity(x)for x in r['files']]
verify_identity(r['binary']);verify_identity(m['binary'])
need((r['binary']['sha256'],r['binary']['bytes'])==(m['binary']['sha256'],m['binary']['bytes']),'binary match')
checked=[verify_identity(x)for key in ('modified_source','build_config','unchanged_base_source')for x in m[key]]
verify_identity(m['source_delta']);verify_identity(m['parent_manifest'])
parent=json.loads(Path(m['parent_manifest']['path']).read_text())
need(m['modified_source']==parent['modified_source'] and m['source_delta']==parent['source_delta'],'CPU/checkpoint implementation changed')
source_blobs=[]
for rel,row in zip(('block/vmdk.c','block/meson.build'),m['unchanged_base_source']):
    blob=subprocess.run(['git','--git-dir=.venv-audit/native-worker/tcg-source-identity-v1/source.git',
        'show','e470268ff446ec56728215a987ed166d5ed8fb64:'+rel],capture_output=True,check=True).stdout
    need(hashlib.sha256(blob).hexdigest()==row['sha256'] and len(blob)==row['bytes'],'base source mismatch')
    source_blobs.append(dict(path=rel,bytes=len(blob),sha256=row['sha256']))
opts=json.loads((ROOT/'.venv-audit/native-worker/tcg-build-v1/build/meson-info/intro-buildoptions.json').read_text())
need([x['value']for x in opts if x['name']=='vmdk']==['enabled'],'vmdk option')
commands=json.loads((ROOT/'.venv-audit/native-worker/tcg-build-v1/build/compile_commands.json').read_text())
need(len([x for x in commands if x['file'].endswith('/block/vmdk.c')])==1,'vmdk compiled source')
need(r['source_a']==r['saved_a_after']==r['target_a'],'A full before/after/restore')
need(r['source_b']==r['target_b'],'B full restore')
for point in ('a','b'):
    b=r['source_'+point]['observation']['ram_blocks']
    need(len(b)==8 and sum(x['bytes']for x in b)==4312342528 and all(x['migratable']for x in b),'RAM extent')
need(r['source_a']['observation']['ram_blocks']!=r['source_b']['observation']['ram_blocks'],'RAM changed')
raw=r['source_a']['states'][0]
anchor=dict(expected_cpu=0,expected_vcpus=2,expected_source_sha256=c.source_digest(raw))
need(c.unpack(c.pack(raw,**anchor),**anchor)==r['target_a']['states'][0],'lossless context')
stream=(WORK/'checkpoint.bin').read_bytes(); cf=common_frames(stream);ef=event_frames(stream)
for i,event in enumerate(r['source_a']['observation']['events']):
    need(cf[i]['interrupt_request']==event['interrupt_request'] and cf[i]['halted']==event['halted'],'stream common')
    need(all(ef[i][k]==event[k]for k in ('error_code','exception_is_int','exception_next_eip','old_exception')),'event subsection')
# Fixed v3 actual ELF already independently decoded; v4 keeps precisely those bytes.
old_elf=ROOT/'.venv-audit/native-worker/tcg-compat-restore-v3/guest.elf'
need((WORK/'guest.elf').read_bytes()==old_elf.read_bytes(),'fixture identity changed')
output=(WORK/'source.bin').read_bytes()
need(output==(WORK/'target.bin').read_bytes() and len(output)==552,'consumer output')
need(struct.unpack_from('<QQ',output)==(0x123456789abcdef0,0x13579bdf2468ace0),'R8/highFS memory')
need(output[16:32].hex()=='13579bdf2468ace00123456789abcdef','XMM15')
need(struct.unpack_from('<Q',output,32)[0]==0x100000000,'FS base')
need(struct.unpack_from('<QQ',output,48)==(0x10010039f,0x100100904),'FIP/FDP')
need(r['source_exit']==r['target_exit']==33,'natural exit')
for role in ('source','target'):
    states=[];obs=[]
    for q in r[role+'_qmp']:
        cmd=q['request']['execute']
        if cmd in ('x-query-tcg-state','x-query-tcg-checkpoint'):
            (states if cmd=='x-query-tcg-state'else obs).append(json.loads(q['response']['return']['state']))
    points=('b',)if role=='source'else('a','b')
    need(states==[s for p in points for s in r[role+'_'+p]['states']],'raw QMP states')
    need(obs==[r[role+'_'+p]['observation']for p in points],'raw QMP observer')
save=[q for q in r['source_qmp']if q['request']['execute']=='x-save-tcg-checkpoint']
need(len(save)==1 and json.loads(save[0]['response']['return']['state'])==dict(before=r['source_a'],after=r['saved_a_after']),'same command QMP')
st,ss=trajectory(WORK/'source.trace',0x100600,0x100780);tt,ts=trajectory(WORK/'target.trace',0x100600,0x100780)
need(st==tt and len(st)==74 and all(x[0]==0 for x in st),'full trajectory')
oldreview=ROOT/'analysis/terminal-wait-tcg-compat-restore-review-v1-20261111.json'
need(ident(oldreview)['sha256']=='d1d44b88fdc2267adf70175d66c27a6b03813928faeb37a533f30297de34da71','prior review changed')
out=ROOT/'analysis/terminal-wait-tcg-compat-restore-review-v12-addendum-20261111.json'
need(not out.exists(),'output frozen')
report=dict(schema='tcg-compat-restore-review-v12-addendum-v1',date='2026-11-11',
    parent_review=ident(oldreview),source_report=ident(rp),build_manifest=ident(mf),
    builder=ident('devtools/terminal_tcg_vmdk_build.py'),binary=r['binary'],
    build_delta=dict(cpu_checkpoint_source_entries_unchanged=len(m['modified_source']),
        source_delta_unchanged=True,exact_upstream_commit='e470268ff446ec56728215a987ed166d5ed8fb64',
        original_source_blobs=source_blobs,current_config_verified=True,
        vmdk='enabled',compile_commands_contains_vmdk=True,identities_rehashed=len(checked)+4,
        limitation='This enables the original complete VMDK driver, including write support. Read-only use is a separate per-launch block configuration, not a property of this build.'),
    evidence_files=files,stream_cpu_common=cf,stream_event_context=ef,
    independently_verified=dict(native_seconds=r['seconds'],same_command_before_after=True,
        source_target_a_and_b_all_raw_cpu_events_ram=True,ram_blocks=8,total_ramblock_bytes=4312342528,
        ram_really_changed=True,original_qmp_receipts_match=True,lossless_compat_envelope_roundtrip=True,
        original_elf_equal_reviewed_v3=True,consumer_bytes=552,
        real_r8_high_fs_distinct_page_xmm15_fsbase_fip_fdp=True,source_target_output_equal=True,
        natural_exit_codes=[33,33],a_to_b_trace_entries=74,all_trace_fields_equal=True,
        trace_fields=['VP','CSbase','PC','hflags','cflags'],exit_suffix_equal=ss==ts),
    record_anchor=anchor,bounded_case_passed=True,windows_admitted=False,
    unicorn32_replay_admitted=False,full_machine_acceptance=False,
    limitations=[
        'All restrictions of the parent review remain: fixed diskless PC fixture only, no arbitrary storage/network/device checkpoint acceptance.',
        'The helper still rejects attached block storage. Enabling VMDK does not extend that checkpoint contract to a Windows disk.',
        'IOThread guard covers user objects, not internal-root objects. RAM save releases BQL internally; only observed same-command/restore equality is certified.',
        '74 equal TB entries are execution-block entry evidence, not an independent retirement trace; VP0 only, not an active SMP handshake.',
        'This addendum does not inspect or operate the separate Windows attempt. No Windows/WOW64 or original-game acceptance follows from this microguest.',
        'RAM evidence is rechecked original observer outputs and fresh restore, not independent decompression of every migration RAM page.'
    ],native_runs_by_reviewer=0)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(ident(out)))
