
.venv-audit/native-worker/tcg-compat-context-v1/consumer64.bin:     file format binary


Disassembly of section .data:

0000000000100700 <.data>:
  100700:	4c 89 04 25 00 90 10 	mov    %r8,0x109000
  100707:	00 
  100708:	64 48 8b 04 25 80 09 	mov    %fs:0x100980,%rax
  10070f:	10 00 
  100711:	48 89 04 25 08 90 10 	mov    %rax,0x109008
  100718:	00 
  100719:	f3 44 0f 7f 3c 25 10 	movdqu %xmm15,0x109010
  100720:	90 10 00 
  100723:	b9 00 01 00 c0       	mov    $0xc0000100,%ecx
  100728:	0f 32                	rdmsr
  10072a:	48 c1 e2 20          	shl    $0x20,%rdx
  10072e:	48 09 d0             	or     %rdx,%rax
  100731:	48 89 04 25 20 90 10 	mov    %rax,0x109020
  100738:	00 
  100739:	48 0f ae 04 25 00 91 	fxsave64 0x109100
  100740:	10 00 
  100742:	90                   	nop
  100743:	90                   	nop
  100744:	90                   	nop
