import hashlib,json,subprocess,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('F:/project/chaomofa');sys.path.insert(0,str(ROOT))
from devtools.isolated_windows_vm import WORKER,vmrun
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def write(p,d):
 with p.open('x',encoding='utf8')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
out=ROOT/'analysis/terminal-original-wait-closeout-v1-20261109.json'
need(not out.exists(),'fresh closeout')
need(vmrun(['list']).strip()=='Total running VMs: 0'and not list(WORKER.rglob('*.vmem')),'VM fully stopped')
checks=read(WORKER/'original-wait-unit-checks-v2-20261109.json')
need(len(checks)==2 and all(x['returncode']==0 and 'Ran 294 tests' in x['output']for x in checks),'both complete regression modes')
preservation=read(WORKER/'original-wait-preservation-v1.json');need(not preservation['mismatches'],'preservation')
retirement=read(WORKER/'original-wait-retirement-result-v1.json')
need(retirement['guest_removed_logical_bytes']==3880553 and retirement['host_removed_logical_bytes']==0,'actual retirement boundary')
need(len(retirement['host_retained_duplicates'])==1,'retained rejected cleanup accounted')
baseline='677da0e9ee995f5b83951f4fb4b9fd41df6a697c'
need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline,'base commit unchanged')
scripts=['check-original-wait-change.py','check-original-wait-evidence.py','retire-original-wait-duplicates.py','finish-original-wait-retirement.py','stop-original-wait-vm.py','closeout-original-wait.py']
capsule=ROOT/'analysis/terminal-original-wait-audit-scripts-v1-20261109.zip'
with zipfile.ZipFile(capsule,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in scripts:z.write(WORKER/name,name)
 z.writestr('manifest.json',json.dumps([ident(WORKER/name)for name in scripts],indent=2))
receipts=[]
for pattern in ('terminal-original-wait-*.run.json','terminal-original-wait-*.log','original-wait-*.json','*original-wait*run.json','boot-original-wait*.json','preflight-original-wait*.json','guest-clock-original-wait*.json','guest-audio-original-wait*.json'):
 receipts.extend(p for p in WORKER.glob(pattern)if p.is_file())
receipts=sorted(set(receipts))
capsule=ROOT/'analysis/terminal-original-wait-receipts-v1-20261109.zip'
with zipfile.ZipFile(capsule,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in receipts:need(p.stat().st_size<1024*1024,'small receipts only');z.write(p,p.name)
 z.writestr('manifest.json',json.dumps([ident(p)for p in receipts],indent=2))
analysis=sorted((ROOT/'analysis').glob('terminal-original-wait-*'))
cutoff=datetime(2026,11,9,6,25,tzinfo=timezone.utc).timestamp()
files=[p for p in WORKER.rglob('*')if p.is_file()]
exclude={'worker.vmdk','chaomofa-worker.vmx','nvram','credentials.private.json'}
local=sorted(set([p for p in files if p.stat().st_mtime>=cutoff and p.name not in exclude]+[WORKER/'guest-system-dlls/ntoskrnl-5669b9b8bfcf.exe']))
need(all(p.stat().st_size<=50*1024*1024 for p in local),'no unplanned large evidence')
workerbytes=sum(p.stat().st_size for p in files);localbytes=sum(p.stat().st_size for p in local);analysisbytes=sum(p.stat().st_size for p in analysis)
prevworker=21907397595;prevtotal=21946638122;prevdisk=16601579520
sources=[]
for n in (1,2,3):
 p=WORKER/f'terminal-original-wait-etw-v{n}-20261109.json.gz'
 import gzip
 source=json.loads(gzip.decompress(p.read_bytes()))
 sources.append(dict(source=ident(p),native_process_seconds=source['duration_seconds'],observer_error=source['error'],lifecycle_error=source['lifecycle']['error'],forced_cleanup=source['lifecycle']['lifetime']['forced_termination'],ETL=source.get('ETL')))
report=dict(schema_version=1,kind='original_WOW64_single_wait_observation_closeout',created_utc=datetime.now(timezone.utc).isoformat(),baseline_commit=baseline,
 accepted=False,formal_progress='2/8 unchanged',new_full_battle_collections=0,new_fresh_native_full_replays=0,new_short_original_lifetimes=3,
 functional_endpoint='One actual original startup worker wait correlated to original Win32/Nt stack, current event/TLS and unique kernel NTSTATUS 0 return; latest source lacks actual CRT exit sample',
 sources=sources,offline_decodes=3,offline_v3_seconds=8.672,offline_v3_total_records=33527,offline_v3_selected_records=107,
 original_v3_strict_status='blocked before ETL read: no original CRT zero result receipt',original_v3_diagnostic_status='diagnostic_original_wait_observed_cleanup_unproven; guest CLI 2 / host nonzero',
 diagnostics_do_not_change_strict_contract=True,new_host_restore_branch='local tests plus independent code review only; actual old host runner retained in decoder implementation v3 capsule',
 host_restore_review=dict(reviewer='battle_gate',blocking_findings=[],single_scheduler_idle_guest_required=True,atomic_concurrent_create_claimed=False,native_validation=False,files=[ident(ROOT/p)for p in ('devtools/isolated_vm_original_wait_decode.py','devtools/tests/test_isolated_vm_original_wait_decode.py')]),
 unproved=dict(continuous_battle_wait_returns=False,result_consumption=False,complete_resource_PTD_cleanup=False,two_fresh_native_full_replays=False,independent_full_state_ABI_cumulative_replay=False),
 checks=dict(unit_test_runs=checks,strict_openspec='passed',main_raw_review=ident(WORKER/'original-wait-main-review-v1.json'),independent_review=ident(ROOT/'analysis/terminal-original-wait-review-v2-20261109.json'),vm_stop=ident(WORKER/'original-wait-vm-stop-v1.json'),host_input_sent=False,host_input_blocked=False,continuous_host_performance_unaffected_proved=False),
 preservation=preservation,retirement=retirement,evidence=[ident(p)for p in analysis],new_local_files_including_backups_scripts_logs=[ident(p)for p in local],
 storage=dict(worker_logical_bytes=workerbytes,previous_worker_logical_bytes=prevworker,worker_growth_bytes=workerbytes-prevworker,mutable_vmdk_bytes=(WORKER/'worker.vmdk').stat().st_size,mutable_vmdk_growth_bytes=(WORKER/'worker.vmdk').stat().st_size-prevdisk,newly_added_analysis_bytes=analysisbytes,new_local_bytes_including_backups_scripts_logs=localbytes,all_round_evidence_bytes_including_backups_scripts_logs=localbytes+analysisbytes,environment_existing_dependencies_and_prior_plus_new_analysis_bytes=prevtotal+workerbytes-prevworker+analysisbytes,new_local_selection='mtime >= 2026-11-09T06:25:00Z plus explicit new kernel duplicate; mutable VMDK/VMX/nvram counted as environment, secret credentials excluded from evidence manifest',guest_remaining_evidence='small preflight and retirement plan plus deployed source code; listed original-wait raw sources/ETL/logs/drivers retired',guest_contents_counted_in_vmdk=True,host_duplicate_retained_bytes=11597168,cleanup_complete=False,same_F_volume_copy_not_independent_disaster_recovery=True,report_itself_and_later_git_audit_outputs_excluded=True,evidence_budget_bytes=256*1024*1024),
 next_required='Continuous original user-mode state/ABI and actual result/resource/PTD lifetime evidence; do not start two formal long replays with this gap')
need(localbytes+analysisbytes<256*1024*1024,'evidence budget')
write(out,report)
print(json.dumps(dict(report=ident(out),storage=report['storage']),indent=2))
