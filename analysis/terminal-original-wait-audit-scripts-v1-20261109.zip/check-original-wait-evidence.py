import gzip,hashlib,json,struct,uuid,zipfile
from pathlib import Path
ROOT=Path('F:/project/chaomofa');WORKER=ROOT/'.venv-audit/native-worker'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def ident(p):return dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(p,data):
 with p.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
source=WORKER/'terminal-original-wait-etw-v3-20261109.json.gz'
proof=WORKER/'terminal-original-wait-decode-v3-diagnostic-20261109.json'
selected=WORKER/'terminal-original-wait-decode-v3-diagnostic-20261109.records.json.gz'
s=json.loads(gzip.decompress(source.read_bytes()));p=json.loads(proof.read_text());r=json.loads(gzip.decompress(selected.read_bytes()))['records']
need(p['status']=='diagnostic_original_wait_observed_cleanup_unproven' and not p['accepted'],'explicit diagnostic only')
need(not p['source_cleanup']['strict_source_cleanup_verified'],'CRT gap preserved')
need(not any(k in x for x in s['lifecycle']['shutdown'] for k in ('crt_exit',)),'no CRT receipt invented')
for path,row in ((source,p['source']),(selected,p['selected_records']),(WORKER/'terminal-original-wait-etw-v3-20261109/trace.etl',p['ETL'])):
 got=ident(path);need(all(got[k]==row[k]for k in ('bytes','sha256')),'source file identity')
active=None;pending=None;pairs=[];last=(-1,-1);tid=s['subject']['tid']
for i,e in enumerate(r):
 h=bytes.fromhex(e['record_header_hex']);b=bytes.fromhex(e['buffer_context_hex']);raw=bytes.fromhex(e['payload_hex'])
 need(len(h)==80 and len(b)==4,'raw event structure')
 ns=(struct.unpack_from('<q',h,16)[0]-116444736000000000)*100
 need(ns==e['ns'] and h[45]==e['opcode'] and str(uuid.UUID(bytes_le=h[24:40]))==e['guid'],'raw identity/time')
 need(struct.unpack_from('<II',h,8)==(e['tid'],e['pid']),'raw owner fields')
 cpu=int.from_bytes(b[:2],'little')if int.from_bytes(h[4:6],'little')&0x200 else b[0]
 need(cpu==e['cpu'] and cpu in (0,1) and e['index']>last[0] and ns>=last[1],'monotonic CPU records');last=e['index'],ns
 if h[45]==36:
  new,old=struct.unpack_from('<II',raw)
  need((new,old)==(e['data']['NewThreadId'],e['data']['OldThreadId']) and old==e['decoder_cpu_tid_before'],'raw switch fields')
  if old==tid:need(active==cpu,'switch out owner');active=None
  if new==tid:need(active is None,'no concurrent CPU');active=cpu
 else:
  need(active==cpu and e['decoder_cpu_tid_before']==tid,'raw whole-reader CPU attribution')
  if h[45]==51:
   need(pending is None and int.from_bytes(raw,'little')==e['data']['SysCallAddress'],'single pending/raw entry');pending=i
  else:
   need(h[45]==52 and len(raw)==4 and int.from_bytes(raw,'little')==e['data']['SysCallNtStatus'],'raw exit')
   need(pending is not None,'no interior unmatched exit');pairs.append((pending,i));pending=None
snap=s['owner_snapshots']['observed_wait'];lo,hi=snap['snapshot_begin_ns'],snap['snapshot_end_ns']
chosen=[(a,b)for a,b in pairs if r[a]['ns']<lo<=hi<r[b]['ns']]
need(len(chosen)==1,'unique actual wait');a,b=chosen[0]
need([a,b]==p['analysis']['selected_indices'] and r[a]['data']['SysCallAddress']==s['kernel_wait_export']['target'] and r[b]['data']['SysCallNtStatus']==0,'raw Nt wait pair')
def mem(address,size):
 chunks=[bytes.fromhex(z['hex'])[address-z['pointer']:address-z['pointer']+size]for z in snap['stack_regions']if z['pointer']<=address and address+size<=z['pointer']+len(bytes.fromhex(z['hex']))]
 need(chunks and len(set(chunks))==1,'unambiguous actual stack bytes');return chunks[0]
rawctx=bytes.fromhex(snap['frame']['context_hex']);eip=struct.unpack_from('<I',rawctx,184)[0];esp=struct.unpack_from('<I',rawctx,196)[0]
nt=next(e for e in s['API_exports']if e['name']=='NtWaitForSingleObject')
need(eip==nt['target']+12 and bytes.fromhex(nt['entry_hex'])[10:15]==bytes.fromhex('ffd2c20c00'),'actual suspended NT ret12')
handle,alert,timeout=struct.unpack('<III',mem(esp+4,12));node=bytes.fromhex(snap['node_hex'])
need((handle,alert,timeout)==(struct.unpack_from('<I',node,0x1c)[0],0,0),'raw current event/alertable/timeout')
api=next(x for x in snap['frame']['chain']if x['return_va']==0x42240d)
need(struct.unpack('<IIII',mem(api['bp'],16))[1:]==(0x42240d,handle,0xffffffff),'raw original wait args')
need(all(x['owner_verified_before_suspend'] and x['previous_suspend_count']==0 for z in s['owner_snapshots'].values() for x in (z['frame'],z['scheduler_frame'])),'all actual owner guards')
capsules={}
for name,mod in [('terminal-original-wait-implementation-v3-20261109.zip','devtools/terminal_original_wait_etw.py'),('terminal-original-wait-decoder-implementation-v3-20261109.zip','devtools/terminal_original_wait_etw_verification.py')]:
 path=ROOT/'analysis'/name
 with zipfile.ZipFile(path)as z:need(z.read(mod)==(ROOT/mod).read_bytes(),'exact executed implementation capsule')
 capsules[mod]=ident(path)
write(WORKER/'original-wait-main-review-v1.json',dict(accepted=False,method='Independent raw header/payload, CPU-flow, pairing and raw original/Nt stack recomputation; no verifier import',source=ident(source),proof=ident(proof),selected=ident(selected),records=len(r),closed_pairs=len(pairs),selected_indices=[a,b],final_partial_entry=pending,NTSTATUS=0,EventHandle=handle,Alertable=alert,Timeout=timeout,all_snapshot_owner_guards=True,source_CRT_zero_result_observed=False,fullABI=False,fullstate=False,PTDcleanup=False,capsules=capsules))
parent=ROOT/'analysis/reverse-validation-preservation-v1-20261106.json';baseline=json.loads(parent.read_text());bad=[]
for x in baseline['small_frozen_fresh_SHA']:
 path=ROOT/x['path'];got=ident(path)if path.exists()else{};
 if any(got.get(k)!=x[k]for k in ('bytes','sha256')):bad.append(x['path'])
large=baseline.get('large_size_only',baseline.get('large_frozen_size_only',[]))
need(large,'exact preservation large category needed')
for x in large:
 path=ROOT/x['path']
 if not path.exists()or path.stat().st_size!=x['bytes']:bad.append(x['path'])
write(WORKER/'original-wait-preservation-v1.json',dict(parent=ident(parent),small_fresh_SHA_count=len(baseline['small_frozen_fresh_SHA']),large_size_only_count=len(large),large_fresh_SHA=False,mismatches=bad))
need(not bad,'preservation differences')
print(json.dumps(dict(records=len(r),closed_pairs=len(pairs),selected_indices=[a,b],EventHandle=handle,NTSTATUS=0,preservation_small=len(baseline['small_frozen_fresh_SHA']),preservation_large=len(large),accepted=False)))
