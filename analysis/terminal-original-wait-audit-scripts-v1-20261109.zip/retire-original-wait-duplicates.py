import hashlib,json,sys
from pathlib import Path,PureWindowsPath
ROOT=Path('F:/project/chaomofa');sys.path.insert(0,str(ROOT))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script
def need(ok,msg):
 if not ok:raise ValueError(msg)
def write(p,data):
 with p.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
plan=WORKER/'original-wait-retirement-plan-v1.json';out=WORKER/'original-wait-retirement-result-v1.json'
need(not plan.exists()and not out.exists(),'fresh exact retirement records')
# Keep exactly one host original and one small repository recovery copy.
for pattern in ('terminal-original-wait-etw-*.json.gz','terminal-original-wait-decode-*.json','terminal-original-wait-decode-*.records.json.gz'):
 for p in WORKER.glob(pattern):
  if p.name.endswith('.run.json'):continue
  target=ROOT/'analysis'/p.name
  with target.open('xb')as f:f.write(p.read_bytes())
  need(target.read_bytes()==p.read_bytes(),'exact small recovery copy')
rows=[]
for pattern in ('terminal-original-wait-etw-*.json.gz','terminal-original-wait-decode-*.json','terminal-original-wait-decode-*.records.json.gz','terminal-original-wait-*.log','terminal-original-wait-*-driver.py'):
 for p in WORKER.glob(pattern):
  if p.name.endswith('.run.json'):continue
  parent='C:/ChaomofaWorker/project/analysis'if p.name.endswith(('.json','.json.gz'))else'C:/ChaomofaWorker'
  got=identity(p);rows.append(dict(guest=str(PureWindowsPath(parent)/p.name),kept=got,bytes=got['bytes'],sha256=got['sha256'],reason='exact redundant guest copy; host original retained, small evidence also has one repository recovery copy'))
for label in ('etw-v2-20261109','etw-v3-20261109'):
 p=WORKER/('terminal-original-wait-'+label)/'trace.etl';got=identity(p)
 rows.append(dict(guest=str(PureWindowsPath('C:/ChaomofaWorker/project/analysis')/p.parent.name/p.name),kept=got,bytes=got['bytes'],sha256=got['sha256'],reason='exact redundant guest ETL; single host original retained, no repository full ETL'))
old=WORKER/'guest-ntoskrnl.exe';new=WORKER/'guest-system-dlls/ntoskrnl-5669b9b8bfcf.exe'
oldid,newid=identity(old),identity(new)
need(oldid['sha256']==newid['sha256']=='5669b9b8bfcf20f08b7d1d65dc2deccbf836279c0e3f66722d72ad33ee7f672a'and oldid['bytes']==newid['bytes']==11597168,'exact preexisting kernel bytes retained')
host=dict(deleted=newid,kept=oldid,reason='new duplicate of preexisting identical guest kernel bytes; current kernel loading identity remains in fresh source')
write(plan,dict(guest=rows,host=[host]))
vmrun(['CopyFileFromHostToGuest',VMX,plan,PureWindowsPath('C:/ChaomofaWorker')/plan.name],guest=True)
script=r"""
$busy=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'tracerpt.exe'});if($busy.Count){throw 'Active collection/decoder'};
$plan=Get-Content -LiteralPath 'C:\ChaomofaWorker\original-wait-retirement-plan-v1.json' -Raw|ConvertFrom-Json;
$checked=@();foreach($r in $plan.guest){$full=[IO.Path]::GetFullPath($r.guest);$parent=[IO.Path]::GetDirectoryName($full);$name=[IO.Path]::GetFileName($full);
$allowed=($parent -eq 'C:\ChaomofaWorker' -and $name.StartsWith('terminal-original-wait-') -and ($name.EndsWith('.log') -or $name.EndsWith('-driver.py'))) -or ($parent -eq 'C:\ChaomofaWorker\project\analysis' -and $name.StartsWith('terminal-original-wait-') -and ($name.EndsWith('.json') -or $name.EndsWith('.json.gz'))) -or ($parent -in @('C:\ChaomofaWorker\project\analysis\terminal-original-wait-etw-v2-20261109','C:\ChaomofaWorker\project\analysis\terminal-original-wait-etw-v3-20261109') -and $name -eq 'trace.etl');
if(!$allowed){throw 'Outside exact current-run cleanup scope'};
if((Get-Item -LiteralPath $full).Length -ne $r.bytes -or (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Guest identity mismatch'};$checked+=$full};
$result=@();foreach($full in $checked){Remove-Item -LiteralPath $full;$result+=[pscustomobject]@{path=$full;deleted= -not(Test-Path -LiteralPath $full)}};$result|ConvertTo-Json -Compress
"""
guest=json.loads(run_script(script));need(len(guest)==len(rows)and all(x['deleted']for x in guest),'all exact guest duplicates retired')
need(new.resolve().parent==(WORKER/'guest-system-dlls').resolve()and identity(new)==newid and identity(old)==oldid,'exact host duplicate still bound')
new.unlink();need(not new.exists()and identity(old)==oldid,'only new duplicate removed')
result=dict(plan=identity(plan),guest_deleted=guest,host_deleted=[host],guest_removed_logical_bytes=sum(x['bytes']for x in rows),host_removed_logical_bytes=newid['bytes'],original_assets_saves_checkpoints_deleted=False,old_kernel_copy_unchanged=True,guest_deletion_does_not_imply_vmdk_shrink=True)
write(out,result)
print(json.dumps({k:v for k,v in result.items()if k not in ('guest_deleted','host_deleted')},indent=2))
