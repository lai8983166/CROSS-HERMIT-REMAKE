import json,sys
from pathlib import Path
ROOT=Path('F:/project/chaomofa');sys.path.insert(0,str(ROOT))
from devtools.isolated_windows_vm import WORKER,identity
from devtools.isolated_vm_guest_admin import run_script
p=WORKER/'original-wait-retirement-plan-v1.json';plan=json.loads(p.read_text())
script=r"""
$plan=Get-Content -LiteralPath 'C:\ChaomofaWorker\original-wait-retirement-plan-v1.json' -Raw|ConvertFrom-Json;
@($plan.guest|ForEach-Object{[pscustomobject]@{path=$_.guest;deleted= -not(Test-Path -LiteralPath $_.guest)}})|ConvertTo-Json -Compress
"""
guest=json.loads(run_script(script))
if len(guest)!=len(plan['guest'])or not all(x['deleted']for x in guest):raise ValueError('all guest duplicates absent')
for x in plan['guest']:
 if identity(Path(x['kept']['path']))!=x['kept']:raise ValueError('host original changed')
retained=[]
for x in plan['host']:
 if identity(Path(x['deleted']['path']))!=x['deleted']or identity(Path(x['kept']['path']))!=x['kept']:raise ValueError('retained duplicate identity mismatch')
 retained.append(dict(candidate=x['deleted'],retained_original=x['kept'],deleted=False,reason='Python unlink failed with WinError 5; subsequent exact PowerShell deletion rejected by automatic approval policy (blocked by policy), no more deletion attempts. Counted as retained same-volume duplicate.'))
result=dict(plan=identity(p),guest_deleted=guest,host_deleted=[],host_retained_duplicates=retained,guest_removed_logical_bytes=sum(x['bytes']for x in plan['guest']),host_removed_logical_bytes=0,original_assets_saves_checkpoints_deleted=False,old_kernel_copy_unchanged=True,guest_deletion_does_not_imply_vmdk_shrink=True,cleanup_complete=False)
with (WORKER/'original-wait-retirement-result-v1.json').open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items()if k not in ('guest_deleted','host_deleted','host_retained_duplicates')},indent=2))
