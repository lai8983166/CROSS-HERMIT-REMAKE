import json,sys
from pathlib import Path
ROOT=Path('F:/project/chaomofa');sys.path.insert(0,str(ROOT))
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
idle=run_script("$busy=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'tracerpt.exe'});if($busy.Count){throw 'guest busy'};'idle'").strip()
if idle!='idle':raise ValueError('guest not idle')
r=dict(guest_idle=True,soft_stop=vmrun(['stop',VMX,'soft'],timeout=60),running_vms=vmrun(['list']),vmem_files=[str(p)for p in WORKER.rglob('*.vmem')],host_input_actions=0)
with (WORKER/'original-wait-vm-stop-v1.json').open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r))
