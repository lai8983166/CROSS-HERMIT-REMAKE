from pathlib import Path
root=Path('F:/project/chaomofa')
source=(root/'devtools/isolated_vm_heap_probe_v2.py').read_text()
source=source.replace('"""Guarded dedicated-guest transport for the owned WOW64 heap capability."""',
    '"""Offline-only transport for complete retained heap schemas and records."""')
source=source.replace("def run(label,source_label=None):", "def run(label,source_label=None):\n    if source_label is None:raise ValueError('offline source required; never start helper')")
source=source.replace("'terminal_heap_etw_probe_v2.py',", "'terminal_heap_etw_probe_v2.py','terminal_heap_etw_decode_v3.py',")
source=source.replace("args=['devtools.terminal_heap_etw_probe_v2'", "args=['devtools.terminal_heap_etw_decode_v3'")
point="            if source_label is None:\n                folder=WORKER/stem;folder.mkdir()"
replacement="""            for key,suffix,limit in (('records','.records.json.gz',2*1024*1024),('schemas','.schemas.json.gz',256*1024)):
                if key not in data:continue
                expected=remote.with_suffix(suffix);local=out.with_suffix(suffix)
                checked_artifact(data[key],expected,limit)
                vmrun(['CopyFileFromGuestToHost',VMX,expected,local],guest=True)
                result[key]=transferred(data[key],local)
"""+point
if point not in source:raise ValueError('exact original retrieval point')
source=source.replace(point,replacement)
source=source.replace("        result['implementations_unchanged']=", "        result['inputs_unchanged']=(sid,eid)==(identity(source),identity(etl))\n        result['implementations_unchanged']=")
source=source.replace("or not r['implementations_unchanged']else 0", "or not r['implementations_unchanged']or not r['inputs_unchanged']else 0")
with (root/'devtools/isolated_vm_heap_decode_v3.py').open('xb')as f:f.write(source.encode())
