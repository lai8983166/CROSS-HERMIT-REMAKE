"""Main-agent independent raw inspection of the delegated finite heap verifier."""
import gzip,hashlib,json,struct
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def need(x,msg):
    if not x:raise ValueError(msg)
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
paths=[W/'terminal-heap-capability-v2-20261109.json',W/'terminal-heap-capability-v2-20261109/trace.etl',W/'terminal-heap-decode-v3-20261109.records.json.gz',W/'terminal-heap-decode-v3-20261109.schemas.json.gz',R/'analysis/terminal-heap-capability-proof-v1-20261109.json']
expected=['ea64989c04abfe59cb71216341192ec36025d3a312ec83754d48e9b96bc8c56a','11ebdae815e9fa7d4c0e59e0e617af45268ea99b3f49f17ee44469067030792f','0ab457945075d0ac361a63234bcbec298ff5acee0f173d0839be3641c30fc3cd','3ea4c968861c159cdbe09849e0be331c452c0c1f2b2ca2163cf6381d60e936f8','469347d4b5ec15bb7a42efe470deeaf6f935ec1dd563c057f44af405e7358089']
refs=[ident(p)for p in paths];need([r['sha256']for r in refs]==expected,'fixed actual source/trace/metadata/proof')
s=json.loads(paths[0].read_bytes());rows=json.loads(gzip.decompress(paths[2].read_bytes()))['records'];schemas=json.loads(gzip.decompress(paths[3].read_bytes()))['schemas'];proof=json.loads(paths[4].read_bytes())
need(len(rows)==180 and len(schemas)==6,'complete retained event/schema set')
own=[];foreign=[]
for row in rows:
    h=bytes.fromhex(row['header_hex']);p=bytes.fromhex(row['payload_hex']);tid,pid=struct.unpack_from('<II',h,8);t=struct.unpack_from('<q',h,16)[0];op=h[45];version=h[42]
    need((tid,pid,t,op,version)==(row['tid'],row['pid'],row['FILETIME'],row['opcode'],row['version']),'header attribution')
    need(b''.join(bytes.fromhex(x['hex'])for x in row['TDH_properties'])==p,'all raw payload bytes independently match TDH retrieval')
    if pid!=6092:
        props={x['name']:int.from_bytes(bytes.fromhex(x['hex']),'little')for x in row['TDH_properties']}
        need(op==38 and version==3 and props['ProcessId']==6092,'foreign records only target-payload statistics')
        foreign.append(dict(index=row['index'],header_pid=pid,payload_pid=props['ProcessId']))
    if op in (32,33,36)and struct.unpack_from('<I',p)[0]==91881472:
        need(pid==6092 and tid==2948 and s['helper']['live']['begin_filetime']<=t<=s['helper']['live']['end_filetime'],'original own helper operation')
        own.append(dict(index=row['index'],opcode=op,payload_dwords=list(struct.unpack('<'+'I'*(len(p)//4),p))))
need([x['index']for x in own]==[117,226,228,338]and[x['opcode']for x in own]==[32,33,33,36],'exact original finite sequence')
need(own[1]['payload_dwords'][:3]==[91881472,152,91882936]and own[2]['payload_dwords'][:3]==[91881472,296,91883096]and own[3]['payload_dwords'][:2]==[91881472,91882936],'actual allocation and free payload fields')
need(len(foreign)==4 and not any(x['opcode']==36 and x['payload_dwords'][1]==91883096 for x in own),'retained-live counterexample has no premature free')
need(proof['finite_owned_WOW64_heap_capability']and all(proof[k]is False for k in ['accepted','original_game','fullABI','fullstate','PTDcleanup','caller_stack_verified']),'finite capability never grants original-game acceptance')
out=dict(kind='main_agent_independent_heap_raw_review',references=refs,owned_heap_events=own,foreign_headers_preserved=foreign,passed=True,
    reviewed_code=['devtools/terminal_heap_etw_verification.py','devtools/tests/test_terminal_heap_etw_verification.py'],
    scope='Main agent independently checks delegated verifier against raw headers and payloads without importing it. Agent review separately covers main context/inventory implementation. Helper BOOL is separate from heap events; original-game cleanup and caller stacks unproved.',
    accepted=False,original_game=False,fullABI=False,PTDcleanup=False)
with (R/'analysis/terminal-heap-main-independent-review-v1-20261109.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print(json.dumps(dict(passed=True,owned_events=4,raw_heap_events=180,foreign_statistics=4,accepted=False)))
