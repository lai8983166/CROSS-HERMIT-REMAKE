import hashlib,json,zipfile
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
names=['prepare-context-checks.py','prepare-context-retirement.py','retire-context-heap-transfers-v1.py',
       'inventory-context-guest-v1.py','check-context-heap-v1.py','check-context-preservation.py',
       'review-context-heap-main-v1.py','closeout-context-heap-v1.py','package-context-heap-v1.py',
       'prepare-heap-decode-v3-transport.py','battle-wait-unit-checks-context-heap-v1-20261109.json',
       'battle-wait-preservation-context-heap-v1-20261109.json','battle-wait-guest-storage-context-heap-v1-20261109.json',
       'battle-wait-guest-transfer-retirement-context-heap-v1-20261109.json','preflight-context-v1-20261109.json']
out=R/'analysis/terminal-battle-wait-context-heap-support-v1-20261109.zip'
rows=[]
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name in names:
        p=W/name;raw=p.read_bytes();z.writestr(name,raw)
        rows.append(dict(member=name,path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    z.writestr('manifest.json',json.dumps(dict(scope='current incremental helpers and small receipts; original native sources remain on F and are referenced in closeout',files=rows),indent=2))
print(json.dumps(dict(path=out.relative_to(R).as_posix(),bytes=out.stat().st_size,members=len(rows)+1)))
