from pathlib import Path
w=Path('F:/project/chaomofa/.venv-audit/native-worker')
s=(w/'check-battle-wait-gaps-v1.py').read_text().replace('rows=[]', "names += ['terminal_battle_wait_context','terminal_battle_wait_context_review','terminal_battle_result_inventory','terminal_heap_etw_probe','terminal_heap_etw_probe_v2','terminal_heap_etw_decode_v3','terminal_heap_etw_verification']\nrows=[]")
(w/'check-context-heap-v1.py').write_text(s)
s=(w/'check-battle-wait-preservation-v3.py').read_text().replace('battle-wait-preservation-v3.json','battle-wait-preservation-context-heap-v1-20261109.json')
(w/'check-context-preservation.py').write_text(s)
s=(w/'inventory-battle-wait-guest-clock-v1.py').read_text().replace('2026-11-09T11:41:37Z','2026-11-09T13:09:08Z').replace('storage-clock-v1','storage-context-heap-v1').replace("$_.Name -like 'python*'", "$_.Name -like 'python*' -or $_.Name -eq 'heap-fixture.exe'")
(w/'inventory-context-guest-v1.py').write_text(s)
