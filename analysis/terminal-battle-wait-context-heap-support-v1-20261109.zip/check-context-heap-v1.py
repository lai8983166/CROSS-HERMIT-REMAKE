import json,subprocess,sys,time
from pathlib import Path
root=Path('F:/project/chaomofa');sys.path.insert(0,str(root))
from devtools.isolated_windows_vm import WORKER,environment
names=['terminal_battle_wait_diagnostic','terminal_battle_wait_verification_v4','terminal_battle_wait_verification_v3','terminal_battle_wait_window_v2','terminal_factory_focus_verification','terminal_factory_focus','terminal_worker_retention_verification_v2','terminal_worker_retention_v2','terminal_worker_retention_v3','terminal_worker_retention_verification','terminal_battle_wait_verification_v2','terminal_worker_retention','terminal_battle_wait_window','terminal_battle_wait_capture','terminal_battle_wait_verification','isolated_vm_battle_wait','terminal_original_wait_etw','terminal_original_wait_etw_verification','isolated_vm_original_wait_decode','isolated_guest_focus','isolated_vm_boot_watch','isolated_vm_preflight','isolated_windows_vm',
       'native_input_isolation','terminal_battle_input','terminal_battle_notice','terminal_notice_verification',
       'terminal_story_dispatch_verification','terminal_debug_relay','terminal_wait_native_verification',
       'terminal_wait_observer_gate','terminal_exit_cleanup_contract','terminal_wait_etw_probe',
       'terminal_owned_mouse','terminal_input_window','terminal_school_handoff','terminal_school_handoff_verification',
       'terminal_school_input','terminal_school_preparation_contract','terminal_story_catalog','terminal_workroom_input']
names += ['terminal_battle_wait_clock','terminal_battle_wait_clock_review','terminal_battle_wait_gap_audit','terminal_ptd_evidence_inventory','terminal_battle_wait_clock_settled','isolated_vm_autologon']
names += ['terminal_battle_wait_context','terminal_battle_wait_context_review','terminal_battle_result_inventory','terminal_heap_etw_probe','terminal_heap_etw_probe_v2','terminal_heap_etw_decode_v3','terminal_heap_etw_verification']
rows=[]
for optimized in (False,True):
    cmd=[sys.executable,'-B']+(['-O']if optimized else [])+['-X','utf8','-m','unittest']
    cmd+=['devtools.tests.test_'+n for n in names];start=time.monotonic()
    r=subprocess.run(cmd,cwd=root,env=environment(),text=True,capture_output=True,timeout=180)
    row=dict(optimized=optimized,returncode=r.returncode,elapsed=time.monotonic()-start,output=r.stdout+r.stderr)
    rows.append(row);print(row['output'],flush=True)
    if r.returncode:break
out=WORKER/('battle-wait-unit-checks-'+sys.argv[1]+'.json')
with out.open('x',encoding='utf8')as f:json.dump(rows,f,indent=2)
if len(rows)!=2 or any(r['returncode']for r in rows):raise SystemExit(1)
