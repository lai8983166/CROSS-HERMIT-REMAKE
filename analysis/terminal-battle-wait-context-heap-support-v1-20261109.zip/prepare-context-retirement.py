from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
s=(W/'retire-battle-wait-transfers-v2.py').read_text()
s=s.replace("for p in sorted(W.glob('terminal-battle-wait-*')):","""stems=['terminal-battle-wait-window-context-v1-20261109',
           'terminal-battle-wait-decode-context-utc-v1-20261109','terminal-battle-wait-decode-context-raw-v1-20261109',
           'terminal-heap-capability-v1-20261109','terminal-heap-capability-v2-20261109',
           'terminal-heap-decode-v2-20261109','terminal-heap-decode-v3-20261109']
    for p in sorted({p for stem in stems for p in W.glob(stem+'*')}):""")
s=s.replace("child=p/'trace.etl'\n            if child.exists():rows.append(dict(guest='C:/ChaomofaWorker/project/analysis/'+p.name+'/trace.etl',retained_host=ident(child)))", 
"""for name in ('trace.etl','heap-fixture.exe'):
                child=p/name
                if child.exists():rows.append(dict(guest='C:/ChaomofaWorker/project/analysis/'+p.name+'/'+name,retained_host=ident(child)))""")
s=s.replace("(p.name.startswith('terminal-battle-wait-decode-')and p.name.endswith('.json')and not p.name.endswith('.run.json'))",
"(p.name.startswith(('terminal-battle-wait-decode-','terminal-heap-'))and p.name.endswith('.json')and not p.name.endswith('.run.json'))")
with (W/'retire-context-heap-transfers-v1.py').open('xb')as f:f.write(s.encode())
