"""Inventory the bounded context/heap increment, with all formal gates closed."""
import hashlib,json,subprocess,zipfile
from datetime import datetime,timezone
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
LABEL='context-heap-v1-20261109'
def read(p):return json.loads(p.read_bytes())
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
if list(W.rglob('*.vmem')):raise ValueError('live VM memory remains')
tests_path=W/f'battle-wait-unit-checks-{LABEL}.json';tests=read(tests_path)
if len(tests)!=2 or any(x['returncode']or 'Ran 478 tests'not in x['output']for x in tests):raise ValueError('required ordinary and optimized regressions')
guest_path=W/f'battle-wait-guest-storage-{LABEL}.json';guest=read(guest_path)
cleanup_path=W/f'battle-wait-guest-transfer-retirement-{LABEL}.json';cleanup=read(cleanup_path)
if guest['game_and_python_processes']or not cleanup['all_removed']:raise ValueError('guest idle and cleanup required')
for row in cleanup['removed']:
    if row['guest']in {x['path'].replace('\\','/')for x in guest['files']}:raise ValueError('retired copy remains')
context=R/'analysis/terminal-battle-wait-context-review-v1-20261109.json'
heap=R/'analysis/terminal-heap-capability-proof-v1-20261109.json'
independent=R/'analysis/terminal-heap-capability-independent-review-v1-20261109.json'
if not independent.is_file():raise ValueError('independent review required')
if not read(heap)['finite_owned_WOW64_heap_capability']or read(heap)['accepted']:raise ValueError('finite helper scope only')
parent=R/'analysis/terminal-battle-wait-clock-closeout-v1-20261109.json';prior=read(parent)
paths=[x for x in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=A','-z'],cwd=R).decode().split('\0')if x]
analysis=[ident(R/p)for p in paths if p.startswith('analysis/')]
files=[];environment=[];worker_bytes=0
for p in W.rglob('*'):
    if not p.is_file():continue
    st=p.stat();worker_bytes+=st.st_size
    if st.st_mtime<1794229748:continue
    if p.suffix.lower()in {'.vmdk','.vmem','.vmx','.vmxf','.nvram','.vmsd','.vmss','.lck'}or p.name.startswith('vmware'):
        environment.append(dict(path=p.relative_to(R).as_posix(),bytes=st.st_size));continue
    if 'credentials'in p.name.lower()or '.private.'in p.name.lower():continue
    if st.st_size>256*1024*1024:raise ValueError('large unclassified current file '+str(p))
    files.append(ident(p))
disk_bytes=sum(p.stat().st_size for p in W.glob('*.vmdk'))
report=dict(kind='complete_context_and_finite_heap_capability_increment',created_utc=datetime.now(timezone.utc).isoformat(),parent=ident(parent),
    accepted=False,formal_tasks_completed=2,formal_tasks_total=8,fullABI=False,fullstate=False,PTDcleanup=False,
    continuous_result_consumption_proved=False,full_resource_lifetime_proved=False,two_fresh_full_native_cases_verified=False,
    progress=dict(context_attempts=225,raw_716_byte_pairs_equal=450,data_only_off_CPU_intervals=224,
        complete_worker_context_intervals_qualified=0,complete_worker_intervals_with_switches=224,
        switches_in_complete_worker_intervals=888,distinct_waits=61,
        old_school_context_references=198,distinct_elapsed_and_context_digest_pairs=169,saved_consumer_return_references=191,
        old_window_current_Nt_return_contexts=423,actual_consumer_EIP_observations=0,
        finite_owned_WOW64_heap_capability=True,heap_total_events=349,heap_events=180,actual_TDH_schemas=6,
        helper_allocation_sizes=[152,296],helper_first_allocation_free_verified=True,helper_second_allocation_live_until_trace_stop=True,
        foreign_header_statistics=4,caller_stack_verified=False,original_game_heap_cleanup_verified=False),
    references=[ident(context),ident(heap),ident(independent),ident(R/'analysis/terminal-heap-main-independent-review-v1-20261109.json'),ident(R/'analysis/terminal-battle-wait-context-independent-review-v1-20261109.json'),ident(R/'analysis/terminal-battle-wait-result-inventory-v1-20261109.json')],
    limitations=['equal complete contexts are endpoints, not a continuous instruction/full-state proof',
        'all complete worker context brackets cross real scheduler events; old data-only gate cannot qualify these brackets',
        'saved consumer return sites and pending syscall EAX are not executing consumers or eventual return values',
        'heap helper is a separate native lifetime, not the original game; event and BOOL receipts remain separate',
        'original caller stacks, free ABI, TLS clear, PTD, handle and scene resource cleanup remain unproved'],
    efficiency=dict(new_full_battle_prefix_attempts=0,new_formal_full_replays=0,new_native_game_short_captures=1,
        game_short_capture_seconds=17.594,new_heap_helper_captures=1,heap_capture_seconds=1.047,
        heap_v1_path_failure_before_native_capture=True,heap_v2_schema_failure_reused_same_ETL_in_v3=True,
        prior_battle_evidence_reused=True,complete_path_speedup_claimed=False),
    tests=dict(receipt=ident(tests_path),ordinary_count=478,optimized_count=478,ordinary_seconds=tests[0]['elapsed'],optimized_seconds=tests[1]['elapsed'],passed=True),
    preservation=read(W/f'battle-wait-preservation-{LABEL}.json'),strict_OpenSpec_valid=True,
    host_evidence_files=files,analysis_evidence_files_before_closeout=analysis,guest_inventory=ident(guest_path),guest_retained_files=guest['files'],
    cleanup=dict(receipt=ident(cleanup_path),guest_duplicate_files_removed=len(cleanup['removed']),guest_duplicate_bytes_removed=cleanup['total_bytes'],
        host_originals_retained=True,historical_sources_removed=False,previous_kernel_duplicate_retained_bytes=11597168,
        previous_kernel_duplicate_deletion='previous rejection; excluded and not retried'),
    environment=dict(host_drive='F',guest_logical_C_inside_F_disk=True,cpu=2,memory_bytes=guest['memory'],VM_soft_stopped=True,VMEM_files_remaining=0,
        guest_game_python_and_heap_helper_processes_before_shutdown=0,host_interactive_input_used=False,
        continuous_host_performance_unaffected_proved=False,VM_disk_bytes=disk_bytes,baseline_VM_disk_bytes=prior['environment']['VM_disk_bytes'],
        VM_disk_growth_bytes=disk_bytes-prior['environment']['VM_disk_bytes'],baseline_worker_logical_bytes=prior['environment']['worker_logical_bytes_at_inventory'],
        worker_logical_bytes_at_inventory=worker_bytes,mutable_environment_files=environment),
    storage_scope='All new local evidence since parent commit 2026-11-09T13:09:08Z: F-drive source/ETL/records, reports, helpers, primary source references, capsules and guest retained copies. Mutable VM environment growth is separate; repository implementation is counted in Git. No private credentials included.',
    same_disk_backup_is_independent_disaster_recovery=False,staged_code_and_evidence_equal_executed_bytes=True,private_credential_scan_passed=True,
    host_new_evidence_bytes_including_closeout=0,total_new_local_evidence_bytes_including_guest_and_backups=0,Git_added_file_bytes_including_closeout=0,closeout_bytes=0)
base=sum(x['bytes']for x in files+analysis);git_base=sum((R/p).stat().st_size for p in paths)
for _ in range(12):
    report['host_new_evidence_bytes_including_closeout']=base+report['closeout_bytes']
    report['total_new_local_evidence_bytes_including_guest_and_backups']=base+report['closeout_bytes']+guest['remaining_current_round_guest_files_bytes']
    report['Git_added_file_bytes_including_closeout']=git_base+report['closeout_bytes']
    raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
    if len(raw)==report['closeout_bytes']:break
    report['closeout_bytes']=len(raw)
else:raise ValueError('manifest size did not stabilize')
if report['total_new_local_evidence_bytes_including_guest_and_backups']>256*1024*1024:raise ValueError('evidence budget exceeded')
out=R/'analysis/terminal-battle-wait-context-heap-closeout-v1-20261109.json'
with out.open('xb')as f:f.write(raw)
print(json.dumps(dict(report=ident(out),local_evidence_bytes=report['total_new_local_evidence_bytes_including_guest_and_backups'],Git_added_file_bytes=report['Git_added_file_bytes_including_closeout'],VM_disk_growth_bytes=report['environment']['VM_disk_growth_bytes'])))
