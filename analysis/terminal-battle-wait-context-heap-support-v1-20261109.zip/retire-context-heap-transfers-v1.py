"""Bounded transport requests; exact guest duplicate files only."""
import base64,hashlib,json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
W=R/'.venv-audit/native-worker'
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
idle="$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*'});if($p.Count){throw 'guest busy'};"
def request(rows,remove=False):
    encoded=base64.b64encode(json.dumps(rows).encode()).decode()
    script=idle+"$rows=ConvertFrom-Json ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+encoded+r"')));$out=@();$checked=@();foreach($r in $rows){$p=$r.guest;if(Test-Path -LiteralPath $p -PathType Leaf){$f=Get-Item -LiteralPath $p;$hash=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant();if($f.Length -ne $r.retained_host.bytes -or $hash -ne $r.retained_host.sha256){throw 'identity mismatch'};$full=(Resolve-Path -LiteralPath $p).Path;if($full -ne $p.Replace('/','\') -or !$full.StartsWith('C:\ChaomofaWorker\') -or $full.Contains('..')){throw 'target escaped'};$checked+=$full;$out+=[pscustomobject]@{guest=$p;resolved_guest=$full;bytes=$f.Length;sha256=$hash}}else{"
    script+=("throw 'missing checked duplicate'" if remove else "")+"}};"
    if remove:script+="foreach($p in $checked){Remove-Item -LiteralPath $p -Force;if(Test-Path -LiteralPath $p){throw 'removal failed'}};"
    script+="ConvertTo-Json -InputObject @($out) -Depth 4 -Compress"
    if len(script)>2700:raise ValueError('bounded transport script')
    result=json.loads(run_script("try {"+script+"} catch { [pscustomobject]@{failure=$_.Exception.Message}|ConvertTo-Json -Compress }"))
    if isinstance(result,dict) and 'failure'in result:raise ValueError(result['failure'])
    return result
label=sys.argv[1];apply='--apply'in sys.argv[2:]
plan=R/f'analysis/terminal-battle-wait-guest-transfer-retirement-{label}.json'
if not apply:
    rows=[]
    stems=['terminal-battle-wait-window-context-v1-20261109',
           'terminal-battle-wait-decode-context-utc-v1-20261109','terminal-battle-wait-decode-context-raw-v1-20261109',
           'terminal-heap-capability-v1-20261109','terminal-heap-capability-v2-20261109',
           'terminal-heap-decode-v2-20261109','terminal-heap-decode-v3-20261109']
    for p in sorted({p for stem in stems for p in W.glob(stem+'*')}):
        if p.is_dir():
            for name in ('trace.etl','heap-fixture.exe'):
                child=p/name
                if child.exists():rows.append(dict(guest='C:/ChaomofaWorker/project/analysis/'+p.name+'/'+name,retained_host=ident(child)))
        elif p.name.endswith(('.json.gz','.log','-driver.py')) or (p.name.startswith(('terminal-battle-wait-decode-','terminal-heap-'))and p.name.endswith('.json')and not p.name.endswith('.run.json')):
            parent='C:/ChaomofaWorker/'if p.name.endswith(('.log','-driver.py'))else'C:/ChaomofaWorker/project/analysis/'
            rows.append(dict(guest=parent+p.name,retained_host=ident(p)))
    actual=[]
    for row in rows:actual+=request([row])
    bypath={x['guest']:x for x in actual};rows=[dict(r,resolved_guest=bypath[r['guest']]['resolved_guest'])for r in rows if r['guest']in bypath]
    data=dict(kind='exact_current_round_guest_transport_retirement',rows=rows,total_bytes=sum(r['retained_host']['bytes']for r in rows),host_files_removed=False,historical_sources_or_assets_removed=False,original_kernel_duplicate_excluded=True,reason='exact current-round transport duplicates; host originals retained on F',execution='pending')
    with plan.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
    print(json.dumps(dict(plan=ident(plan),files=len(rows),bytes=data['total_bytes'])))
else:
    data=json.loads(plan.read_text());rows=data['rows']
    for row in rows:
        if ident(R/row['retained_host']['path'])!=row['retained_host']:raise ValueError('retained original changed')
    # Check every guest identity before removing any; recheck again in each removal batch.
    for row in rows:
        if len(request([row]))!=1:raise ValueError('guest missing before cleanup')
    removed=[]
    for row in rows:removed+=request([row],True)
    out=W/f'battle-wait-guest-transfer-retirement-{label}.json'
    result=dict(plan=ident(plan),removed=removed,total_bytes=data['total_bytes'],host_originals_retained=True,all_removed=True)
    with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(receipt=ident(out),files=len(removed),bytes=data['total_bytes'])))
