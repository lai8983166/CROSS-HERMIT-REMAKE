"""Bounded serial-controlled VM; WinPE copy-only seed, then a fresh Windows child."""
import argparse,json,os,signal,socket,subprocess,threading,time
from pathlib import Path
from devtools.terminal_tcg_roundtrip_probe import QMP,identity

def run(mode,out):
    out=out.resolve();root=Path(__file__).resolve().parents[1];w=root/'.venv-audit/native-worker'
    if not str(out).startswith('/mnt/f/')or(out/'report.json').exists():raise ValueError('fresh F case')
    manifest=json.loads((w/'tcg-context-build-v1/manifest.json').read_bytes());binary=Path(manifest['binary']['path'])
    if identity(binary)['sha256']!=manifest['binary']['sha256']:raise ValueError('runtime identity')
    parent_manifest=Path(manifest['parent_manifest']['path'])
    if identity(parent_manifest)['sha256']!=manifest['parent_manifest']['sha256']:raise ValueError('parent build identity')
    v4=json.loads(parent_manifest.read_bytes());v3path=Path(v4['parent_manifest']['path'])
    if identity(v3path)['sha256']!=v4['parent_manifest']['sha256']:raise ValueError('CR2 parent build identity')
    for row in json.loads(v3path.read_bytes())['overlay']+[v4['new_header'],manifest['backend'],manifest['builder']]+[c['overlay'] for c in manifest['compilation']]:
        if identity(Path(row['path']))['sha256']!=row['sha256']:raise ValueError('runtime source identity')
    gate_path=w/'tcg-context-preflight-v4/proof.json'
    gate=json.loads(gate_path.read_bytes())
    if gate.get('preflight_passed') is not True or gate.get('binary_sha256')!=manifest['binary']['sha256']:raise ValueError('context preflight admission')
    if mode=='seed':
        parent=w/'tcg-wait-native-v10/disk.qcow2';expected=json.loads((w/'tcg-wait-native-v10/report.json').read_bytes())['overlay'];limit=600
    else:
        parent=w/'tcg-serial-seed-v2/disk.qcow2';seed=json.loads((w/'tcg-serial-seed-v2/seed-verification.json').read_bytes())
        if seed.get('verified')is not True:raise ValueError('verified offline payload required')
        expected=seed['overlay'];limit=900
    if identity(parent)['sha256']!=expected['sha256']:raise ValueError('fixed parent SHA')
    fixed={'tcg-windows-compat-v2':'6ca705a9ed38e206d6963dbd7bc3a40706dc6ade3eb0af2c804ccdf9b0556df4','tcg-windows-current-v1':'4793ea281b842ddc8efcdc0616ade3b33ee5b83bc9cf6970ab5c564a856db138','tcg-wait-native-v5':'49d282cfb517b8aa323271da446c94e6235b503a6ed74954de62d55c8a8c8efe','tcg-wait-native-v10':'5b0b7c52167ba6004a1bbc9e0b98f143a2e2ede786bc5ddf65bd9321b90651a1'}
    for name,sha in fixed.items():
        if identity(w/name/'disk.qcow2')['sha256']!=sha:raise ValueError('fixed ancestor '+name)
    build=json.loads((w/'tcg-serial-agent-build-v2/manifest.json').read_bytes())
    if identity(root/'devtools/terminal_tcg_serial_agent_v2.cs')['sha256']!='71a4bd15730e7f659b40b3b8fea5fabb2dee19d3e8e517daf5b3f1ebee5a69eb':raise ValueError('fixed agent source')
    if identity(w/'tcg-serial-agent-build-v2/agent.exe')['sha256']!=build['executable']['sha256'] or build['executable']['sha256']!='9d9c7712fd8e68024dd6394e1ab6f2333e8af4e01ded9d284a66f6a0632cba8a':raise ValueError('fixed agent executable')
    if mode=='run':
        for row in seed['sources']:
            name=row['path'].replace(chr(92),'/').split('/')[-2]
            if identity(w/name/'disk.qcow2')['sha256']!=row['sha256']:raise ValueError('seed source binding')
        if next(row for row in seed['files'] if row['path'].endswith('/agent.exe'))['sha256']!=build['executable']['sha256']:raise ValueError('seed build binding')

    parents=[w/'worker.vmdk',w/'tcg-windows-compat-v2/disk.qcow2',w/'tcg-windows-current-v1/disk.qcow2',w/'tcg-wait-native-v5/disk.qcow2',w/'tcg-wait-native-v10/disk.qcow2']
    if mode!='seed':parents.append(parent)
    before=[(p.stat().st_size,p.stat().st_mtime_ns)for p in parents]
    disk=out/'disk.qcow2'
    if disk.exists():raise ValueError('fresh overlay')
    subprocess.run(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(parent),str(disk)],check=True,capture_output=True,timeout=15)
    qp='chaomofa-'+out.name+'-qmp'
    cmd=[str(binary),'-L',str(w/'qemu-worker/runtime/share'),'-machine','pc','-accel','tcg,thread=single','-smp','2','-m','4G','-uuid','626d1a20-6383-4cd3-85d5-6c9831d6f941','-display','none','-monitor','none','-no-reboot','-nic','none','-device','e1000e,mac=52:54:00:12:34:56,romfile=',
         '-device','mptsas1068,id=scsi0','-drive','file='+str(disk)+',if=none,id=os,format=qcow2','-device','scsi-hd,drive=os,bus=scsi0.0','-qmp','unix:'+qp+',abstract=on,server=on,wait=off']
    if mode=='seed':
        media=w/'SERVER_EVAL_x64FRE_en-us.iso'
        if media.stat().st_size!=5044094976:raise ValueError('recorded original media size')
        cmd+=['-serial','none','-cdrom',str(media),'-drive','file='+str(out/'seed.private.flp')+',if=floppy,format=raw','-boot','order=d,menu=off']
    else:cmd+=['-chardev','socket,id=cmf,host=127.0.0.1,port=15988,server=on,wait=off','-serial','chardev:cmf']
    r=dict(accepted=False,mode=mode,binary=identity(binary),parent=expected,command=cmd,host_input_actions=0,virtual_boot_key_actions=0,errors=[]);p=q=None;done=threading.Event();started=time.monotonic()
    def watchdog():
        while not done.wait(.1):
            if time.monotonic()-started>limit or disk.stat().st_size>128*1024**2:
                r['errors'].append('wall/128MiB budget')
                if p and p.poll()is None:os.killpg(p.pid,signal.SIGKILL)
                return
    threading.Thread(target=watchdog,daemon=True).start()
    try:
        with(out/'stderr.log').open('xb')as log:
            p=subprocess.Popen(['nice','-n','10']+cmd,stdout=log,stderr=log,start_new_session=True)
            for _ in range(80):
                if p.poll()is not None:raise RuntimeError('early VM exit')
                try:q=QMP(qp);break
                except(FileNotFoundError,ConnectionRefusedError):time.sleep(.1)
            if q is None:raise RuntimeError('QMP readiness')
            (out/'vm-ready.json').write_text(json.dumps(dict(mode=mode,pid=p.pid,qmp=qp,serial_port=15988 if mode=='run'else None)))
            if mode=='seed':
                time.sleep(2);q.call('screendump',{'filename':str(out/'boot-prompt.ppm')})
                r['boot_key']=q.call('send-key',{'keys':[{'type':'qcode','data':'ret'}],'hold-time':50});r['virtual_boot_key_actions']=1
            q.f.close();q.s.close();q=None
            capture_at=150 if mode=='seed'else 240;captured=False
            while p.poll()is None and time.monotonic()-started<limit-10 and not(out/'vm-stop').exists():
                if not captured and time.monotonic()-started>=capture_at:
                    q=QMP(qp);q.call('screendump',{'filename':str(out/'boot.ppm')});q.f.close();q.s.close();q=None;captured=True
                time.sleep(.2)
            if p.poll()is None:
                q=QMP(qp);r['quit']=q.call('quit');p.wait(timeout=5)
            else:r['guest_poweroff']=p.returncode==0
    except Exception as e:r['errors'].append(type(e).__name__+': '+str(e))
    finally:
        done.set()
        if p and p.poll()is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
        if q:q.f.close();q.s.close()
        r.update(seconds=time.monotonic()-started,process_exited=p is None or p.poll()is not None,parent_size_mtime_unchanged=before==[(x.stat().st_size,x.stat().st_mtime_ns)for x in parents],overlay=identity(disk))
        (out/'report.json').write_text(json.dumps(r,indent=2))
    print(json.dumps({k:r[k]for k in ('mode','seconds','errors','process_exited','parent_size_mtime_unchanged')}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['seed','run']);p.add_argument('output',type=Path);a=p.parse_args();run(a.mode,a.output)
