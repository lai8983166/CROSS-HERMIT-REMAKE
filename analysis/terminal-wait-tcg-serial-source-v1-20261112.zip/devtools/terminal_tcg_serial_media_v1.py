"""Create private F-drive WinPE seed media; never install or repartition Windows."""
import hashlib,json,secrets,xml.etree.ElementTree as ET
from pathlib import Path
from devtools.isolated_windows_vm import WORKER,identity
STARTUP=b'@echo off\r\nstart "" /b "C:\\ChaomofaWorker\\SerialV1\\agent.exe"\r\nexit /b 0\r\n'
def answer():
 ns='urn:schemas-microsoft-com:unattend';wcm='http://schemas.microsoft.com/WMIConfig/2002/State';ET.register_namespace('',ns);ET.register_namespace('wcm',wcm)
 def tag(p,n,text=None,attrs=None):
  e=ET.SubElement(p,'{'+ns+'}'+n,attrs or {});e.text=text;return e
 root=ET.Element('{'+ns+'}unattend');settings=tag(root,'settings',attrs={'pass':'windowsPE'})
 common=dict(processorArchitecture='amd64',publicKeyToken='31bf3856ad364e35',language='neutral',versionScope='nonSxS')
 intl=tag(settings,'component',attrs=dict(name='Microsoft-Windows-International-Core-WinPE',**common));lang=tag(intl,'SetupUILanguage');tag(lang,'UILanguage','en-US')
 for n in ('InputLocale','SystemLocale','UILanguage','UserLocale'):tag(intl,n,'0409:00000409'if n=='InputLocale'else'en-US')
 setup=tag(settings,'component',attrs=dict(name='Microsoft-Windows-Setup',**common));run=tag(setup,'RunSynchronous');command=tag(run,'RunSynchronousCommand',attrs={'{'+wcm+'}action':'add'})
 tag(command,'Order','1');tag(command,'Path','cmd.exe /d /c A:\\SEED.CMD');tag(command,'Description','Copy owned serial control into an existing isolated Windows child, then shut down')
 tag(tag(setup,'UserData'),'AcceptEula','true')
 return ET.tostring(root,encoding='utf-8',xml_declaration=True)
def seed_cmd():
 lines=['@echo off','setlocal EnableExtensions EnableDelayedExpansion','if /i not "%SystemDrive%"=="X:" exit /b 20','if not exist X:\\Windows\\System32\\wpeutil.exe exit /b 21','echo started>A:\\SEED.START','set COUNT=0','set TARGET=',
 'for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do (',' if exist %%D:\\Windows\\System32\\config\\SYSTEM if exist %%D:\\ChaomofaWorker (','  set /a COUNT+=1','  set TARGET=%%D:', ' )',')',
 'if not "!COUNT!"=="1" goto fail','if exist "!TARGET!\\ChaomofaWorker\\SerialV1" goto fail','if exist "!TARGET!\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\CMF_SERIAL_V1.CMD" goto fail',
 'mkdir "!TARGET!\\ChaomofaWorker\\SerialV1"','if errorlevel 1 goto fail',
 'copy /b A:\\AGENT.EXE "!TARGET!\\ChaomofaWorker\\SerialV1\\agent.exe" >A:\\COPY.LOG','if errorlevel 1 goto fail',
 'copy /b A:\\CONFIG.TXT "!TARGET!\\ChaomofaWorker\\SerialV1\\CONFIG.TXT" >>A:\\COPY.LOG','if errorlevel 1 goto fail',
 'copy /b A:\\START.CMD "!TARGET!\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\CMF_SERIAL_V1.CMD" >>A:\\COPY.LOG','if errorlevel 1 goto fail',
 'echo seed-complete>A:\\SEED.OK','echo !TARGET!>>A:\\SEED.OK','wpeutil shutdown','exit /b 0',':fail','echo seed-failed>A:\\SEED.FAIL','wpeutil shutdown','exit /b 1']
 return ('\r\n'.join(lines)+'\r\n').encode('ascii')
def main():
 from pyfatfs.PyFat import PyFat
 from pyfatfs.PyFatFS import PyFatFS
 out=WORKER/'tcg-serial-seed-v1';out.mkdir(exist_ok=False)
 build=WORKER/'tcg-serial-agent-build-v1';manifest=json.loads((build/'manifest.json').read_bytes());exe=Path(manifest['executable']['path']);raw=exe.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=manifest['executable']['sha256']:raise ValueError('compiled agent identity')
 key=secrets.token_hex(32);(out/'control-key.private').write_text(key,encoding='ascii')
 floppy=out/'seed.private.flp';floppy.touch(exist_ok=False);fat=PyFat();fat.mkfs(str(floppy),fat_type=PyFat.FAT_TYPE_FAT12,size=1440*1024,media_type=0xF0);fat.close()
 files={'Autounattend.xml':answer(),'SEED.CMD':seed_cmd(),'START.CMD':STARTUP,'AGENT.EXE':raw,'CONFIG.TXT':(key+'\r\n').encode()}
 with PyFatFS(str(floppy))as fs:
  for name,data in files.items():fs.writebytes(name,data)
 with PyFatFS(str(floppy),read_only=True)as fs:
  for name,data in files.items():
   if fs.readbytes(name)!=data:raise ValueError('FAT byte identity')
 public={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in files.items()}
 (out/'media-manifest.json').write_text(json.dumps(dict(accepted=False,floppy=identity(floppy),files=public,private_key_not_in_report=True,no_disk_format_or_install_directive=True),indent=2))
 (out/'seed-source.cmd').write_bytes(files['SEED.CMD']);(out/'startup-source.cmd').write_bytes(STARTUP);(out/'answer-source.xml').write_bytes(files['Autounattend.xml'])
 print(json.dumps(dict(files=public,floppy_bytes=floppy.stat().st_size)))
if __name__=='__main__':main()
