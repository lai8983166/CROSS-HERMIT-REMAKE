@echo off
start "" /b "C:\ChaomofaWorker\SerialV1\agent.exe"
exit /b 0
