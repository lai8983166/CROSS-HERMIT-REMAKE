import gzip,hashlib,json,os,shutil,stat
from pathlib import Path
from devtools.isolated_windows_vm import WORKER,identity
rows=[]
cases=[WORKER/n for n in ('tcg-serial-seed-v1','tcg-serial-seed-v2','tcg-serial-seed-v3','tcg-serial-native-v1','tcg-serial-native-v2')]
for case in cases:
 assert json.loads((case/'report.json').read_bytes())['process_exited']
 for p in sorted(case.glob('*.ppm')):
  before=identity(p);dst=p.with_suffix('.ppm.gz');assert not dst.exists()
  with p.open('rb')as src,dst.open('xb')as target:
   with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0)as z:shutil.copyfileobj(src,z)
  with gzip.open(dst,'rb')as z:raw=z.read()
  assert hashlib.sha256(raw).hexdigest()==before['sha256'];p.unlink();rows.append(dict(original=before,replacement=identity(dst),action='lossless_compression',original_path_available=False))
 # PNG is a derived inspection preview; exact PPM bytes remain above.
 for p in sorted(case.glob('*.png')):
  dst=p.with_suffix('.ppm.gz');assert dst.exists();before=identity(p);p.unlink();rows.append(dict(original=before,replacement=str(dst),action='remove_derived_preview',original_path_available=False))
case=WORKER/'tcg-serial-native-v1'
for name in ('SYSTEM.private','SYSTEM.private.LOG1','SYSTEM.private.LOG2','Application.evtx','System.evtx','Application-events.private.json','System-events.private.json','Application-events-v2.private.json','System-events-v2.private.json'):
 p=case/name
 if not p.exists():continue
 row=dict(original=identity(p),action='remove_regenerable_extraction',replacement=str(case/'disk.qcow2.gz'),original_path_available=False)
 try:os.chmod(p,stat.S_IWRITE);p.unlink()
 except Exception as e:row['original_path_available']=True;row['cleanup_error']=type(e).__name__
 rows.append(row)
(WORKER/'serial-cleanup-v1.json').write_text(json.dumps(rows,indent=2));print(json.dumps(dict(records=len(rows),failed=[r for r in rows if r.get('cleanup_error')],removed_raw_bytes=sum(r['original']['bytes']for r in rows if not r['original_path_available']))))
