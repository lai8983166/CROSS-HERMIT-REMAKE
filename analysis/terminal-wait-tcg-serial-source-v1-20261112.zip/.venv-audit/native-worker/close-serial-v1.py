import hashlib,json,zipfile
from pathlib import Path
from datetime import datetime,timezone
from devtools.isolated_windows_vm import WORKER,ROOT,identity
w=WORKER;analysis=ROOT/'analysis';stamp='v1-20261112';capsule=analysis/('terminal-wait-tcg-serial-source-'+stamp+'.zip')
paths=list((ROOT/'devtools').glob('terminal_tcg_serial_*'))+[ROOT/'devtools/tests/test_terminal_tcg_serial_v1.py']
public=('report.json','media-manifest.json','seed-verification.json','seed-source.cmd','answer-source.xml','startup-source.cmd','stderr.log','vm-ready.json','host-control.json','serial-result.json','offline-inspection.json','serial-registry-dissection.json','startup-registry.json','bcd-diagnostic.json','winlogon-public.json','compression.json','client.stderr','client.stdout','ended-markers.json','ended-winlogon.json')
for name in ('tcg-serial-seed-v1','tcg-serial-seed-v2','tcg-serial-seed-v3','tcg-serial-native-v1','tcg-serial-native-v2'):
 paths +=[w/name/f for f in public if(w/name/f).exists()]
for v in (1,2,3):paths +=[w/('tcg-serial-agent-build-v'+str(v))/f for f in ('manifest.json','agent.exe')]
paths +=[w/f for f in ('serial-build-provenance-v1.json','serial-original-winlogon-v1.json','serial-compression-v1.json','serial-cleanup-v1.json','serial-preservation-v1.json')]
# Diagnostic extraction scripts contain no embedded credentials; failed parsers are provenance only.
paths +=list(w.glob('*serial*.py'))
rows=[]
with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(paths)):
  assert p.is_file();raw=p.read_bytes();assert len(raw)<2*1024*1024
  member=p.relative_to(ROOT).as_posix();z.writestr(member,raw);rows.append(dict(member=member,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 with_manifest=dict(accepted=False,baseline_commit='bcd591e45907d0d8039a5b9a3502175de762f60d',files=rows,private_floppy_and_config_excluded=True)
 z.writestr('manifest.json',json.dumps(with_manifest,indent=2))
# Failed runnable launch recipes are preserved by exact bytes in the capsule, not left live.
retired=[]
for p in (ROOT/'devtools').glob('terminal_tcg_serial_*'):
 if p.name in ('terminal_tcg_serial_agent_v3.cs','terminal_tcg_serial_client_v3.py','terminal_tcg_serial_media_v3.py','terminal_tcg_serial_seed_verify_v3.py'):continue
 before=identity(p)
 with zipfile.ZipFile(capsule)as z:assert z.read(p.relative_to(ROOT).as_posix())==p.read_bytes()
 p.unlink();retired.append(before)
cases=[]
for name in ('tcg-serial-seed-v1','tcg-serial-native-v1','tcg-serial-seed-v2','tcg-serial-native-v2','tcg-serial-seed-v3'):
 case=w/name;r=json.loads((case/'report.json').read_bytes());row=dict(case=name,vm_seconds=r['seconds'],vm_process_exited=r['process_exited'],parents_size_mtime_unchanged=r['parent_size_mtime_unchanged'],guest_poweroff=r.get('guest_poweroff',False),qmp_quit='quit'in r,runner_errors=r['errors'],overlay_original=r['overlay'])
 if(case/'serial-result.json').exists():
  client=json.loads((case/'serial-result.json').read_bytes());row.update(operations=len(client['operations']),failure=client['errors'],host_control=json.loads((case/'host-control.json').read_bytes()))
 if(case/'seed-verification.json').exists():row['offline_seed_verified']=json.loads((case/'seed-verification.json').read_bytes())['verified']
 cases.append(row)
gates=dict(accepted=False,formal_tasks_complete=2,formal_tasks_total=8,offline_seed_copy_verified=True,serial_agent_readiness=False,serial_command_return_and_guest_cleanup=False,small_block_deployment=False,original_probe_executed=False,input_isolation_verified=False,d3d8_tested=False,d3d8_compatible=None,game_starts=0,formal_replays=0,host_input_injected=False,host_input_blocked=False,host_foreground_takeover=False,all_owned_vm_processes_exited=all(c['vm_process_exited']for c in cases),host_jobs_empty_and_closed=all(c['host_control']['active_processes_after']==0 and c['host_control']['job_closed']for c in cases if'host_control'in c),guest_autologon_or_bootstrap_cleanup_verified=False,continuous_host_performance_unaffected_proved=False)
result=dict(schema='terminal-tcg-serial-closeout-v1',checked_utc=datetime.now(timezone.utc).isoformat(),accepted=False,gates=gates,cases=cases,decision='Current TCG/Windows/control-bootstrap combination is not admitted for bounded interactive collection; stop these launch recipes. D3D8 remains untested, not incompatible.',next_boundary='Inspect the pre-script WinPE startup stall or use a separately qualified bootstrap/backend; do not blindly rerun Startup or Userinit recipe. Require hello, native completion/cleanup, blocks, original probe and same-boot input/D3D8 before game.',limitations=['v1/v2 no durable Startup/agent execution evidence; SMBIOS tail issue was static, not established runtime cause','v3 no SEED.START or new SerialV3 directory; Userinit remains original; reg load was not observed','host exit0 / VM errors=[] do not imply success','failed frozen guest disks retain private autologon/bootstrap state; never present as cleaned runnable sources','base VMDK preservation is size/mtime scope, not a fresh full SHA'],source_capsule=identity(capsule),retired_live_recipes=retired,tests=dict(command='python -B -X utf8 -m unittest devtools.tests.test_terminal_tcg_serial_v1 devtools.tests.test_terminal_tcg_qualification_verify_v1',passed=10,guest_execution=False),preservation=json.loads((w/'serial-preservation-v1.json').read_bytes()),guest_start_count=5,readiness_failures=2,first_native_failure_bound_seconds=300,full_game_collection_count=0)
(analysis/('terminal-wait-tcg-serial-closeout-'+stamp+'.json')).write_text(json.dumps(result,indent=2))
review=dict(accepted=False,independent_reviewer='/root/serial_agent',primary_reviewed_agent_source=True,independent_reviewed_media_client_and_actual_reports=True,conclusion='not admitted; all serial/game/graphics gates remain closed',reviewed_facts=['seed v1/v2 exact copied bytes and guest poweroff','native v1/v2 empty operation lists and readiness timeouts; host jobs/VM exited','v2 startup/agent markers absent','v3 empty seed markers, no seed verification, QMP stop rather than guest poweroff','gzip SHA matches compression receipts; reviewer did not re-decompress'],findings_resolved=['v2/v3 strict late complete response rejection','unassigned child host kill path','explicit bootstrap cleanup checks','fixed ancestor SHA and agent source/build binding','startup template exactness','original Userinit exact offline REG_SZ read; v3 verifier checks REG_SZ'],remaining_limitations=result['limitations'],source_capsule=result['source_capsule'])
(analysis/('terminal-wait-tcg-serial-review-'+stamp+'.json')).write_text(json.dumps(review,indent=2))
print(json.dumps(dict(capsule=result['source_capsule'],retired_recipes=len(retired),gates=gates)))
