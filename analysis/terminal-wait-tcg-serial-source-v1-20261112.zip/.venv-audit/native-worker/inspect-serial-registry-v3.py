import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v1';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10','tcg-serial-seed-v1',case.name):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
n=NTFS(next(p for p in Disk(s).partitions if p.offset==525336576).open());rows={}
from dissect.regf import RegistryHive
hive=RegistryHive(n.mft.get('Windows/System32/config/SYSTEM').open())
for path in ('Select','ControlSet001/Enum/ACPI/PNP0501','ControlSet001/Services/Serial'):
 key=hive.open(path.replace('/',chr(92)))
 def vals(k):
  return {v.name:v.value.hex()if isinstance(v.value,bytes)else v.value for v in k.values()}
 rows[path]=vals(key)
 if 'PNP0501'in path:
  for child in key.subkeys():
   row=vals(child)
   for sub in child.subkeys():
    if sub.name=='Device Parameters':row[sub.name]=vals(sub)
   rows[path+'/'+child.name]=row
(case/'serial-registry-dissection.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
