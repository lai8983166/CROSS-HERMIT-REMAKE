from pathlib import Path
B=chr(92)
def wp(s):return s.replace('/',B)
key=wp('HKLM/CMF_SERIAL_SEED_V3/Microsoft/Windows NT/CurrentVersion/Winlogon')
before=wp('C:/Windows/system32/userinit.exe,');after=before+wp('C:/ChaomofaWorker/SerialV3/agent.exe,')
s=Path('devtools/terminal_tcg_serial_media_v2.py').read_text().replace('SerialV2','SerialV3').replace('SERIAL_V2','SERIAL_V3').replace('seed-v2','seed-v3').replace('build-v2','build-v3')
start=s.index('def seed_cmd():');end=s.index('\ndef main():',start)
# Preserve copy-only volume discovery and fixed-file copy checks from v2.
import sys
sys.path.insert(0,str(Path('.').resolve()))
from devtools.terminal_tcg_serial_media_v2 import seed_cmd
lines=seed_cmd().decode().replace('SerialV2','SerialV3').replace('SERIAL_V2','SERIAL_V3').splitlines()
new=[];skip=False
for line in lines:
 if 'CMF_SERIAL_V3.CMD'in line:
  if line.startswith('copy '):skip=True
  continue
 if skip and line=='if errorlevel 1 goto fail':skip=False;continue
 if line=='echo seed-complete>A:'+B+'SEED.OK':
  new+=['reg query HKLM'+B+'CMF_SERIAL_SEED_V3 >nul 2>&1','if not errorlevel 1 goto fail','reg load HKLM'+B+'CMF_SERIAL_SEED_V3 "!TARGET!'+wp('/Windows/System32/config/SOFTWARE')+'" >A:'+B+'REG.LOG','if errorlevel 1 goto fail','set HIVE_LOADED=1','set ORIGINAL=', 'for /f "tokens=2,*" %%A in (\'reg query "'+key+'" /v Userinit 2^>nul\') do if "%%A"=="REG_SZ" set "ORIGINAL=%%B"','if not "!ORIGINAL!"=="'+before+'" goto fail','echo !ORIGINAL!>A:'+B+'USERINIT.BEFORE','reg add "'+key+'" /v Userinit /t REG_SZ /d "'+after+'" /f >>A:'+B+'REG.LOG','if errorlevel 1 goto fail','reg query "'+key+'" /v Userinit >A:'+B+'USERINIT.AFTER','if errorlevel 1 goto fail','reg unload HKLM'+B+'CMF_SERIAL_SEED_V3 >>A:'+B+'REG.LOG','if errorlevel 1 goto fail','set HIVE_LOADED=']
 if line==':fail':
  new.append(line);new.append('if "!HIVE_LOADED!"=="1" reg unload HKLM'+B+'CMF_SERIAL_SEED_V3 >>A:'+B+'REG.LOG');continue
 new.append(line)
script=(chr(13)+chr(10)).join(new)+chr(13)+chr(10)
s=s[:start]+'def seed_cmd():\n return '+repr(script.encode('ascii'))+'\n'+s[end:]
s=s.replace(",'START.CMD':STARTUP",'').replace(";(out/'startup-source.cmd').write_bytes(STARTUP)",'')
Path('devtools/terminal_tcg_serial_media_v3.py').write_text(s)
s=Path('devtools/terminal_tcg_serial_seed_verify_v2.py').read_text().replace('media_v2','media_v3').replace('seed-v2','seed-v3').replace('build-v2','build-v3').replace('SerialV2','SerialV3').replace('SERIAL_V2','SERIAL_V3')
s=s.replace(",'ProgramData/Microsoft/Windows/Start Menu/Programs/Startup/CMF_SERIAL_V3.CMD':STARTUP",'')
s=s.replace("files=[]", "from dissect.regf import RegistryHive\n hive=RegistryHive(ntfs.mft.get('Windows/System32/config/SOFTWARE').open())\n userinit=hive.open('Microsoft/Windows NT/CurrentVersion/Winlogon'.replace('/',chr(92))).value('Userinit').value\n if userinit!="+repr(after)+":raise ValueError('installed Userinit chain')\n files=[]")
s=s.replace('files=files,markers=markers','files=files,userinit=userinit,markers=markers')
s=s.replace("'SEED.FAIL','COPY.LOG'","'SEED.FAIL','COPY.LOG','REG.LOG','USERINIT.BEFORE','USERINIT.AFTER'")
Path('devtools/terminal_tcg_serial_seed_verify_v3.py').write_text(s)
s=Path('devtools/terminal_tcg_serial_client_v2.py').read_text().replace('tcg-serial-seed-v2','tcg-serial-seed-v3').replace('tcg-serial-agent-build-v2','tcg-serial-agent-build-v3').replace('client_v2','client_v3')
s=s.replace("v['autologon_cleared']is True", "v['autologon_cleared']is True and v['initialization_restored']is True")
s=s.replace("r['bye'].get('startup_removed')", "r['bye'].get('bootstrap_restored')").replace('owned Startup cleanup failed','owned bootstrap restoration failed')
Path('devtools/terminal_tcg_serial_client_v3.py').write_text(s)
for name in ('media','seed_verify','client'):
 p=Path('devtools/terminal_tcg_serial_'+name+'_v3.py');compile(p.read_text(),str(p),'exec')
print(script)
