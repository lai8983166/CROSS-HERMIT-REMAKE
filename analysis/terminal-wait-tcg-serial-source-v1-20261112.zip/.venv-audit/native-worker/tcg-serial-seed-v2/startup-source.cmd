@echo off
if /i not "%COMPUTERNAME%"=="CHAOMOFA-WORKER" exit /b 20
echo startup-entered>"C:\ChaomofaWorker\SerialV2\startup-entered.txt"
start "" /b "C:\ChaomofaWorker\SerialV2\agent.exe"
echo %errorlevel%>"C:\ChaomofaWorker\SerialV2\startup-launch-exit.txt"
exit /b 0
