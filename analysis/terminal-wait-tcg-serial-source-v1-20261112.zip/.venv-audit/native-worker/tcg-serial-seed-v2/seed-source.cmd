@echo off
setlocal EnableExtensions EnableDelayedExpansion
if /i not "%SystemDrive%"=="X:" exit /b 20
if not exist X:\Windows\System32\wpeutil.exe exit /b 21
echo started>A:\SEED.START
set COUNT=0
set TARGET=
for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do (
 if exist %%D:\Windows\System32\config\SYSTEM if exist %%D:\ChaomofaWorker (
  set /a COUNT+=1
  set TARGET=%%D:
 )
)
if not "!COUNT!"=="1" goto fail
if exist "!TARGET!\ChaomofaWorker\SerialV2" goto fail
if exist "!TARGET!\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\CMF_SERIAL_V2.CMD" goto fail
mkdir "!TARGET!\ChaomofaWorker\SerialV2"
if errorlevel 1 goto fail
copy /b A:\AGENT.EXE "!TARGET!\ChaomofaWorker\SerialV2\agent.exe" >A:\COPY.LOG
if errorlevel 1 goto fail
copy /b A:\CONFIG.TXT "!TARGET!\ChaomofaWorker\SerialV2\CONFIG.TXT" >>A:\COPY.LOG
if errorlevel 1 goto fail
copy /b A:\START.CMD "!TARGET!\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\CMF_SERIAL_V2.CMD" >>A:\COPY.LOG
if errorlevel 1 goto fail
echo seed-complete>A:\SEED.OK
echo !TARGET!>>A:\SEED.OK
wpeutil shutdown
exit /b 0
:fail
echo seed-failed>A:\SEED.FAIL
wpeutil shutdown
exit /b 1
