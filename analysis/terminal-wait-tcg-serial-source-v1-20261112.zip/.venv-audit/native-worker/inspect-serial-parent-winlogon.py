import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v2';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10'):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
n=NTFS(next(p for p in Disk(s).partitions if p.offset==525336576).open());rows={}
from dissect.regf import RegistryHive
hive=RegistryHive(n.mft.get('Windows/System32/config/SOFTWARE').open());key=hive.open('Microsoft/Windows NT/CurrentVersion/Winlogon'.replace('/',chr(92)))
for v in key.values():
 if v.name in ('Shell','Userinit','AutoAdminLogon','AutoLogonCount'):rows[v.name]=dict(value=v.value,type=int(v.type))
(w/'serial-original-winlogon-v1.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
