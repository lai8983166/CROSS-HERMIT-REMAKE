import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v1';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10','tcg-serial-seed-v1',case.name):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
n=NTFS(next(p for p in Disk(s).partitions if p.offset==525336576).open());rows={}
for path in ('ChaomofaWorker/SerialV1','ProgramData/Microsoft/Windows/Start Menu/Programs/Startup'):
 names=list(n.mft.get(path).listdir(ignore_dos=True));rows[path]=names
for name in ('agent-failure.json','agent.exe','CONFIG.TXT'):
 try:
  raw=n.mft.get('ChaomofaWorker/SerialV1/'+name).open().read(262144);rows[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  if name.endswith('.json'):rows[name]['content']=json.loads(raw)
 except Exception as e:rows[name]=type(e).__name__
for name in ('System.evtx','Application.evtx'):
 raw=n.mft.get('Windows/System32/winevt/Logs/'+name).open().read(20*1024*1024)
 (case/name).write_bytes(raw);rows[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(case/'offline-inspection.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
