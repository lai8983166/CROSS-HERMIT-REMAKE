@echo off
setlocal EnableExtensions EnableDelayedExpansion
if /i not "%SystemDrive%"=="X:" exit /b 20
if not exist X:\Windows\System32\wpeutil.exe exit /b 21
echo started>A:\SEED.START
set COUNT=0
set TARGET=
for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do (
 if exist %%D:\Windows\System32\config\SYSTEM if exist %%D:\ChaomofaWorker (
  set /a COUNT+=1
  set TARGET=%%D:
 )
)
if not "!COUNT!"=="1" goto fail
if exist "!TARGET!\ChaomofaWorker\SerialV3" goto fail
mkdir "!TARGET!\ChaomofaWorker\SerialV3"
if errorlevel 1 goto fail
copy /b A:\AGENT.EXE "!TARGET!\ChaomofaWorker\SerialV3\agent.exe" >A:\COPY.LOG
if errorlevel 1 goto fail
copy /b A:\CONFIG.TXT "!TARGET!\ChaomofaWorker\SerialV3\CONFIG.TXT" >>A:\COPY.LOG
if errorlevel 1 goto fail
reg query HKLM\CMF_SERIAL_SEED_V3 >nul 2>&1
if not errorlevel 1 goto fail
reg load HKLM\CMF_SERIAL_SEED_V3 "!TARGET!\Windows\System32\config\SOFTWARE" >A:\REG.LOG
if errorlevel 1 goto fail
set HIVE_LOADED=1
set ORIGINAL=
for /f "tokens=2,*" %%A in ('reg query "HKLM\CMF_SERIAL_SEED_V3\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Userinit 2^>nul') do if "%%A"=="REG_SZ" set "ORIGINAL=%%B"
if not "!ORIGINAL!"=="C:\Windows\system32\userinit.exe," goto fail
echo !ORIGINAL!>A:\USERINIT.BEFORE
reg add "HKLM\CMF_SERIAL_SEED_V3\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Userinit /t REG_SZ /d "C:\Windows\system32\userinit.exe,C:\ChaomofaWorker\SerialV3\agent.exe," /f >>A:\REG.LOG
if errorlevel 1 goto fail
reg query "HKLM\CMF_SERIAL_SEED_V3\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Userinit >A:\USERINIT.AFTER
if errorlevel 1 goto fail
reg unload HKLM\CMF_SERIAL_SEED_V3 >>A:\REG.LOG
if errorlevel 1 goto fail
set HIVE_LOADED=
echo seed-complete>A:\SEED.OK
echo !TARGET!>>A:\SEED.OK
wpeutil shutdown
exit /b 0
:fail
if "!HIVE_LOADED!"=="1" reg unload HKLM\CMF_SERIAL_SEED_V3 >>A:\REG.LOG
echo seed-failed>A:\SEED.FAIL
wpeutil shutdown
exit /b 1
