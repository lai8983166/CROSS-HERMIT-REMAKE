import gzip,hashlib,json,os,shutil,time
from pathlib import Path
from devtools.isolated_windows_vm import WORKER,identity
rows=[]
for name in ('tcg-serial-native-v1','tcg-serial-native-v2'):
 case=WORKER/name;r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
 p=case/'disk.qcow2';before=identity(p);assert before['sha256']==r['overlay']['sha256'];dst=p.with_suffix('.qcow2.gz');assert not dst.exists()
 with p.open('rb')as src,dst.open('xb')as target:
  with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0,compresslevel=6)as z:shutil.copyfileobj(src,z,1024*1024)
 h=hashlib.sha256();size=0
 with gzip.open(dst,'rb')as z:
  for b in iter(lambda:z.read(1024*1024),b''):h.update(b);size+=len(b)
 assert(size,h.hexdigest())==(before['bytes'],before['sha256'])
 row=dict(original=before,compressed=identity(dst),restore_to=str(p),lossless_roundtrip=True,original_path_available=False,backing_seed_retained=True)
 (case/'compression.json').write_text(json.dumps(row,indent=2));p.unlink();rows.append(row)
(WORKER/'serial-compression-v1.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
