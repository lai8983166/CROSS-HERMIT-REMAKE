import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v1';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10','tcg-serial-seed-v1',case.name):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
from dissect.regf import RegistryHive
rows=[]
for part in Disk(s).partitions:
 try:
  ntfs=NTFS(part.open());entry=ntfs.mft.get('Boot/BCD');hive=RegistryHive(entry.open())
  for obj in hive.open('Objects').subkeys():
   try:elements=obj.subkey('Elements')
   except Exception:continue
   vals={}
   for e in elements.subkeys():
    if e.name in ('16000010','15000011','15000012','15000013','12000004'):
     vals[e.name]={v.name:v.value.hex()if isinstance(v.value,bytes)else v.value for v in e.values()}
   if vals:rows.append(dict(partition_offset=part.offset,object=obj.name,elements=vals))
 except Exception as e:rows.append(dict(partition_offset=part.offset,error=type(e).__name__))
(case/'bcd-diagnostic.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
