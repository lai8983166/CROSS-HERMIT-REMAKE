import base64,json,subprocess,datetime
from devtools.isolated_windows_vm import WORKER,environment
case=WORKER/'tcg-serial-native-v1';start=datetime.datetime.fromtimestamp((case/'vm-ready.json').stat().st_mtime,datetime.timezone.utc).isoformat();results={}
for name in ('Application','System'):
 code="Get-WinEvent -FilterHashtable @{Path='"+str(case/(name+'.evtx'))+"' } -MaxEvents 25 -ErrorAction Stop | Select-Object TimeCreated,Id,ProviderName,LevelDisplayName,Message | ConvertTo-Json -Depth 4"
 p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(code.encode('utf-16le')).decode()],capture_output=True,timeout=30,env=environment(),creationflags=subprocess.CREATE_NO_WINDOW)
 raw=p.stdout.decode('utf-8-sig',errors='replace');(case/(name+'-events-v2.private.json')).write_text(raw);print(name,p.returncode,p.stderr.decode(errors='replace')[:400])
 try:rows=json.loads(raw)
 except Exception:rows=[]
 if isinstance(rows,dict):rows=[rows]
 results[name]=[dict(id=r['Id'],provider=r['ProviderName'],level=r['LevelDisplayName'],message=r['Message'])for r in rows]
secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
public=json.dumps(results,ensure_ascii=False).replace(secret,'[redacted]');(case/'recent-events-v2.json').write_text(public);print(public)
