import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v1';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10','tcg-serial-seed-v1',case.name):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
n=NTFS(next(p for p in Disk(s).partitions if p.offset==525336576).open());rows={}
from dissect.regf import RegistryHive
for filename,paths in [('Windows/System32/config/SOFTWARE',['Microsoft/Windows/CurrentVersion/Explorer/Shell Folders','Microsoft/Windows/CurrentVersion/Policies/Explorer','Microsoft/Windows/CurrentVersion/Explorer/StartupApproved/StartupFolder']),('Users/Administrator/NTUSER.DAT',['Software/Microsoft/Windows/CurrentVersion/Explorer/StartupApproved/StartupFolder','Software/Microsoft/Windows/CurrentVersion/Policies/Explorer'])]:
 hive=RegistryHive(n.mft.get(filename).open())
 for path in paths:
  try:
   key=hive.open(path.replace('/',chr(92)));rows[filename+':'+path]={v.name:v.value.hex()if isinstance(v.value,bytes)else v.value for v in key.values()}
  except Exception as e:rows[filename+':'+path]=type(e).__name__
(case/'startup-registry.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
