import json,hashlib
from pathlib import Path
from dissect.hypervisor.disk.vmdk import VMDK
from dissect.hypervisor.disk.qcow2 import QCow2
from dissect.ntfs import NTFS
from dissect.volume.disk import Disk
from devtools.isolated_windows_vm import WORKER
w=WORKER;case=w/'tcg-serial-native-v1';r=json.loads((case/'report.json').read_bytes());assert r['process_exited']
s=VMDK(w/'worker.vmdk')
for name in ('tcg-windows-compat-v2','tcg-windows-current-v1','tcg-wait-native-v5','tcg-wait-native-v10','tcg-serial-seed-v1',case.name):
 s.seek(0);s=QCow2((w/name/'disk.qcow2').open('rb'),backing_file=s).open()
n=NTFS(next(p for p in Disk(s).partitions if p.offset==525336576).open());rows={}
raw=n.mft.get('Windows/System32/config/SYSTEM').open().read(32*1024*1024)
(case/'SYSTEM.private').write_bytes(raw)
import ctypes,winreg
h=ctypes.c_void_p();api=ctypes.WinDLL('advapi32',use_last_error=True);api.RegLoadAppKeyW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_void_p),ctypes.c_uint,ctypes.c_uint,ctypes.c_uint]
rc=api.RegLoadAppKeyW(str(case/'SYSTEM.private'),ctypes.byref(h),winreg.KEY_READ,1,0)
if rc:raise ctypes.WinError(rc)
root=winreg.HKEYType(h.value)
def vals(key):
 out={};i=0
 while True:
  try:name,value,kind=winreg.EnumValue(key,i);out[name]=value if not isinstance(value,bytes)else value.hex();i+=1
  except OSError:break
 return out
for base in ('Select','ControlSet001/Enum/ACPI/PNP0501','ControlSet001/Services/Serial'):
 with winreg.OpenKey(root,base.replace('/',chr(92)))as key:
  rows[base]=vals(key)
  if 'PNP0501'in base:
   i=0
   while True:
    try:name=winreg.EnumKey(key,i);i+=1
    except OSError:break
    with winreg.OpenKey(key,name)as child:
     row=vals(child)
     try:
      with winreg.OpenKey(child,'Device Parameters')as p:row['Device Parameters']=vals(p)
     except OSError:pass
     rows[base+'/'+name]=row
root.Close();(case/'serial-registry.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
