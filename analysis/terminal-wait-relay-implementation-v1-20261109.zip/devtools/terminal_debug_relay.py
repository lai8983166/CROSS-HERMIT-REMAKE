"""Bounded guest-only hardware observations through the original debug parent.

The child is already debugged by its original protection parent. Attach only to
that owned parent, observe its NtDebugContinue call, and leave its reply intact.
Only debug registers are instrumented; no game memory or general registers.
"""
import ctypes as C
import ctypes.wintypes as W
import struct
import time
import traceback

from tools import school_crt_init_capture as debug
from tools.school_crt_init_nested import instrument, resolve

win = debug.win
need = debug.need
word = debug.word
detach = win.bind('DebugActiveProcessStop', W.BOOL, [W.DWORD])
kill_on_exit = win.bind('DebugSetProcessKillOnExit', W.BOOL, [W.BOOL])


def observe(c, owned, tid, target, capture, seconds=30, maximum_hits=256):
    """capture(context) returns (small evidence, next original instruction VA).

    None ends the requested scope. Returned observations are not full replay.
    Called synchronously by the thread which owns the debugger attachment.
    """
    from devtools.native_input_isolation import require_qualified_guest
    qualification = require_qualified_guest()
    need(1 <= seconds <= 120 and 1 <= maximum_hits <= 4096, 'bounded debug scope')
    parent = int(owned.pi.pid)
    need(parent != c.pid and {parent, c.pid} <= set(owned.members()), 'exact owned parent and child')
    need(tid in win.threads(c.pid), 'selected current child worker')
    api = resolve(parent, 'ntdll.dll', 'NtDebugContinue')
    entry = api['target']
    result = dict(parent_pid=parent, child_pid=c.pid, child_tid=tid, qualification=qualification,
        parent_api=api, hits=[], instrumentation=[], protocol=[], error=None,
        source_memory_written=False, general_registers_written=False,
        debugger_reply_substituted=False, accepted=False, full_instruction_trace=False)
    threads = {}; processes = {}; masks = {}; originals = {}
    pending = None; attached = False; child_handle = None
    wanted = target; child_original = None; child_armed = False
    started = time.monotonic()
    def parent_arm(h, key, targets, mask):
        result['instrumentation'].append(dict(role='parent', pid=key[0], tid=key[1],
            **instrument(h, targets, mask)))
        masks[key] = (targets, mask)
    def restore(h, old, suspended):
        if suspended:
            win.check(win.suspend(h) != 0xffffffff, 'suspend owned instrumentation cleanup')
        try:
            targets = tuple(word(old, i) for i in (4,8,12,16))
            # DR6 is debug status, not architectural application state.
            return instrument(h, targets, word(old,24))
        finally:
            if suspended:win.check(win.resume(h) != 0xffffffff, 'resume owned instrumentation cleanup')
    try:
        child_handle = win.opent(0x5A, False, tid)
        win.check(child_handle, 'selected worker debug context handle')
        win.check(win.suspend(child_handle) != 0xffffffff, 'suspend selected worker')
        try:
            child_original = debug.context(child_handle)
            need(word(child_original,24) == 0, 'do not replace preexisting child hardware instrumentation')
        finally:win.resume(child_handle)
        win.check(debug.attach(parent), 'attach exact owned protection parent')
        attached = True
        win.check(kill_on_exit(False), 'debugger exit must not kill original parent')
        deadline = started + seconds
        events = 0
        while time.monotonic() < deadline and len(result['hits']) < maximum_hits:
            e = debug.EVENT()
            if not debug.wait_event(C.byref(e), 100):
                error = C.get_last_error()
                need(error in (0,121), 'debug wait failed, not a timeout: '+str(error))
                continue
            events += 1
            need(events <= maximum_hits*8+256, 'bounded parent debug events')
            pending = (e.pid,e.tid); key = pending; status = 0x10002
            need(e.pid == parent, 'only explicitly attached owned parent')
            if e.code in (2,3):
                h = e.u.create.thread if e.code == 3 else e.u.thread.thread
                threads[key] = h; originals[key] = debug.context(h)
                need(word(originals[key],24) == 0, 'no existing parent hardware instrumentation')
                if e.code == 3:
                    processes[e.pid] = e.u.create.process
                    if e.u.create.file:win.close(e.u.create.file)
                parent_arm(h,key,(entry,0,0,0),1)
            elif e.code == 6:
                if e.u.file:win.close(e.u.file)
            elif e.code == 1:
                ex = e.u.exception.record.code; h = threads[key]
                status = 0x80010001
                if ex in (0x80000003,0x4000001F):
                    status = 0x10002
                    parent_arm(h,key,(entry,0,0,0),1)
                    if not child_armed:
                        win.check(win.suspend(child_handle) != 0xffffffff, 'suspend selected child for first arm')
                        try:
                            result['instrumentation'].append(dict(role='child',pid=c.pid,tid=tid,
                                **instrument(child_handle,(wanted,0,0,0),1)))
                            child_armed = True
                        finally:win.resume(child_handle)
                elif ex in (0x80000004,0x4000001E):
                    status = 0x10002
                    context = debug.context(h); ip = word(context,184)
                    targets, mask = masks[key]
                    if ip == entry and word(context,20)&1:
                        stack = debug.required(processes[parent],word(context,196),16)
                        ret,debug_object,client,reply = struct.unpack('<4I',stack)
                        cp,ct = struct.unpack('<2I',debug.required(processes[parent],client,8))
                        need(cp == c.pid, 'original parent continues only its owned child')
                        if ct == tid:
                            cc = debug.context(child_handle)
                            if word(cc,184) == wanted and word(cc,20)&1:
                                need(reply == 0x10002, 'original parent naturally accepts the hardware event')
                                record,next_ip = capture(cc)
                                index = len(result['hits'])
                                result['hits'].append(dict(index=index,elapsed=time.monotonic()-started,
                                    context_hex=cc.hex(),target=wanted,data=record))
                                result['protocol'].append(dict(hit_index=index,parent_context_hex=context.hex(),
                                    parent_stack_hex=stack.hex(),client_id_hex=struct.pack('<2I',cp,ct).hex(),
                                    original_continue_status=reply,debug_object=debug_object))
                                wanted = next_ip
                                result['instrumentation'].append(dict(role='child',pid=c.pid,tid=tid,
                                    **instrument(child_handle,(wanted or 0,0,0,0),1 if wanted else 0)))
                        parent_arm(h,key,(entry,ret,0,0),4)
                    else:
                        need(ip == targets[1] and mask == 4 and word(context,20)&2,
                             'only original parent continuation entry/return breakpoints')
                        parent_arm(h,key,(entry,0,0,0),1)
                else:
                    status = 0x80010001
                    result.setdefault('other_parent_exceptions',[]).append(dict(code=ex,first_chance=e.u.exception.first))
            elif e.code == 4:
                h=threads.pop(key,None);originals.pop(key,None)
                if h:win.close(h)
            elif e.code == 5:
                result['parent_exit_during_scope']=int(e.u.exit_code)
            win.check(debug.continue_event(*pending,status), 'continue unmodified owned parent event')
            pending = None
            if wanted is None:
                result['scope_completed']=True;break
            need(e.code != 5, 'parent exited before observation completed')
        result.setdefault('scope_completed',False)
        result['debug_events'] = events
    except Exception as exc:
        result['error']=repr(exc);result['traceback']=traceback.format_exc(limit=6)
    finally:
        cleanup = dict(errors=[], parent_detached=False, child_debug_registers_restored=False)
        if child_handle and child_original is not None and child_armed:
            try:
                cleanup['child_restore']=restore(child_handle,child_original,True)
                cleanup['child_debug_registers_restored']=True
            except Exception as exc:cleanup['errors'].append('child: '+repr(exc))
        for key,h in threads.items():
            try:restore(h,originals[key],pending is None)
            except Exception as exc:cleanup['errors'].append('parent: '+repr(exc))
        if pending:
            if not debug.continue_event(*pending,status):cleanup['errors'].append('pending event continuation failed')
        if attached:
            cleanup['parent_detached']=bool(detach(parent))
            if not cleanup['parent_detached']:cleanup['errors'].append('detach failed: '+str(C.get_last_error()))
        for h in threads.values():win.close(h)
        for h in processes.values():win.close(h)
        if child_handle:win.close(child_handle)
        result['cleanup']=cleanup;result['elapsed_seconds']=time.monotonic()-started
    return result
