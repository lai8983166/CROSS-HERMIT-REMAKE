import json,hashlib
from pathlib import Path
from devtools.terminal_tcg_control_verify import evaluate
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker';case=W/'tcg-windows-control-v6'
def ident(p):
    d=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
r=json.loads((case/'report.json').read_bytes());sidecar=json.loads((case/'sidecar.json').read_bytes())
status=json.loads((case/'status-resume-1.json').read_bytes());wow=json.loads((case/'wow64-resume-1.json').read_bytes())
derived=dict(r,observations=r['observations']+[dict(control=status)],wow64=wow)
result=evaluate(derived,sidecar)
if not result['control_preflight_passed']or not result['wow64_process_preflight_passed']:raise ValueError('preflight rejected')
result.update(formal_progress='2/8',windows_full_state_admitted=False,game_starts=0,host_input=0,
    raw_sources=[ident(case/n)for n in ('report.json','sidecar.json','status-query-1.json','status-resume-1.json','wow64-query-1.json','wow64-resume-1.json')],
    phases=[ident(p)for p in sorted((W/'tcg-control-evidence-v1').glob('phase-*.json'))],
    independent_review=ident(R/'analysis/terminal-wait-tcg-windows-control-independent-final-review-v1-20261111.json'),
    code=[ident(R/'devtools'/n)for n in ('terminal_tcg_windows_control_v7.py','terminal_tcg_net_sidecar_v4.py','terminal_tcg_guest_query_v3.py','terminal_tcg_query_resume.py','terminal_tcg_control_verify.py')],
    status=status['response']['value'],wow64=wow['response']['value'],
    receive_resume_semantics='Original authenticated command IDs, immutable phase digest; never resubmit; explicit command/shell close after output',
    limitation='WOW64 process existence/exit only; no original wait return or CPU context/replay proof')
with (R/'analysis/terminal-wait-tcg-windows-control-proof-v1-20261111.json').open('x')as f:json.dump(result,f,indent=2)
print(json.dumps({k:result[k]for k in ('control_preflight_passed','wow64_process_preflight_passed','cleanup_observed')}))
