import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
guest=PureWindowsPath('C:/ChaomofaWorker/project')
out=WORKER/'wait-return-unit-checks-v1-20261109.json'
driver=WORKER/'wait-return-unit-checks-v1-driver.py'
if out.exists()or driver.exists():raise ValueError('fresh unit check')
files=[R/'devtools/terminal_wait_return_callback.py',R/'devtools/terminal_wait_return_callback.cs',R/'devtools/tests/test_terminal_wait_return_callback.py']
before=[identity(p)for p in files]
for p in files:vmrun(['CopyFileFromHostToGuest',VMX,p,guest/p.relative_to(R).as_posix()],guest=True)
remote=PureWindowsPath('C:/ChaomofaWorker')/driver.name
remote_out=guest/'analysis'/out.name
script='''import json,os,subprocess,sys,time
os.chdir('C:/ChaomofaWorker/project');os.environ['TEMP']=os.environ['TMP']='C:/ChaomofaWorker/temp'
rows=[]
for flags in ([],['-O']):
    start=time.monotonic();p=subprocess.run([sys.executable,'-B']+flags+['-m','unittest','devtools.tests.test_terminal_wait_return_callback'],capture_output=True,text=True,timeout=30)
    rows.append(dict(flags=flags,returncode=p.returncode,elapsed_seconds=round(time.monotonic()-start,3),output=p.stdout+p.stderr))
with open(OUT,'x',encoding='utf8')as f:json.dump(rows,f,indent=2)
if any(x['returncode'] for x in rows):raise SystemExit(1)
'''.replace('OUT',repr(str(remote_out)))
with driver.open('x',encoding='utf8')as f:f.write(script)
vmrun(['CopyFileFromHostToGuest',VMX,driver,remote],guest=True)
print(run_script("& C:\\ChaomofaWorker\\Python\\python.exe -B '"+str(remote)+"';if($LASTEXITCODE -ne 0){throw 'regression failed'};'passed'"))
vmrun(['CopyFileFromGuestToHost',VMX,remote_out,out],guest=True)
if before!=[identity(p)for p in files]:raise ValueError('executed sources changed')
print(out.read_text())
