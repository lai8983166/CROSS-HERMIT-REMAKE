import json,sys,time
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.terminal_wait_return_callback import verify
folder=WORKER/'wait-return-self-v1-20261109';guest=PureWindowsPath('C:/ChaomofaWorker/wait-return-self-v1-20261109')
receipt=WORKER/'wait-return-self-v2-20261109.run.json'
if receipt.exists():raise ValueError('new receipt')
script=r"""$env:TEMP='C:\ChaomofaWorker\temp';$env:TMP=$env:TEMP;if(!(Test-Path -LiteralPath $env:TEMP)){New-Item -ItemType Directory -Path $env:TEMP|Out-Null};
$d='C:\ChaomofaWorker\wait-return-self-v1-20261109';if(!(Test-Path -LiteralPath $d) -or (Test-Path -LiteralPath ($d+'\helper.exe')) -or (Test-Path -LiteralPath ($d+'\report.json'))){throw 'fresh compiled helper required'};
& C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /nologo /platform:x86 /r:System.Web.Extensions.dll /out:C:\ChaomofaWorker\wait-return-self-v1-20261109\helper.exe C:\ChaomofaWorker\wait-return-self-v1-20261109\terminal_wait_return_callback.cs;if($LASTEXITCODE -ne 0){throw 'compile failed'};
& C:\ChaomofaWorker\wait-return-self-v1-20261109\helper.exe --owned-helper-only C:\ChaomofaWorker\wait-return-self-v1-20261109\report.json;'helper_exit='+$LASTEXITCODE
"""
r=dict(accepted=False,host_input_actions=0,original_game_started=False,errors=[],prior_transport=identity(WORKER/'wait-return-self-v1-20261109.run.json'))
start=time.monotonic()
try:r['execution']=run_script(script)
except Exception as e:r['errors'].append(str(e))
for name in ('helper.exe','report.json'):
    try:vmrun(['CopyFileFromGuestToHost',VMX,guest/name,folder/name],guest=True)
    except Exception as e:r['errors'].append(name+': '+str(e))
if(folder/'report.json').exists():
    source=json.loads((folder/'report.json').read_text(encoding='utf-8-sig'))
    r['native_summary']={k:source.get(k)for k in ('error','registration_status','unregistration_status','returns','cleanup_errors')}
    try:r['verification']=verify(source)
    except Exception as e:r['errors'].append('verify: '+str(e))
r['elapsed_seconds']=round(time.monotonic()-start,3);r['files']=[identity(p)for p in folder.iterdir()if p.is_file()]
with receipt.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k!='files'},indent=2))
