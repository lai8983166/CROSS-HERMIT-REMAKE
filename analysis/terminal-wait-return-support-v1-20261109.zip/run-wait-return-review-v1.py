import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
module=R/'devtools/terminal_wait_return_callback_review.py'
driver=WORKER/'wait-return-review-v1-driver.py'
out=R/'analysis/terminal-wait-return-callback-failure-v1-20261109.json'
guest=PureWindowsPath('C:/ChaomofaWorker/project');remote=PureWindowsPath('C:/ChaomofaWorker')/driver.name
remote_out=guest/'analysis'/out.name
script='''import json,sys
from pathlib import Path
sys.path.insert(0,'C:/ChaomofaWorker/project')
from devtools.terminal_wait_return_callback_review import audit
class CurrentDLLs:
    def __truediv__(self,name):return Path('C:/Windows')/('SysWOW64' if name=='ntdll.dll' else 'System32')/name
r=audit(CurrentDLLs(),Path('C:/ChaomofaWorker/wait-return-self-v1-20261109/report.json'))
with open(OUT,'x',encoding='utf8')as f:json.dump(r,f,indent=2)
print('bounded original DLL audit completed; native return relay NOT supported')
'''.replace('OUT',repr(str(remote_out)))
with driver.open('x',encoding='utf8')as f:f.write(script)
before=identity(module)
vmrun(['CopyFileFromHostToGuest',VMX,module,guest/'devtools'/module.name],guest=True)
vmrun(['CopyFileFromHostToGuest',VMX,driver,remote],guest=True)
print(run_script("& C:\\ChaomofaWorker\\Python\\python.exe -B '"+str(remote)+"';if($LASTEXITCODE -ne 0){throw 'audit failed'};'completed'"))
if out.exists():raise ValueError('fresh report')
vmrun(['CopyFileFromGuestToHost',VMX,remote_out,out],guest=True)
if before!=identity(module):raise ValueError('audit implementation changed')
print(json.dumps(identity(out)))
