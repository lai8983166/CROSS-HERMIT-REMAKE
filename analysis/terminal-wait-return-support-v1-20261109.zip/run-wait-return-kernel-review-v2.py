import sys,json
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
module=R/'devtools/terminal_wait_return_callback_review_v2.py';driver=WORKER/'wait-return-kernel-review-v2-driver.py'
out=R/'analysis/terminal-wait-return-kernel-refusal-v2-20261109.json'
guest=PureWindowsPath('C:/ChaomofaWorker/project');remote=PureWindowsPath('C:/ChaomofaWorker')/driver.name
remote_out=guest/'analysis'/out.name
script='''import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'C:/ChaomofaWorker/project')
from devtools.terminal_wait_return_callback_review_v2 import audit,KERNEL
class CurrentDLLs:
    def __truediv__(self,name):return Path('C:/Windows')/('SysWOW64' if name=='ntdll.dll' else 'System32')/('ntoskrnl.exe' if name==KERNEL else name)
r=audit(CurrentDLLs(),Path('C:/ChaomofaWorker/wait-return-self-v1-20261109/report.json'))
parent=Path('C:/ChaomofaWorker/project/analysis/terminal-wait-return-callback-failure-v1-20261109.json')
old=json.loads(parent.read_bytes());increment={k:v for k,v in r.items()if k not in old or v!=old[k]}
increment.update(accepted=False,parent=dict(path=str(parent),bytes=parent.stat().st_size,sha256=hashlib.sha256(parent.read_bytes()).hexdigest()),increment_only=True)
with open(OUT,'x',encoding='utf8')as f:json.dump(increment,f,indent=2)
print('actual kernel rejects native64-to-WOW64 callback; no native retry made')
'''.replace('OUT',repr(str(remote_out)))
with driver.open('x',encoding='utf8')as f:f.write(script)
before=identity(module)
vmrun(['CopyFileFromHostToGuest',VMX,module,guest/'devtools'/module.name],guest=True)
vmrun(['CopyFileFromHostToGuest',VMX,driver,remote],guest=True)
print(run_script("& C:\\ChaomofaWorker\\Python\\python.exe -B '"+str(remote)+"';if($LASTEXITCODE -ne 0){throw 'kernel audit failed'};'done'"))
if out.exists():raise ValueError('fresh report')
vmrun(['CopyFileFromGuestToHost',VMX,remote_out,out],guest=True)
if before!=identity(module):raise ValueError('implementation changed')
print(json.dumps(identity(out)))
