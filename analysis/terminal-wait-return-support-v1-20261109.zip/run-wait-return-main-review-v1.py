import sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_original_wait_decode import restore_guest_artifact
from devtools.isolated_vm_guest_admin import run_script
guest=PureWindowsPath('C:/ChaomofaWorker/project');source=WORKER/'terminal-battle-wait-window-battle-v6-20261109.json.gz'
restore_guest_artifact(source,guest/'analysis/wait-return-inputs-v1-20261109'/source.name,identity(source))
driver=WORKER/'review-wait-return-main-v1.py';remote=PureWindowsPath('C:/ChaomofaWorker')/driver.name
vmrun(['CopyFileFromHostToGuest',VMX,driver,remote],guest=True)
print(run_script("& C:\\ChaomofaWorker\\Python\\python.exe -B '"+str(remote)+"';if($LASTEXITCODE -ne 0){throw 'independent review failed'};'done'"))
out=R/'analysis/terminal-wait-return-independent-review-v1-20261109.json'
if out.exists():raise ValueError('fresh independent report')
vmrun(['CopyFileFromGuestToHost',VMX,guest/'analysis'/out.name,out],guest=True)
print(identity(out))
