import sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
print(run_script(r"""try {$env:TEMP='C:\ChaomofaWorker\temp';$env:TMP=$env:TEMP;& C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /nologo /platform:x86 /r:System.Web.Extensions.dll /out:C:\ChaomofaWorker\wait-return-self-v1-20261109\helper.exe C:\ChaomofaWorker\wait-return-self-v1-20261109\terminal_wait_return_callback.cs 2>&1;'compiler_exit='+$LASTEXITCODE}catch{'error='+$_.Exception.Message}"""))
