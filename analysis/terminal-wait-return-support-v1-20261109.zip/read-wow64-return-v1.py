import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
state=json.loads(run_script(STATUS))
if state['cpu']!=2 or not 4000000000<state['memory']<4500000000:raise ValueError('bounded guest')
rows=json.loads(run_script(r"""$busy=@(Get-Process 'CROSS HERMIT',python,pythonw -ErrorAction SilentlyContinue);if($busy.Count){throw 'guest busy'};@('wow64.dll','wow64cpu.dll')|ForEach-Object {$p=Join-Path 'C:\Windows\System32' $_;[pscustomobject]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}|ConvertTo-Json -Compress"""))
for row in rows:
    p=WORKER/'guest-system-dlls'/PureWindowsPath(row['path']).name
    if not p.exists():vmrun(['CopyFileFromGuestToHost',VMX,PureWindowsPath(row['path']),p],guest=True)
    got=identity(p)
    if any(got[k]!=row[k] for k in ('bytes','sha256')):raise ValueError('exact system DLL')
    row['local']=got
with (WORKER/'wow64-return-dll-read-v1-20261109.json').open('x',encoding='utf8')as f:json.dump(dict(guest=state,files=rows,accepted=False,host_input_actions=0),f,indent=2)
print(json.dumps(rows))
