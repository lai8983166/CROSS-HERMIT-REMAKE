import json,os,subprocess,sys,time
os.chdir('C:/ChaomofaWorker/project');os.environ['TEMP']=os.environ['TMP']='C:/ChaomofaWorker/temp'
rows=[]
for flags in ([],['-O']):
    start=time.monotonic();p=subprocess.run([sys.executable,'-B']+flags+['-m','unittest','devtools.tests.test_terminal_wait_return_callback'],capture_output=True,text=True,timeout=30)
    rows.append(dict(flags=flags,returncode=p.returncode,elapsed_seconds=round(time.monotonic()-start,3),output=p.stdout+p.stderr))
with open('C:\\ChaomofaWorker\\project\\analysis\\wait-return-unit-checks-v1-20261109.json','x',encoding='utf8')as f:json.dump(rows,f,indent=2)
if any(x['returncode'] for x in rows):raise SystemExit(1)
