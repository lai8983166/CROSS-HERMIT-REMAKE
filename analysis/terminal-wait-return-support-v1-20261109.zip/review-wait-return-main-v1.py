"""Independent review: original game's frozen selector, actual return bytes and rejection."""
import gzip,hashlib,json,struct,sys
from pathlib import Path
R=Path('C:/ChaomofaWorker/project');sys.path.insert(0,str(R))
from devtools.terminal_wait_return_callback import verify,build_image
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def need(v,m):
    if not v:raise ValueError(m)
source=Path('C:/ChaomofaWorker/wait-return-self-v1-20261109/report.json')
old=R/'analysis/wait-return-inputs-v1-20261109/terminal-battle-wait-window-battle-v6-20261109.json.gz'
need(ident(old)['sha256']=='9874fb2e589aafb1b3190c9a2a5aac7c7ee0e0a3179923cd10d463bee3fd680e','fixed original game source')
with gzip.open(old,'rb')as f:game=json.loads(f.read(8*1024*1024+1))
entries=[x for x in game['API_exports']if x['name']=='NtWaitForSingleObject'];need(len(entries)==1,'one original export')
entry=entries[0];need(entry['RVA']==0x73bf0 and entry['module_sha256']=='2761f133cac12188ed380666104527884b2f89dab918bc5082692ca1b7f341e6','same exact x86 ntdll image')
native=json.loads(source.read_bytes());observed=bytes.fromhex(native['nt_wait_before'])
need(bytes.fromhex(entry['entry_hex'])[:5]==observed[:5]==bytes.fromhex('b804000d00'),'game and helper share actual selector13')
need(observed==bytes.fromhex(native['nt_wait_after']),'no original syscall rewrite')
try:verify(native)
except ValueError as exc:
    rejection=str(exc);need(rejection=='exact callback and return counts; no overflow/bounds error','refusal at real callback count')
else:raise ValueError('zero callback report must not pass')
memory=bytes.fromhex(native['records_hex']);need(struct.unpack_from('<5I',memory)==(0,0,0,4,0),'no observations but four completed wrappers')
need(memory[64:64+8*2048]==bytes(8*2048),'all callback record slots unpopulated')
post=[list(struct.unpack_from('<9I',memory,20480+i*1024+32))for i in range(4)]
need([x[7]for x in post]==[0,0,0,258],'actual post-return raw EAX matches reported native return')
proof=R/'analysis/terminal-wait-return-callback-failure-v1-20261109.json';audit=json.loads(proof.read_bytes())
need(audit['source']['sha256']==ident(source)['sha256'],'failure review bound to native source')
segments={ (x['module'],x['start_rva']):x for x in audit['excerpts']}
path=segments['wow64cpu.dll',0x1b46]['instructions'];calls=[x for x in path if x['mnemonic']=='call']
need(len(calls)==1 and calls[0]['rva']==0x1b51 and calls[0]['operands']=='0x1ce0','only syscall trampoline call in selected fast return body')
need(any(x['rva']==0x1b8e and x['hex']=='41ff2e'for x in path)and path[-1]['hex']=='48cf','both direct32bit return forms present')
result=dict(kind='main_independent_native_wait_return_failure_review',passed=True,accepted=False,
    self_helper_preflight_passed=False,game_wait_return_observed=False,first_result_consumer_observed=False,three_game_handshakes_proved=False,
    source=ident(source),parent_game_source=ident(old),static_failure_proof=ident(proof),
    original_game_same_ntdll_and_turbo_selector=True,callback_records=0,post_returns=[0,0,0,258],
    actual_raw_post_frames=post,strict_capability_rejection=rejection,
    limitations=['Self-helper post-return frames are not original game frames.','The original game DLL hash authenticates NtWait selector13; this is not a new game run.',
    'Loaded wow64cpu base is not captured; post ECX is only a consistency hint.','No complete ABI, first result consumption, three game handshakes or resource/PTD cleanup is proved.'],
    review_method='Main independently checks raw post frames, zero callback memory, original game export and exact fast-path branch/call instructions; strict verifier remains rejecting.')
with(R/'analysis/terminal-wait-return-independent-review-v1-20261109.json').open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print('independent failure review passed; gate A remains unproved')
