"""Single bounded self-owned WOW64 native return preflight in the F VM."""
import json,sys,time
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.terminal_wait_return_callback import prepare,verify
folder=WORKER/'wait-return-self-v1-20261109'
guest=PureWindowsPath('C:/ChaomofaWorker/wait-return-self-v1-20261109')
receipt=WORKER/'wait-return-self-v1-20261109.run.json'
if receipt.exists():raise ValueError('fresh receipt')
state=json.loads(run_script(STATUS))
if state['cpu']!=2 or not 4000000000<state['memory']<4500000000:raise ValueError('bounded guest')
idle=run_script("$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'helper.exe'});if($p.Count){throw 'busy'};'idle'")
if idle.strip()!='idle':raise ValueError('idle guest')
before=[identity(R/'devtools'/n) for n in ('terminal_wait_return_callback.py','terminal_wait_return_callback.cs')]
prepare(folder)
q=str(guest)
run_script("if(Test-Path -LiteralPath '"+q+"'){throw 'fresh helper dir'};New-Item -ItemType Directory -Path '"+q+"'|Out-Null;'ready'")
result=dict(guest=state,implementations=before,accepted=False,original_game_started=False,host_input_actions=0,errors=[])
started=time.monotonic()
try:
    for name in ('callback.bin','manifest.json','terminal_wait_return_callback.cs'):
        vmrun(['CopyFileFromHostToGuest',VMX,folder/name,guest/name],guest=True)
    script="$env:TEMP='C:\\ChaomofaWorker\\temp';$env:TMP=$env:TEMP;& C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe /nologo /platform:x86 /r:System.Web.Extensions.dll '/out:"+q+"\\helper.exe' '"+q+"\\terminal_wait_return_callback.cs';if($LASTEXITCODE -ne 0){throw 'compile failed'};& '"+q+"\\helper.exe' --owned-helper-only '"+q+"\\report.json';'helper_exit='+$LASTEXITCODE"
    result['execution']=run_script(script)
except Exception as exc:result['errors'].append(str(exc))
finally:
    for name in ('helper.exe','report.json'):
        try:vmrun(['CopyFileFromGuestToHost',VMX,guest/name,folder/name],guest=True)
        except Exception as exc:result['errors'].append(name+': '+str(exc))
    if (folder/'report.json').exists():
        report=json.loads((folder/'report.json').read_text(encoding='utf-8-sig'))
        try:result['verification']=verify(report)
        except Exception as exc:result['errors'].append('verify: '+str(exc))
        result['native_summary']={k:report.get(k)for k in ('error','registration_status','unregistration_status','returns','cleanup_errors')}
    result['elapsed_seconds']=round(time.monotonic()-started,3)
    result['implementations_unchanged']=before==[identity(R/'devtools'/n) for n in ('terminal_wait_return_callback.py','terminal_wait_return_callback.cs')]
    result['files']=[identity(p)for p in folder.iterdir()if p.is_file()]
    with receipt.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items()if k not in ('guest','files','implementations')},indent=2))
raise SystemExit(1 if result['errors']or not result['implementations_unchanged']else 0)
