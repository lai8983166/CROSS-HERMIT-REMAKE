import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
from devtools.isolated_vm_guest_admin import run_script
out=WORKER/'wait-return-worker-stop-v1-20261109.json'
if out.exists():raise ValueError('fresh stop receipt')
idle=run_script("$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*' -or $_.Name -eq 'helper.exe'});if($p.Count){throw 'busy'};'idle'")
if idle.strip()!='idle':raise ValueError('idle worker required')
r=dict(host_input_actions=0,guest_idle=True,stop_mode='soft')
r['stop_output']=vmrun(['stop',VMX,'soft'],timeout=60)
r['running_vms_after']=vmrun(['list']);r['vmem_files']=[str(p)for p in WORKER.rglob('*.vmem')]
if str(VMX).lower() in r['running_vms_after'].lower()or r['vmem_files']:raise ValueError('worker remains running')
r['VM_disk_bytes']=sum(p.stat().st_size for p in WORKER.glob('*.vmdk'))
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r))
