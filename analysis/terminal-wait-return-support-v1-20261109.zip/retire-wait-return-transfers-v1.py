"""Retire only enumerated current-round guest duplicates with retained host SHA."""
import json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker';sys.path.insert(0,str(R))
# Reuse frozen exact-leaf native PowerShell deletion and path/hash checks.
parent=W/'retire-result-tail-transfers-v1.py'
prefix=parent.read_text().split("apply='--apply'in sys.argv[1:]")[0]
exec(compile(prefix,str(parent),'exec'))
plan=R/'analysis/terminal-wait-return-transfer-retirement-v1-20261109.json'
receipt=W/'wait-return-transfer-retirement-v1-20261109.json'
if '--apply'not in sys.argv:
    pairs=[]
    for n in ('callback.bin','manifest.json','terminal_wait_return_callback.cs','helper.exe','report.json'):
        pairs.append(('C:/ChaomofaWorker/wait-return-self-v1-20261109/'+n,W/'wait-return-self-v1-20261109'/n))
    for n in ('terminal_wait_return_callback.py','terminal_wait_return_callback.cs','terminal_wait_return_callback_review.py','terminal_wait_return_callback_review_v2.py','tests/test_terminal_wait_return_callback.py'):
        pairs.append(('C:/ChaomofaWorker/project/devtools/'+n,R/'devtools'/n))
    for n in ('terminal-wait-return-callback-failure-v1-20261109.json','terminal-wait-return-kernel-refusal-v2-20261109.json','terminal-wait-return-independent-review-v1-20261109.json'):
        pairs.append(('C:/ChaomofaWorker/project/analysis/'+n,R/'analysis'/n))
    pairs.append(('C:/ChaomofaWorker/project/analysis/wait-return-unit-checks-v1-20261109.json',W/'wait-return-unit-checks-v1-20261109.json'))
    pairs.append(('C:/ChaomofaWorker/project/analysis/wait-return-inputs-v1-20261109/terminal-battle-wait-window-battle-v6-20261109.json.gz',W/'terminal-battle-wait-window-battle-v6-20261109.json.gz'))
    for n in ('wait-return-unit-checks-v1-driver.py','wait-return-review-v1-driver.py','wait-return-kernel-review-v2-driver.py','review-wait-return-main-v1.py'):
        pairs.append(('C:/ChaomofaWorker/'+n,W/n))
    rows=[dict(guest=g,retained_host=ident(p))for g,p in pairs]
    for row in rows:
        got=request([row])
        if len(got)!=1:raise ValueError('exact duplicate required')
        row['resolved_guest']=got[0]['resolved_guest']
    result=dict(kind='current_round_exact_guest_transfer_retirement',rows=rows,total_bytes=sum(x['retained_host']['bytes']for x in rows),
        retained_originals=True,historical_sources_removed=False,host_files_removed=False,reason='Current-round duplicate transfer/code/binary files only; original host sources and one bounded unresolved failure are retained.',execution='pending')
    with plan.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(files=len(rows),bytes=result['total_bytes'],plan=ident(plan))))
else:
    data=json.loads(plan.read_bytes());removed=[]
    for row in data['rows']:
        if ident(R/row['retained_host']['path'])!=row['retained_host']:raise ValueError('retained host bytes changed')
        removed+=request([row],True)
    result=dict(plan=ident(plan),removed=removed,total_bytes=data['total_bytes'],all_removed=True,host_originals_retained=True)
    with receipt.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(files=len(removed),bytes=data['total_bytes'],all_removed=True)))
