import json,sys
from pathlib import Path
sys.path.insert(0,'C:/ChaomofaWorker/project')
from devtools.terminal_wait_return_callback_review import audit
class CurrentDLLs:
    def __truediv__(self,name):return Path('C:/Windows')/('SysWOW64' if name=='ntdll.dll' else 'System32')/name
r=audit(CurrentDLLs(),Path('C:/ChaomofaWorker/wait-return-self-v1-20261109/report.json'))
with open('C:\\ChaomofaWorker\\project\\analysis\\terminal-wait-return-callback-failure-v1-20261109.json','x',encoding='utf8')as f:json.dump(r,f,indent=2)
print('bounded original DLL audit completed; native return relay NOT supported')
