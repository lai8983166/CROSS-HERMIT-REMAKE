import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'C:/ChaomofaWorker/project')
from devtools.terminal_wait_return_callback_review_v2 import audit,KERNEL
class CurrentDLLs:
    def __truediv__(self,name):return Path('C:/Windows')/('SysWOW64' if name=='ntdll.dll' else 'System32')/('ntoskrnl.exe' if name==KERNEL else name)
r=audit(CurrentDLLs(),Path('C:/ChaomofaWorker/wait-return-self-v1-20261109/report.json'))
parent=Path('C:/ChaomofaWorker/project/analysis/terminal-wait-return-callback-failure-v1-20261109.json')
old=json.loads(parent.read_bytes());increment={k:v for k,v in r.items()if k not in old or v!=old[k]}
increment.update(accepted=False,parent=dict(path=str(parent),bytes=parent.stat().st_size,sha256=hashlib.sha256(parent.read_bytes()).hexdigest()),increment_only=True)
with open('C:\\ChaomofaWorker\\project\\analysis\\terminal-wait-return-kernel-refusal-v2-20261109.json','x',encoding='utf8')as f:json.dump(increment,f,indent=2)
print('actual kernel rejects native64-to-WOW64 callback; no native retry made')
