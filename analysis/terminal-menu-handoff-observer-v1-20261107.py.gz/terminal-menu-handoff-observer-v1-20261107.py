"""Read-only native menu continuation after the original startup retires.

The observer never submits input or calls game roots. Any UI action is issued
separately through Computer Use. A stop file only stops observation/owned cleanup.
"""
import argparse
import ctypes as C
import ctypes.wintypes as W
import gzip
import json
from pathlib import Path
import time
import traceback
from types import SimpleNamespace

from devtools import terminal_scene_owner as base
from devtools import terminal_startup_handoff as startup
from devtools.terminal_scene_resources import clone

ROOT=base.ROOT
need=base.need
word=base.word
RANGES=startup.RANGES+((0x45E8D0,0x45F9A0),(0x49F4E0,0x49F720),
    (0x4B8FF0,0x4B9300),(0x4D9F30,0x4DA550),(0x60CEB0,0x60CEE0))


def snapshot(c,owned):
    with base.original.frozen(c.h,c.pid) as frames:
        manager,rows=startup.graph(c)
        game=word(c.get(0x7A49FC,4))
        row=dict(elapsed=owned.elapsed(),frames=frames,manager_hex=manager.hex(),
            registered_tasks=rows,MAIN_event_hex=c.get(c.main+0x2C,8).hex(),game=game,
            keyboard_hex=c.get(game+0x10B8,0xA00).hex(),mouse_hex=c.get(game+0x196C,0x58).hex(),
            scenario_hex=c.get(0x7F4488,80).hex(),VM_hex=c.get(base.native.VM,128).hex(),
            scene_global=word(c.get(0x7A4174,4)),group90_hex=c.get(game+0xB14,8).hex(),
            tasks=[])
        for node in rows:
            head=bytes.fromhex(node['head_hex']);pointer=node['pointer'];vt=word(head)
            task=dict(pointer=pointer,vtable=vt,vtable_hex=c.get(vt,8).hex(),
                      header_hex=c.get(pointer,64).hex(),thread_id=word(head,0x24))
            frame=next((f for f in frames if f['tid']==task['thread_id']),None)
            if frame and {0x421F8A,0x56E183}<={f['return_va'] for f in frame['chain']}:
                task['TLS']=base.capture_tls(c,frame,pointer)
                task['TLS']['index_memory']=dict(pointer=0x761BC0,hex=c.get(0x761BC0,4).hex())
                if task['TLS']['TLS_index']>=64:
                    p=task['TLS']['TEB']+0xF94
                    task['TLS']['expansion_memory']=dict(pointer=p,hex=c.get(p,4).hex())
            if vt==0x59A430:
                task['scene_head_hex']=c.get(pointer,0x200).hex()
                task['controller_task_backpointer']=word(c.get(pointer+0x190+0x117C38,4))
            row['tasks'].append(task)
        return row


def continue_menu(pid,owned,progress,duration):
    report=dict(pid=pid,error=None,samples=[],workers=[],host_game_calls=[],host_memory_writes=[],
        collector_input_actions=[],full_battle_exit_accepted=False,full_native_instruction_trace=False)
    c=None;handles={};started=time.monotonic()
    try:
        # Reuse the immutable observer as a current native phase, never its old handles.
        report['startup']=startup.probe(pid,owned,progress,min(duration-30,720))
        need(report['startup']['error'] is None and report['startup']['native_handoff_observed'],
             'current native startup must retire before menu continuation')
        h=base.original.openp(0x100450,False,pid)
        base.original.check(h,'read-only current menu owner')
        c=SimpleNamespace(h=h,pid=pid,owned=owned,get=lambda p,n:base.original.required(h,p,n))
        c.main=word(c.get(0x7A4A00,4));report['main']=c.main
        identity=clone(base.source_identity,RANGES=RANGES,IAT=startup.IAT)
        report['source_before']=identity(c)
        report['TLS_implementation']=base.tls_contract(c)
        report['manager_event']=base.event_identity(c,word(c.get(c.main+0x17C,4)))
        deadline=min(started+duration,time.monotonic()+300);last_signature=None;last_saved=0
        stop=Path(str(progress).removesuffix('.progress.json')+'.stop.json')
        while time.monotonic()<deadline:
            row=snapshot(c,owned)
            for task in row['tasks']:
                head=bytes.fromhex(task['header_hex']);tid=word(head,0x24)
                if not word(head,0x20) or not tid:continue
                key=(task['pointer'],tid)
                if key not in handles:
                    handle=W.HANDLE()
                    base.original.check(base.parent.duplicate(h,word(head,0x20),base.parent.current_process(),
                        C.byref(handle),0,False,2),'retain current original worker')
                    try:
                        need(base.get_thread_pid(handle)==pid and base.get_thread_id(handle)==tid,'same worker owner')
                        event=base.event_identity(c,word(head,0x1C))
                    except BaseException:
                        base.original.close(handle);raise
                    handles[key]=handle
                    report['workers'].append(dict(pointer=key[0],thread_id=tid,vtable=task['vtable'],
                        original_handle=word(head,0x20),event=event,first_elapsed=row['elapsed']))
            for worker in report['workers']:
                if 'exit' in worker:continue
                handle=handles[(worker['pointer'],worker['thread_id'])]
                status=base.original.wait(handle,0)
                need(status in (0,258),'successful zero-time worker status query')
                if status==0:
                    code=W.DWORD();base.original.check(base.parent.exit_thread(handle,C.byref(code)),'original worker exit')
                    worker['exit']=dict(code=code.value,wait_status=status,elapsed=owned.elapsed(),before_WM_CLOSE=True)
                    need(code.value==0,'abnormal original worker termination')
            signature=(tuple((t['pointer'],t['vtable']) for t in row['tasks']),
                row['MAIN_event_hex'],row['VM_hex'][56:72],row['mouse_hex'][96:104])
            now=time.monotonic()
            if signature!=last_signature or now-last_saved>=1:
                need(len(report['samples'])<2000,'bounded menu snapshot retention')
                row['index']=len(report['samples']);report['samples'].append(row)
                last_saved=now;last_signature=signature
                progress.write_text(json.dumps(dict(status='observing_menu_continuation',pid=pid,
                    elapsed=owned.elapsed(),samples=len(report['samples']),
                    tasks=[dict(pointer=t['pointer'],vtable=hex(t['vtable'])) for t in row['tasks']],
                    VM_PC=word(bytes.fromhex(row['VM_hex']),28),
                    mouse_hex=row['mouse_hex'],host_game_calls=0,collector_input_actions=0)),encoding='utf8')
            if stop.exists():
                raw=stop.read_bytes();need(len(raw)<=1024 and json.loads(raw)=={'stop':True},'explicit observation stop only')
                report['stop_reason']='controller_finished_observation';break
            time.sleep(.05)
        report.setdefault('stop_reason','bounded_menu_deadline')
        report['source_after']=identity(c)
        need(report['source_before']==report['source_after'],'original menu code unchanged')
    except Exception as exc:
        report.update(error=repr(exc),traceback=traceback.format_exc(limit=8))
    finally:
        for handle in handles.values():base.original.close(handle)
        if c:base.original.close(c.h)
    return report


def run(out,seconds):
    paths=[Path(__file__),Path(startup.__file__),Path(base.__file__),ROOT/'devtools/terminal_scene_resources.py']
    identities=[base.identity(p) for p in paths]
    result=clone(base.run,run_probe=continue_menu)(out,seconds)
    need(identities==[base.identity(p) for p in paths],'observation implementation unchanged throughout native run')
    need(base.sha(startup.PARENT.read_bytes())==startup.PARENT_SHA,'fixed immutable asset parent')
    parent=json.loads(gzip.decompress(startup.PARENT.read_bytes()))
    inventory=result['runtime'].pop('immutable_files')
    need(inventory==parent['runtime']['immutable_files'],'freshly hashed native assets match fixed parent')
    result['runtime']['immutable_files_reference']=dict(path=startup.PARENT.relative_to(ROOT).as_posix(),
        sha256=startup.PARENT_SHA,rows=len(inventory),freshly_hashed_this_lifetime=True)
    result.update(kind='original_menu_continuation_observation',implementations=identities,
        human_operation_required=False,host_game_roots_called=False,full_battle_exit_accepted=False)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=720);args=parser.parse_args();out=args.out.resolve()
    need(out.is_relative_to(ROOT/'analysis') and not out.exists(),'fresh bounded local output')
    need(300<=args.seconds<=900,'bounded native observation')
    result=run(out,args.seconds);raw=json.dumps(result,separators=(',',':')).encode()
    need(len(raw)<=48*1024*1024,'bounded raw evidence');packed=gzip.compress(raw,mtime=0)
    need(len(packed)<=4*1024*1024,'bounded compressed evidence')
    with out.open('xb') as stream:stream.write(packed)
    print(json.dumps(dict(report=base.identity(out),probe_error=(result.get('probe') or {}).get('error'),
                          lifecycle_error=result['lifecycle']['error'])),flush=True)
    if (result.get('probe') or {}).get('error') or result['lifecycle']['error']:raise SystemExit(1)


if __name__=='__main__':main()
