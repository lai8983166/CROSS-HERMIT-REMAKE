import gzip,json,sys,time,shutil,struct
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_monitor_v3 import Monitor
from devtools.vmware_vmss_cpu_v2 import read_cpu_groups
from devtools.vmware_vmss_state import decode_cpu_report
out=WORKER/'vm-monitor-snapshot-v1-20261110.json'
cpuout=WORKER/'vm-monitor-snapshot-cpu-v1-20261110.json.gz'
name='owned-vmm-state-preflight-v1-20261110'
if out.exists()or cpuout.exists():raise ValueError('fresh outputs')
r=dict(accepted=False,host_input_actions=0,original_game_started=False,errors=[],snapshot_name=name)
r['guest_before']=json.loads(run_script(STATUS))
if run_script("if(@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};'idle'").strip()!='idle':raise ValueError('idle')
r['snapshots_before']=vmrun(['listSnapshots',VMX]);
if r['snapshots_before'].strip()!='Total snapshots: 0':raise ValueError('no existing snapshots')
if shutil.disk_usage(WORKER).free<10*1024**3:raise ValueError('bounded transient snapshot needs 10 GiB free')
before={p.name for p in WORKER.iterdir()};m=None;created=False;t=time.monotonic()
def cores():
    rows=[]
    for cpu in (1,2):
        if m.query(('Hg%d'%cpu).encode())!=b'OK':raise ValueError('select CPU')
        rows.append(m.query(b'g').decode())
    return rows
try:
    m=Monitor();r['stop']=m.query(b'?').decode();r['g_before']=cores()
    r['snapshot_output']=vmrun(['snapshot',VMX,name],timeout=60);created=True
    r['snapshot_seconds']=time.monotonic()-t
    new=[p for p in WORKER.iterdir()if p.name not in before and p.is_file()]
    r['temporary_created_files']=[dict(path=str(p),bytes=p.stat().st_size)for p in new]
    meta=[p for p in new if p.suffix=='.vmsn']
    if len(meta)!=1:raise ValueError('one fresh owned snapshot metadata')
    raw=read_cpu_groups(meta[0]);decoded=decode_cpu_report(raw)
    with cpuout.open('xb')as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as z:z.write(json.dumps(raw,separators=(',',':')).encode())
    r['cpu_evidence']=identity(cpuout);r['metadata']=dict(path=str(meta[0]),bytes=meta[0].stat().st_size)
    r['g_after']=cores();r['core_unchanged']=r['g_before']==r['g_after']
    names='rax rbx rcx rdx rsi rdi rbp rsp r8 r9 r10 r11 r12 r13 r14 r15'.split()
    r['checkpoint_core_matches']=[]
    for g,c in zip(r['g_before'],decoded['cpus']):
        b=bytes.fromhex(g);vals=struct.unpack('<17QI',b[:140])
        r['checkpoint_core_matches'].append(all(c['gpr64'][n]==v for n,v in zip(names,vals[:16]))and c['rip64']==vals[16]and c['eflags']==vals[17])
    if not r['core_unchanged']or not all(r['checkpoint_core_matches']):raise ValueError('same paused epoch required')
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if created:
        try:
            r['delete_owned_snapshot']=vmrun(['deleteSnapshot',VMX,name],timeout=60)
            r['snapshots_after']=vmrun(['listSnapshots',VMX]);validate_vmx(VMX.read_text(encoding='utf8'))
            r['temporary_files_remaining']=[str(p)for p in WORKER.iterdir()if p.name not in before and p.suffix in('.vmsn','.vmem','.vmdk')]
        except Exception as exc:r['errors'].append('snapshot cleanup: '+repr(exc))
    if m:
        try:m.close();r['detached']=True
        except Exception as exc:r['errors'].append('detach: '+repr(exc))
        r['transcript']=m.rows
    try:r['guest_after']=json.loads(run_script(STATUS))
    except Exception as exc:r['errors'].append('guest: '+str(exc))
    r['elapsed_seconds']=time.monotonic()-t
    r['bounded_idle_preflight_passed']=not r['errors']and r.get('core_unchanged')and all(r.get('checkpoint_core_matches',[]))and not r.get('temporary_files_remaining')
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('transcript','g_before','g_after')},indent=2))
if not r['bounded_idle_preflight_passed']:raise SystemExit(1)
