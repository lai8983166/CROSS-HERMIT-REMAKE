from pathlib import Path
W=Path('F:/project/chaomofa/.venv-audit/native-worker')
s=(W/'probe-vm-monitor-v3.py').read_text().replace('availability-v3-20261109','availability-v4-20261109')
old="        row['g']=decode_registers(m.query(b'g'),annexes);r['threads'].append(row)"
new="""        raw_g=m.query(b'g');row['raw_g_hex']=raw_g.hex()
        try:row['g']=decode_registers(raw_g,annexes)
        except Exception as exc:row['register_decode_error']=str(exc)
        r['threads'].append(row)"""
if s.count(old)!=1:raise ValueError('exact diagnostics-only adaptation')
s=s.replace(old,new)
with(W/'probe-vm-monitor-v4.py').open('x',encoding='utf8')as f:f.write(s)
