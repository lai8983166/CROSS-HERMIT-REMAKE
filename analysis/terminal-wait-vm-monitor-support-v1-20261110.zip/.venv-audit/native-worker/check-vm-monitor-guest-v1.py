import json,sys,zipfile
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'vm-monitor-guest-checks-v1-20261110.json';bundle=WORKER/'vm-monitor-guest-checks-v1-20261110.zip'
guest=PureWindowsPath('C:/ChaomofaWorker/vm-monitor-checks-v1-20261110');q=str(guest)
if out.exists()or bundle.exists():raise ValueError('fresh guest check outputs')
files=sorted((R/'devtools').glob('vmware_*.py'))+sorted((R/'devtools/tests').glob('test_vmware_*.py'))
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED)as z:
    for p in files:z.writestr(p.relative_to(R).as_posix(),p.read_bytes())
    z.writestr('devtools/__init__.py','');z.writestr('devtools/tests/__init__.py','')
remote=PureWindowsPath('C:/ChaomofaWorker/vm-monitor-guest-checks-v1-20261110.zip')
vmrun(['CopyFileFromHostToGuest',VMX,bundle,remote],guest=True)
run_script("if(Test-Path -LiteralPath '"+q+"'){throw 'fresh folder'};Expand-Archive -LiteralPath '"+str(remote)+"' -DestinationPath '"+q+"';'expanded'")
r=dict(accepted=False,original_game_started=False,host_input_actions=0,guest=json.loads(run_script(STATUS)),bundle=identity(bundle),files=[identity(p)for p in files],tests=[])
for flag,label in [('', 'ordinary'),('-O ','optimized')]:
    script="Set-Location -LiteralPath '"+q+"';$env:TEMP='C:\\ChaomofaWorker\\temp';$env:TMP=$env:TEMP;$env:PYTHONDONTWRITEBYTECODE='1';$psi=New-Object System.Diagnostics.ProcessStartInfo;$psi.FileName='C:\\ChaomofaWorker\\Python\\python.exe';$psi.Arguments='-B "+flag+"-X utf8 -m unittest discover -s devtools/tests -p test_vmware_*.py';$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory='"+q+"';$p=[Diagnostics.Process]::Start($psi);$stdout=$p.StandardOutput.ReadToEnd();$stderr=$p.StandardError.ReadToEnd();$p.WaitForExit();[pscustomobject]@{exit_code=$p.ExitCode;stdout=$stdout;stderr=$stderr}|ConvertTo-Json -Compress"
    got=json.loads(run_script(script));got['mode']=label;r['tests'].append(got)
    if got['exit_code']:break
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r['tests'],indent=2))
if len(r['tests'])!=2 or any(x['exit_code']for x in r['tests']):raise SystemExit(1)
