import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_wait_fixture import prepare
folder=WORKER/'vm-wait-fixture-v1-20261110';guest=PureWindowsPath('C:/ChaomofaWorker/vm-wait-fixture-v1-20261110')
out=WORKER/'vm-wait-fixture-deployment-v1-20261110.json'
if out.exists():raise ValueError('fresh deployment')
idle=run_script("$p=@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue);if($p.Count){throw 'busy'};'idle'")
if idle.strip()!='idle':raise ValueError('idle guest')
prepare(folder);q=str(guest)
run_script("if(Test-Path -LiteralPath '"+q+"'){throw 'fresh fixture dir'};New-Item -ItemType Directory -Path '"+q+"'|Out-Null;'created'")
for name in ('fixture.bin','manifest.json','terminal_vm_wait_fixture.cs'):vmrun(['CopyFileFromHostToGuest',VMX,folder/name,guest/name],guest=True)
script="$env:TEMP='C:\\ChaomofaWorker\\temp';$env:TMP=$env:TEMP;$output=& C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe /nologo /platform:x86 /r:System.Web.Extensions.dll '/out:"+q+"\\fixture.exe' '"+q+"\\terminal_vm_wait_fixture.cs' 2>&1;$rc=$LASTEXITCODE;[pscustomobject]@{exit_code=$rc;compiler_output=($output -join \"`n\")}|ConvertTo-Json -Compress"
result=json.loads(run_script(script));result.update(accepted=False,guest=json.loads(run_script(STATUS)),host_input_actions=0,native_fixture_started=False)
if result['exit_code']==0:vmrun(['CopyFileFromGuestToHost',VMX,guest/'fixture.exe',folder/'fixture.exe'],guest=True)
result['files']=[identity(p)for p in folder.iterdir()if p.is_file()]
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items()if k not in ('guest','files')},indent=2))
if result['exit_code']:raise SystemExit(1)
