import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER
from devtools.terminal_vm_monitor_v3 import Monitor
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'vm-monitor-resume-v2-20261110.json'
if out.exists():raise ValueError('fresh recovery receipt')
r=dict(accepted=False,host_input_actions=0,original_game_started=False,errors=[])
m=None
try:
    m=Monitor();r['stopped_before_continue']=m.query(b'?').decode();m.send(b'c');time.sleep(.1)
    m.close();r['detached']=True
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if m and m.sock:
        try:m.close()
        except Exception as exc:r['errors'].append('detach: '+repr(exc))
    if m:r['transcript']=m.rows
try:r['guest_after']=json.loads(run_script(STATUS))
except Exception as exc:r['errors'].append('guest: '+str(exc))
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k!='transcript'},indent=2))
