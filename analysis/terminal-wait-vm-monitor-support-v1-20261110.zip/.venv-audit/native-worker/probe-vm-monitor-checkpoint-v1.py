"""Pause only the dedicated idle VM, then save that same VMM epoch."""
import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_monitor_v3 import Monitor
out=WORKER/'vm-monitor-checkpoint-v1-20261109.json'
if out.exists()or list(WORKER.glob('*.vmss')):raise ValueError('fresh checkpoint preflight; no existing saved state')
state=json.loads(run_script(STATUS))
idle=run_script("$p=@(Get-Process 'CROSS HERMIT',python,pythonw,helper -ErrorAction SilentlyContinue);if($p.Count){throw 'busy'};'idle'")
if idle.strip()!='idle':raise ValueError('idle guest')
r=dict(accepted=False,fullstate=False,fullABI=False,host_input_actions=0,original_game_started=False,guest=state,errors=[],vCPUs=[])
m=None
try:
    m=Monitor();r['endpoint']=m.owner;r['stop']=m.query(b'?').decode();r['qSupported']=m.query(b'qSupported').decode()
    threads=m.query(b'qfThreadInfo');end=m.query(b'qsThreadInfo')
    if threads!=b'm1,2'or end!=b'l':raise ValueError('two exact vCPU IDs')
    for tid in ('1','2'):
        if m.query(('Hg'+tid).encode())!=b'OK':raise ValueError('select actual vCPU')
        r['vCPUs'].append(dict(id=tid,g=m.query(b'g').decode(),cr3_packets=[p.hex()for p in m.monitor('r cr3')]))
    r['suspend_started_monotonic']=time.monotonic()
    # VMM hard suspend saves state directly; no guest suspend script runs.
    r['suspend_output']=vmrun(['suspend',VMX,'hard'],timeout=60)
    r['suspend_elapsed_seconds']=round(time.monotonic()-r['suspend_started_monotonic'],3)
    r['running_vms_after']=vmrun(['list'])
    if str(VMX).lower()in r['running_vms_after'].lower():raise ValueError('dedicated VM did not suspend')
    vmss=list(WORKER.glob('*.vmss'))
    if len(vmss)!=1:raise ValueError('one current VM saved-state file')
    r['saved_state']=identity(vmss[0]);r['runtime_memory']=[dict(path=str(p),bytes=p.stat().st_size)for p in WORKER.glob('*.vmem')]
    r['checkpoint_saved']=True
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if m:
        r['transcript']=m.rows
        if r.get('checkpoint_saved'):
            m.sock.close();m.sock=None;r['debugger_socket_closed_after_saved_VM']=True
        else:
            try:m.close();r['detached']=True
            except Exception as exc:r['errors'].append('detach: '+repr(exc))
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('transcript','endpoint','guest','vCPUs')},indent=2))
