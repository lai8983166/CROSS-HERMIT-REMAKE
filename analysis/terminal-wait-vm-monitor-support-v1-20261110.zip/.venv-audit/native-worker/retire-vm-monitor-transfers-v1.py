import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script
out=WORKER/'vm-monitor-transfer-retirement-v1-20261110.json';retained=WORKER/'vm-monitor-guest-retained-v1-20261110'
if out.exists()or retained.exists():raise ValueError('fresh retention outputs')
roots=['C:\\ChaomofaWorker\\'+n for n in('vm-wait-fixture-v1-20261110','vm-wait-baseline-v1-20261110','vm-monitor-checks-v1-20261110')]
archive='C:\\ChaomofaWorker\\vm-monitor-guest-checks-v1-20261110.zip'
rootlist=','.join("'"+p+"'"for p in roots)
inventory="$files=@();foreach($root in @("+rootlist+")){if(!(Test-Path -LiteralPath $root)){throw 'expected owned folder'};$files+=@(Get-ChildItem -LiteralPath $root -Recurse -File)};$files+=Get-Item -LiteralPath '"+archive+"';$rows=@($files|ForEach-Object{[pscustomobject]@{path=$_.FullName;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}});ConvertTo-Json -InputObject @($rows) -Compress"
rows=json.loads(run_script(inventory));retained.mkdir()
candidates=sorted((R/'devtools').glob('vmware_*.py'))+sorted((R/'devtools/tests').glob('test_vmware_*.py'))+list((WORKER/'vm-wait-fixture-v1-20261110').glob('*'))
candidates += [WORKER/'vm-monitor-guest-checks-v1-20261110.zip',R/'devtools/terminal_vm_wait_observer_gate.py',R/'devtools/tests/test_terminal_vm_wait_observer_gate.py',R/'analysis/terminal-wait-vm-monitor-breakpoint-failure-v1-20261110.json']
known={}
for p in candidates:
    if p.is_file():row=identity(p);known.setdefault((row['bytes'],row['sha256']),row)
mapped=[]
for row in rows:
    key=(row['bytes'],row['sha256'])
    if row['bytes']>1024**2:raise ValueError('bounded current transfer')
    if key not in known:
        target=retained/(row['sha256'][:16]+PureWindowsPath(row['path']).suffix)
        vmrun(['CopyFileFromGuestToHost',VMX,PureWindowsPath(row['path']),target],guest=True)
        got=identity(target)
        if (got['bytes'],got['sha256'])!=key:raise ValueError('exact guest artifact retention')
        known[key]=got
    mapped.append(dict(guest=row,retained=known[key]))
removed=[]
for item in mapped:
    row=item['guest'];path=row['path'].replace("'","''")
    script="$p=(Resolve-Path -LiteralPath '"+path+"').ProviderPath;$roots=@("+rootlist+");$allowed=$p -eq '"+archive+"';foreach($root in $roots){$allowed=$allowed -or $p.StartsWith($root+'\\',[StringComparison]::OrdinalIgnoreCase)};if(!$allowed){throw 'outside exact current transfer roots'};$f=Get-Item -LiteralPath $p;if($f.PSIsContainer -or $f.Length -ne "+str(row['bytes'])+" -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne '"+row['sha256']+"'){throw 'changed transfer'};Remove-Item -LiteralPath $p;if(Test-Path -LiteralPath $p){throw 'removal failed'};'removed'"
    if run_script(script).strip()!='removed':raise ValueError('exact guest retirement')
    removed.append(row)
remaining=run_script("$n=0;foreach($root in @("+rootlist+")){$n+=(@(Get-ChildItem -LiteralPath $root -Recurse -File|Measure-Object Length -Sum)[0].Sum)};if(Test-Path -LiteralPath '"+archive+"'){$n+=(Get-Item -LiteralPath '"+archive+"').Length};[pscustomobject]@{remaining_current_round_guest_files_bytes=$n;active_fixtures=@(Get-Process fixture -ErrorAction SilentlyContinue|Select-Object Id,SessionId)}|ConvertTo-Json -Depth 4 -Compress")
r=dict(accepted=False,host_input_actions=0,retained_mappings=mapped,removed=removed,total_removed_bytes=sum(x['bytes']for x in removed),after=json.loads(remaining),all_removed=len(removed)==len(rows),historical_files_removed=False)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('retained_mappings','removed')},indent=2))
