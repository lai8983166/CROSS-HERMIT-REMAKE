import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_monitor_v3 import Monitor
from devtools.vmware_rsp_state import register_layout
out=WORKER/'vm-monitor-registers-v1-20261109.json'
if out.exists():raise ValueError('new register capability report')
parent=WORKER/'vm-monitor-availability-v4-20261109.json';prior=json.loads(parent.read_bytes())
state=json.loads(run_script(STATUS))
if state!=prior['guest']:raise ValueError('same exact current VM boot')
layout=register_layout({k:v.encode()for k,v in prior['annexes'].items()})
r=dict(parent=identity(parent),accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,errors=[],queries={})
m=None
try:
    m=Monitor();r['stop']=m.query(b'?').decode();r['endpoint']=m.owner
    r['qSupported']=m.query(b'qSupported').decode()
    for reg in (0,23,24,32,40,56):r['queries'][str(reg)]=m.query(('p'+format(reg,'x')).encode()).decode()
    capable=all(len(r['queries'][str(reg)])==layout['registers'][reg]['bitsize']//4 for reg in (24,32,40,56))
    r['four_missing_register_reads_sized']=capable
    if capable:
        for reg in range(24,57):
            if str(reg)not in r['queries']:r['queries'][str(reg)]=m.query(('p'+format(reg,'x')).encode()).decode()
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if m:
        try:m.close();r['detached']=True
        except Exception as exc:r['errors'].append('detach: '+repr(exc))
        r['transcript']=m.rows
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('transcript','endpoint')},indent=2))
