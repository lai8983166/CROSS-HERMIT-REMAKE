"""One true NtWait return checkpoint, then normal completion of owned waits."""
import concurrent.futures as cf,gzip,json,re,struct,sys,time
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_monitor_v4 import Monitor
from devtools.vmware_rsp_state import decode_monitor_reply
from devtools.vmware_rsp_state_v2 import parse_monitor_register
from devtools.vmware_vmss_cpu_v2 import read_cpu_groups
out=WORKER/'vm-wait-fixture-run-v1-20261110.json';cpuout=WORKER/'vm-wait-fixture-cpu-v1-20261110.json.gz'
folder=WORKER/'vm-wait-fixture-v1-20261110';guest=PureWindowsPath('C:/ChaomofaWorker/vm-wait-fixture-v1-20261110');q=str(guest)
name='owned-wait-cpu-v1-20261110';r=dict(accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,errors=[],false_hits=[])
if out.exists()or cpuout.exists():raise ValueError('fresh outputs')
if vmrun(['listSnapshots',VMX]).strip()!='Total snapshots: 0':raise ValueError('no prior snapshots')
if run_script("if(@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};'idle'").strip()!='idle':raise ValueError('idle guest')
r['guest_before']=json.loads(run_script(STATUS));r['fixture_exe']=identity(folder/'fixture.exe')
pool=cf.ThreadPoolExecutor(max_workers=2);m=None;snapshot=None;ready=None;t=time.monotonic()
def need(v,s):
    if not v:raise ValueError(s)
def memory(address,size):
    raw=m.query(('m%x,%x'%(address,size)).encode());b=bytes.fromhex(raw.decode());need(len(b)==size,'exact guest read');return b
def cpu_from_stop(stop):
    match=re.search(rb'thread:([0-9a-f]+);',stop);need(match,'actual stopped CPU');return int(match[1],16)
def select(cpu):need(m.query(('Hg%x'%cpu).encode())==b'OK','select stopped CPU')
def cores():
    values=[]
    for cpu in(1,2):select(cpu);values.append(m.query(b'g').decode())
    return values
def gates(names):
    text=';'.join("[IO.File]::WriteAllText('"+q+'\\'+s+"','continue')"for s in names)
    return run_script(text+";'gate-written'")
try:
    command="$p=Start-Process -FilePath '"+q+"\\fixture.exe' -ArgumentList @('--owned-vmm-fixture','"+q+"') -WindowStyle Hidden -PassThru;$end=[DateTime]::UtcNow.AddSeconds(10);while(!(Test-Path -LiteralPath '"+q+"\\ready.json')){if($p.HasExited){throw 'fixture exited before ready'};if([DateTime]::UtcNow -gt $end){throw 'ready deadline'};Start-Sleep -Milliseconds 50};Get-Content -LiteralPath '"+q+"\\ready.json' -Raw"
    ready=json.loads(run_script(command));r['ready']=ready
    need(ready['source_sha256']==identity(folder/'terminal_vm_wait_fixture.cs')['sha256'],'fixture source binding')
    m=Monitor();r['initial_stop']=m.query(b'?').decode();bp=('%x,1'%ready['return_pc']).encode()
    need(m.query(b'Z1,'+bp)==b'OK','VMM hidden hardware return breakpoint')
    pending_go=pool.submit(gates,['go']);m.send(b'c')
    for attempt in range(24):
        stop=m.receive(timeout=8);cpu=cpu_from_stop(stop);select(cpu);g=m.query(b'g');b=bytes.fromhex(g.decode())
        rip=int.from_bytes(b[128:136],'little');cs=int.from_bytes(b[140:144],'little');sp=int.from_bytes(b[56:64],'little')
        row=dict(stop=stop.decode(),cpu=cpu,g=g.decode())
        if rip==ready['return_pc']and cs==0x23:
            fs=parse_monitor_register('r fs',decode_monitor_reply(m.monitor('r fs')));row['fs']=fs
            teb=fs['fields']['reported_base'];ids=struct.unpack('<II',memory(teb+0x20,8));row['teb_client_id']=ids
            if list(ids)==[ready['pid'],ready['tid']]:
                stack=memory(sp,64);row['stack_hex']=stack.hex()
                words=struct.unpack('<4I',stack[:16])
                if list(words)==[ready['postcall_pc'],ready['event_handle'],0,ready['timeout_pointer']]:
                    need(int.from_bytes(b[:8],'little')==0,'actual successful NtWait result')
                    r['wait_return']=row;r['go_result']=pending_go.result(timeout=5);break
        r['false_hits'].append(row)
        need(m.query(b'z1,'+bp)==b'OK','temporarily remove shared-address breakpoint')
        m.send(b's');step=m.receive(timeout=3);need(step[:1]in(b'S',b'T'),'step past unrelated return')
        need(m.query(b'Z1,'+bp)==b'OK','restore owned hardware breakpoint');m.send(b'c')
    else:raise ValueError('bounded unrelated wait returns')
    r['nt_wait_at_stop']=memory(ready['nt_wait'],32).hex();need(r['nt_wait_at_stop']==ready['nt_wait_before'],'original NtWait bytes unchanged')
    r['data_at_stop']=memory(ready['data'],16384).hex()
    r['counters_before']=memory(ready['data']+0x300,8).hex();time.sleep(.1);r['counters_after_dwell']=memory(ready['data']+0x300,8).hex()
    need(r['counters_before']==r['counters_after_dwell'],'both pinned CPU loops stopped')
    r['p_registers']={str(i):m.query(('p%x'%i).encode()).decode()for i in range(24,57)}
    r['g_before_snapshot']=cores();select(cpu)
    old={p.name for p in WORKER.glob('*.vmsn')};snapshot=pool.submit(vmrun,['snapshot',VMX,name],timeout=90)
    deadline=time.monotonic()+35;last=None;stable=0;raw=None
    while time.monotonic()<deadline:
        metas=[p for p in WORKER.glob('*.vmsn')if p.name not in old]
        if len(metas)==1:
            try:
                candidate=read_cpu_groups(metas[0]);key=candidate['cpu_groups'][0]['sha256']
                if key==last:stable+=1
                else:stable=0;last=key
                if stable>=2:raw=candidate;r['snapshot_metadata_path']=str(metas[0]);break
            except(OSError,ValueError):pass
        time.sleep(.25)
    need(raw is not None,'bounded snapshot CPU metadata ready while stopped')
    with cpuout.open('xb')as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as z:z.write(json.dumps(raw,separators=(',',':')).encode())
    r['cpu_evidence']=identity(cpuout);r['snapshot_cpu_seconds']=time.monotonic()-t
    r['g_after_snapshot']=cores();select(cpu);r['counters_after_snapshot']=memory(ready['data']+0x300,8).hex()
    need(r['g_before_snapshot']==r['g_after_snapshot'],'both CPU cores unchanged across snapshot')
    need(r['counters_before']==r['counters_after_snapshot'],'both CPUs stayed stopped across snapshot')
    need(m.query(b'z1,'+bp)==b'OK','remove owned breakpoint before continuing');m.close();r['detached']=True
    r['snapshot_completed']=snapshot.result(timeout=60)
    r['metadata_final']=identity(Path(r['snapshot_metadata_path']))
    r['temporary_snapshot_files']=[dict(path=str(p),bytes=p.stat().st_size)for p in WORKER.glob(Path(r['snapshot_metadata_path']).stem+'.*')if p.is_file()]
    r['delete_snapshot']=vmrun(['deleteSnapshot',VMX,name],timeout=30);validate_vmx(VMX.read_text(encoding='utf8'))
    r['first_return']=json.loads(run_script("Get-Content -LiteralPath '"+q+"\\returned-0.json' -Raw"))
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if m:
        try:m.close()
        except Exception as exc:r['errors'].append('detach '+repr(exc))
        r['transcript']=m.rows
    if snapshot:
        try:
            snapshot.result(timeout=60)
            snaps=vmrun(['listSnapshots',VMX])
            if name in snaps.splitlines():r['cleanup_owned_snapshot']=vmrun(['deleteSnapshot',VMX,name],timeout=30)
        except Exception as exc:r['errors'].append('snapshot cleanup '+repr(exc))
    if ready:
        try:
            gates(['go','ack-0','ack-1','ack-2','ack-3'])
            final=run_script("$end=[DateTime]::UtcNow.AddSeconds(10);while(!(Test-Path -LiteralPath '"+q+"\\result.json')){if([DateTime]::UtcNow -gt $end){throw 'result deadline'};Start-Sleep -Milliseconds 50};Get-Content -LiteralPath '"+q+"\\result.json' -Raw")
            result=json.loads(final);r['fixture_result']=result
            with(folder/'result.json').open('x',encoding='utf8')as f:f.write(final)
        except Exception as exc:r['errors'].append('fixture cleanup '+repr(exc))
    pool.shutdown(wait=True)
    r['elapsed_seconds']=time.monotonic()-t
    try:r['guest_after']=json.loads(run_script(STATUS))
    except Exception as exc:r['errors'].append('guest '+str(exc))
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('transcript','fixture_result','g_before_snapshot','g_after_snapshot','data_at_stop','p_registers')},indent=2))
if r['errors']:raise SystemExit(1)
