import json,sys,time,re
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.terminal_vm_monitor_v2 import Monitor,need
from devtools.vmware_rsp_state import decode_registers,decode_monitor_reply
out=WORKER/'vm-monitor-availability-v2-20261109.json'
need(not out.exists(),'fresh monitor report')
state=json.loads(run_script(STATUS));need(state['cpu']==2 and 4000000000<state['memory']<4500000000,'bounded actual guest')
need(run_script("$p=@(Get-Process 'CROSS HERMIT',python,pythonw,helper -ErrorAction SilentlyContinue);if($p.Count){throw 'guest busy'};'idle'").strip()=='idle','idle guest')
paths=[R/"devtools/terminal_vm_monitor_v2.py",R/'devtools/terminal_vm_monitor.py',R/'devtools/vmware_rsp_state.py'];before=[identity(p)for p in paths]
r=dict(accepted=False,original_game_started=False,fullstate=False,fullABI=False,host_input_actions=0,guest=state,implementations=before,errors=[])
m=None;start=time.monotonic()
try:
    m=Monitor();r['endpoint']=m.owner;r['stop']=m.interrupt().decode()
    r['qSupported']=m.query(b'qSupported').decode('ascii')
    annexes={};pending=['target.xml']
    while pending:
        name=pending.pop(0);raw=bytearray()
        for _ in range(8):
            packet=m.query(('qXfer:features:read:'+name+':'+format(len(raw),'x')+',1000').encode())
            need(packet[:1]in(b'm',b'l'),'target XML capability required');raw.extend(packet[1:])
            if packet[:1]==b'l':break
        else:raise ValueError('bounded XML annex')
        annexes[name]=bytes(raw)
        for ref in re.findall(rb'href="([a-zA-Z0-9_.-]+)"',raw):
            n=ref.decode()
            if n not in annexes and n not in pending:pending.append(n)
        need(len(annexes)+len(pending)<=8,'bounded XML include set')
    r['annexes']={k:v.decode()for k,v in annexes.items()}
    ids=[];packet=m.query(b'qfThreadInfo')
    for _ in range(8):
        if packet==b'l':break
        need(packet.startswith(b'm'),'actual monitor thread list');ids+=packet[1:].decode().split(',');packet=m.query(b'qsThreadInfo')
    else:raise ValueError('bounded VMM thread list')
    r['threads']=[]
    for tid in ids:
        need(m.query(('Hg'+tid).encode())==b'OK','select actual VMM thread')
        row=dict(id=tid,extra_hex=m.query(('qThreadExtraInfo,'+tid).encode()).decode())
        row['g']=decode_registers(m.query(b'g'),annexes);r['threads'].append(row)
    r['monitor']={}
    for command in ('help','r','r cr0','r cr2','r cr3','r cr4','r cs','r ss','r ds','r es','r fs','r gs','r gdtr','r idtr','r ldtr','r dr0','r dr7'):
        packets=m.monitor(command)
        r['monitor'][command]=dict(packets_hex=[p.hex()for p in packets])
        try:r['monitor'][command]['text']=decode_monitor_reply(packets).decode('ascii')
        except Exception as exc:r['monitor'][command]['decode_error']=str(exc)
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if m:
        try:m.close();r['detached']=True
        except Exception as exc:r['errors'].append('detach: '+repr(exc));r['detached']=False
        r['transcript']=m.rows
    r['elapsed_seconds']=round(time.monotonic()-start,3)
    r['implementations_unchanged']=before==[identity(p)for p in paths]
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('guest','implementations','transcript','annexes','threads','monitor')},indent=2))
if r.get('monitor'):print(json.dumps({k:v.get('text',v.get('decode_error'))for k,v in r['monitor'].items()},indent=2))
print('report',identity(out))
