import gzip,hashlib,json,struct,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R));W=R/'.venv-audit/native-worker'
from devtools.isolated_windows_vm import identity
from devtools.terminal_vm_wait_observer_gate import witness
out=R/'analysis/terminal-wait-vm-monitor-main-review-v1-20261110.json'
if out.exists():raise ValueError('fresh independent main review')
def need(v,s):
    if not v:raise ValueError(s)
epochs=[(R/'analysis/terminal-wait-vm-monitor-cpu-tags-v1-20261110.json',W/'vm-monitor-checkpoint-v1-20261109.json','vCPUs'),(W/'vm-monitor-snapshot-cpu-v1-20261110.json.gz',W/'vm-monitor-snapshot-v1-20261110.json','g_before')]
checks=[]
for path,source,key in epochs:
    report=json.loads(gzip.decompress(path.read_bytes())if path.suffix=='.gz'else path.read_bytes());s=json.loads(source.read_bytes());group=report['cpu_groups'][0];raw=bytes.fromhex(group['raw_hex'])
    need(len(raw)==group['bytes']and hashlib.sha256(raw).hexdigest()==group['sha256'],'raw CPU identity')
    def read(name,idx,size):
        tags=[x for x in group['tags']if x['name']==name and x['indices']==idx];need(len(tags)==1,'unambiguous tag')
        tag=tags[0];off=tag['data_offset']-group['offset'];data=raw[off:off+size]
        need(tag['disk_size']==tag['memory_size']==size and hashlib.sha256(data).hexdigest()==tag['data_sha256'],'raw tag range identity')
        return data
    rows=[]
    for i,item in enumerate(s[key]):
        g=bytes.fromhex(item['g']if key=='vCPUs'else item);need(len(g)==164,'actual partial RSP core width')
        rsp=struct.unpack('<17Q7I',g);gp=struct.unpack('<16Q',read('gpregs',[i],128))
        # Direct raw-field comparison, independent of canonical-state decoder.
        order=[0,3,1,2,6,7,5,4,8,9,10,11,12,13,14,15]
        need([gp[j]for j in order]==list(rsp[:16]),'16 GPR raw equality')
        need(int.from_bytes(read('rip',[i],8),'little')==rsp[16],'original RIP')
        flags=int.from_bytes(read('eflags',[i],4),'little')|int.from_bytes(read('EFLAGS',[i],4),'little')
        need(flags==rsp[17],'original flags OR')
        need([int.from_bytes(read('S',[i,j],4),'little')for j in(1,2,3,0,4,5)]==list(rsp[18:]),'six raw selectors')
        rows.append(dict(cpu=i,core_registers_matched=24,fullstate=False))
    checks.append(dict(raw_source=identity(path),rsp_source=identity(source),cpus=rows,FX_pointer_mode_proved=False))
baseline=json.loads((W/'vm-wait-baseline-v1-20261110.json').read_bytes());failure=json.loads((W/'vm-wait-fixture-run-v1-20261110.json').read_bytes());b=baseline['result']
need(failure['fixture_exe']['sha256']==baseline['fixture_exe']['sha256'],'same frozen helper binary')
need(baseline['exit_code']==0 and b['returns']==[0,0,0,258]and b['signals']==3 and not b['error']and not b['cleanup_errors'],'unobserved native wait baseline')
need(b['nt_wait_before']==b['nt_wait_after']and b['handles_closed']and b['buffers_released']and b['watchdog_disarmed'],'own helper normal cleanup')
need(b['code_after']==b['ready']['code_hex'],'fixture RX bytes unchanged')
data=bytes.fromhex(b['data_hex']);need(struct.unpack_from('<I',data,0x200)[0]==4,'four original postreturn records')
frames=[]
for i in range(4):
    frame=struct.unpack_from('<9I',data,0x1000+i*0x400+0x200)
    need(frame[0]==0x55556666 and frame[1]==0x33334444 and frame[4]==0x11112222 and frame[7]==(258 if i==3 else 0),'native saved callee registers and result')
    frames.append(dict(index=i,result=frame[7],post_frame_hex=data[0x1000+i*0x400+0x200:0x1000+i*0x400+0x224].hex()))
r=dict(accepted=False,reviewer='main agent; direct raw-field arithmetic independent of subagent canonical-state decoder',idle_cpu_checks=checks,monitor_gate=witness(),baseline_source=identity(W/'vm-wait-baseline-v1-20261110.json'),same_helper_binary=True,baseline_postreturns=frames,self_helper_cleanup_proved=True,original_game_wait_return_captured=False,first_result_consumer_captured=False,three_original_game_handshakes_proved=False,fullstate=False,fullABI=False,original_resource_PTD_cleanup=False)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in('idle_cpu_checks','baseline_postreturns')},indent=2))
