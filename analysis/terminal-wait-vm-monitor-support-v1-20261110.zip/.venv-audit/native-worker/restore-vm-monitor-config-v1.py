import gzip,hashlib,json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
out=WORKER/'vm-monitor-restoration-v1-20261110.json'
if out.exists():raise ValueError('fresh restoration')
running=vmrun(['list'])
if str(VMX).lower()in running.lower():raise ValueError('restore only stopped owned VM')
raw=VMX.read_bytes();fields=validate_vmx(raw.decode('utf8'))
expected={'debugStub.listen.guest64':'TRUE','debugStub.listen.guest64.remote':'FALSE','debugStub.hideBreakpoints':'TRUE'}
if {k:v for k,v in fields.items()if k.startswith('debugStub.')}!=expected:raise ValueError('only our exact monitor settings')
saved=WORKER/'vm-monitor-breakpoint-panic-v1-20261110.log'
with saved.open('xb')as f:f.write((WORKER/'vmware.log').read_bytes())
dump=WORKER/'vmware-vmx.dmp';compressed=WORKER/'vm-monitor-breakpoint-panic-v1-20261110.dmp.gz'
original=identity(dump)
if not 0<original['bytes']<64*1024**2:raise ValueError('bounded unique failure minidump')
with dump.open('rb')as src,compressed.open('xb')as dst:
    with gzip.GzipFile(fileobj=dst,mode='wb',mtime=0)as z:
        for b in iter(lambda:src.read(1024*1024),b''):z.write(b)
h=hashlib.sha256();size=0
with gzip.open(compressed,'rb')as f:
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
if size!=original['bytes']or h.hexdigest()!=original['sha256']:raise ValueError('lossless minidump retention')
before=identity(VMX);new=b''.join(line for line in raw.splitlines(keepends=True)if line.split(b'=',1)[0].strip().decode('ascii',errors='ignore')not in expected)
after_fields=validate_vmx(new.decode('utf8'))
if {k:v for k,v in fields.items()if k not in expected}!=after_fields:raise ValueError('remove only owned settings')
VMX.write_bytes(new)
r=dict(accepted=False,host_input_actions=0,original_game_started=False,running_vms=running,panic_log=identity(saved),minidump_original=original,minidump_lossless_compressed=identity(compressed),compressed_reconstruction_verified=True,vmx_before=before,vmx_after=identity(VMX),removed_settings=expected)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r,indent=2))
