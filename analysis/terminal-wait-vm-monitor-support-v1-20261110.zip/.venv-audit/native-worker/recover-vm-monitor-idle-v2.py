import json,sys,shutil,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
out=WORKER/'vm-monitor-idle-recovery-v2-20261110.json'
if out.exists():raise ValueError('fresh recovery')
prior=json.loads((WORKER/'vm-monitor-checkpoint-v1-20261109.json').read_bytes())
need=prior.get('original_game_started')is False and not prior.get('errors')
if not need:raise ValueError('only idle self-owned monitor preflight recovery')
validate_vmx(VMX.read_text(encoding='utf8'))
saved=WORKER/'vm-monitor-failed-resume-v2-20261110.log'
with saved.open('xb')as f:f.write((WORKER/'vmware.log').read_bytes())
r=dict(accepted=False,host_input_actions=0,original_game_started=False,reason='idle debugger suspend/resume preflight entered persistent kernel loop; both administration paths unavailable',prior_log=identity(saved),before_vmx=identity(VMX))
try:r['tools_state']=vmrun(['checkToolsState',VMX],timeout=10)
except RuntimeError as exc:r['tools_state']=str(exc)
if r['tools_state'].strip() not in ('installed','vmrun failed: unknown'):raise ValueError('recheck changed guest state before recovery')
r['dedicated_idle_vm_power_off']=vmrun(['stop',VMX,'hard'],timeout=30)
r['running_after']=vmrun(['list']);r['after_vmx']=identity(VMX)
if str(VMX).lower()in r['running_after'].lower():raise ValueError('VM must stop')
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('before_vmx','after_vmx')}))
