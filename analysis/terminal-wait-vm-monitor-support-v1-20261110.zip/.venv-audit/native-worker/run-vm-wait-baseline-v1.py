import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'vm-wait-baseline-v1-20261110.json'
source=WORKER/'vm-wait-fixture-v1-20261110';guest=PureWindowsPath('C:/ChaomofaWorker/vm-wait-baseline-v1-20261110');q=str(guest)
if out.exists():raise ValueError('fresh baseline')
run_script("if(@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};if(Test-Path -LiteralPath '"+q+"'){throw 'fresh'};New-Item -ItemType Directory -Path '"+q+"'|Out-Null;'ready'")
for name in('fixture.bin','manifest.json','terminal_vm_wait_fixture.cs','fixture.exe'):
    vmrun(['CopyFileFromHostToGuest',VMX,source/name,guest/name],guest=True)
gates=';'.join("[IO.File]::WriteAllText('"+q+'\\'+name+"','continue')"for name in('go','ack-0','ack-1','ack-2','ack-3'))
script=gates+";$p=Start-Process -FilePath '"+q+"\\fixture.exe' -ArgumentList @('--owned-vmm-fixture','"+q+"') -WindowStyle Hidden -PassThru;if(!$p.WaitForExit(15000)){throw 'bounded baseline deadline'};[pscustomobject]@{exit_code=$p.ExitCode;result=(Get-Content -LiteralPath '"+q+"\\result.json' -Raw|ConvertFrom-Json)}|ConvertTo-Json -Depth 10 -Compress"
r=json.loads(run_script(script));r.update(accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,guest=json.loads(run_script(STATUS)),fixture_exe=identity(source/'fixture.exe'),monitor_attached=False)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
result=r['result'];print(json.dumps({k:v for k,v in result.items()if k not in ('ready','data_hex','code_after')},indent=2))
if r['exit_code']or result['error']or result['returns']!=[0,0,0,258]or result['cleanup_errors']or not result['handles_closed']or not result['buffers_released']:raise SystemExit(1)
