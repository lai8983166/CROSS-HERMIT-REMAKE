import hashlib,json,sys,zipfile
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
out=R/'analysis/terminal-wait-vm-monitor-support-v1-20261110.zip'
if out.exists():raise ValueError('fresh bounded support capsule')
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files=[];excluded=[]
for p in W.rglob('*'):
    if not p.is_file()or p.stat().st_mtime<1794238920:continue
    if p.suffix.lower()in('.vmdk','.vmem','.vmx','.vmxf','.nvram','.vmsd','.vmss','.lck')or p.name.startswith('vmware')or 'credentials'in p.name.lower()or '.private.'in p.name.lower():continue
    if p.name.endswith('.dmp.gz')or p.suffix=='.zip':excluded.append(ident(p));continue
    if p.stat().st_size>1024**2:raise ValueError('bounded support member')
    files.append(p)
manifest=dict(kind='bounded_vmm_preflight_support',accepted=False,baseline_commit='4117c298588e954f24d13c4cab915b3a8c129b88',members=[ident(p)for p in files],excluded_local_files=excluded,
    restore_scope='Original reports and small CPU groups only. Removed VMSS/VMSN metadata/RAM cannot be recreated in full from CPU subsets. Never claim suspended native lifetime restoration.',
    native_reproduction_warning='Frozen failing scripts are audit sources, not an automatic rerun plan. Current ULM hidden breakpoint and suspend/resume paths are disqualified; run the gate before considering any original game.')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files:z.writestr(p.relative_to(R).as_posix(),p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,indent=2).encode())
with zipfile.ZipFile(out)as z:
    for row in manifest['members']:
        b=z.read(row['path'])
        if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('lossless member identity')
print(json.dumps(dict(capsule=ident(out),members=len(files),uncompressed_bytes=sum(p.stat().st_size for p in files))))
