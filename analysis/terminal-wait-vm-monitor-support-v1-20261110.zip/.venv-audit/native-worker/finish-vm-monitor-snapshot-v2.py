import gzip,json,struct,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.vmware_vmss_cpu_v2 import read_cpu_groups
from devtools.vmware_vmss_state import decode_cpu_report
out=WORKER/'vm-monitor-snapshot-finish-v2-20261110.json';cpuout=WORKER/'vm-monitor-snapshot-cpu-v1-20261110.json.gz'
if out.exists()or cpuout.exists():raise ValueError('fresh finish receipt')
prior=json.loads((WORKER/'vm-monitor-snapshot-v1-20261110.json').read_bytes());name=prior['snapshot_name']
if name!='owned-vmm-state-preflight-v1-20261110' or not prior['detached']:raise ValueError('owned idle snapshot')
if vmrun(['listSnapshots',VMX]).splitlines()[-1]!=name:raise ValueError('exact owned sole snapshot')
metadata=WORKER/'chaomofa-worker-Snapshot1.vmsn';raw=read_cpu_groups(metadata)
with cpuout.open('xb')as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as z:z.write(json.dumps(raw,separators=(',',':')).encode())
r=dict(accepted=False,host_input_actions=0,original_game_started=False,errors=[],cpu_evidence=identity(cpuout),metadata=identity(metadata),checkpoint_core_matches=[])
r['decoder_gap']='new VMSN v3 container, pending offline decoder version; raw preserved'
r['snapshot_before_cleanup']=[dict(path=str(p),bytes=p.stat().st_size)for p in WORKER.glob('*Snapshot1.*')]
try:
    r['delete_owned_snapshot']=vmrun(['deleteSnapshot',VMX,name],timeout=60)
    r['snapshots_after']=vmrun(['listSnapshots',VMX]);validate_vmx(VMX.read_text(encoding='utf8'))
    r['guest_after']=json.loads(run_script(STATUS))
except Exception as exc:r['errors'].append(str(exc))
r['remaining_snapshot_files']=[str(p)for p in WORKER.glob('*Snapshot1.*')]
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r,indent=2))
