import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script
guest=PureWindowsPath('C:/ChaomofaWorker/vm-monitor-checks-v1-20261110');q=str(guest)
out=WORKER/'vm-monitor-gate-guest-checks-v1-20261110.json'
if out.exists():raise ValueError('fresh gate verification')
files=['devtools/terminal_vm_wait_observer_gate.py','devtools/tests/test_terminal_vm_wait_observer_gate.py','analysis/terminal-wait-vm-monitor-breakpoint-failure-v1-20261110.json']
run_script("New-Item -ItemType Directory -Path '"+q+"\\analysis'|Out-Null;'created'")
for name in files:vmrun(['CopyFileFromHostToGuest',VMX,R/name,guest/name],guest=True)
rows=[]
for opt in('','-O '):
    script="Set-Location -LiteralPath '"+q+"';$psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='C:\\ChaomofaWorker\\Python\\python.exe';$psi.Arguments='-B "+opt+"-X utf8 -m unittest devtools.tests.test_terminal_vm_wait_observer_gate';$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardError=$true;$psi.RedirectStandardOutput=$true;$psi.WorkingDirectory='"+q+"';$p=[Diagnostics.Process]::Start($psi);$stdout=$p.StandardOutput.ReadToEnd();$stderr=$p.StandardError.ReadToEnd();$p.WaitForExit();[pscustomobject]@{exit_code=$p.ExitCode;stdout=$stdout;stderr=$stderr}|ConvertTo-Json -Compress"
    got=json.loads(run_script(script));got['optimized']=bool(opt);rows.append(got)
r=dict(accepted=False,host_input_actions=0,tests=rows,files=[identity(R/p)for p in files])
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(rows,indent=2))
if any(x['exit_code']for x in rows):raise SystemExit(1)
