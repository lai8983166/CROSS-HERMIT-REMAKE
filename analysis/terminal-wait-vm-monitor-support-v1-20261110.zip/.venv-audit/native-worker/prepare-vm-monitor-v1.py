"""Enable only a loopback VMM debug endpoint while the dedicated VM is off."""
import json,socket,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,identity,vmrun,validate_vmx
out=WORKER/'vm-monitor-config-v1-20261109.json';backup=WORKER/'vm-monitor-config-before-v1-20261109.txt'
if out.exists()or backup.exists():raise ValueError('new config receipt and backup')
running=vmrun(['list'])
if str(VMX).lower()in running.lower():raise ValueError('never edit running VM')
raw=VMX.read_bytes();fields=validate_vmx(raw.decode('utf8'))
if any(k.startswith('debugStub.')for k in fields):raise ValueError('do not overwrite existing debug configuration')
with socket.socket()as s:s.bind(('127.0.0.1',8864))
settings={'debugStub.listen.guest64':'TRUE','debugStub.listen.guest64.remote':'FALSE','debugStub.hideBreakpoints':'TRUE'}
with backup.open('xb')as f:f.write(raw)
before=identity(VMX)
new=raw+b'\r\n'+''.join(k+' = "'+v+'"\r\n'for k,v in settings.items()).encode()
validate_vmx(new.decode('utf8'))
VMX.write_bytes(new)
r=dict(before=before,backup=identity(backup),after=identity(VMX),settings=settings,
    running_vms_before=running,host_input_actions=0,port=8864,remote_connections_enabled=False,
    software_breakpoints_allowed=False,accepted=False,original_game_started=False)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r))
