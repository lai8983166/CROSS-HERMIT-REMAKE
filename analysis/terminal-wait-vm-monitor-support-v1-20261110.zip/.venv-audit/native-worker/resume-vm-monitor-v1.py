import json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.terminal_vm_monitor_v3 import Monitor
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'vm-monitor-resume-v1-20261110.json'
if out.exists():raise ValueError('fresh resume receipt')
source=R/'analysis/terminal-wait-vm-monitor-cpu-tags-v1-20261110.json'
if not source.exists():raise ValueError('retain bounded original CPU tags before resume')
r=dict(retained_CPU=identity(source),host_input_actions=0,accepted=False)
r['resume_output']=vmrun(['start',VMX,'nogui'],timeout=60)
m=None
try:m=Monitor();r['first_stop']=m.query(b'?').decode()
finally:
    if m:m.close();r['detached']=True
r['guest_after']=json.loads(run_script(STATUS));r['remaining_vmss']=[dict(path=str(p),bytes=p.stat().st_size)for p in WORKER.glob('*.vmss')]
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r))
