import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.terminal_vm_monitor_v3 import Monitor
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
out=WORKER/'vm-monitor-resume-v3-20261110.json'
if out.exists():raise ValueError('fresh receipt')
r=dict(accepted=False,host_input_actions=0,original_game_started=False,samples=[],errors=[])
for i in range(2):
    m=None;row=dict(cpus=[])
    try:
        m=Monitor();row['stop']=m.query(b'?').decode()
        for cpu in (1,2):
            if m.query(('Hg%d'%cpu).encode())!=b'OK':raise ValueError('CPU select')
            g=m.query(b'g');b=bytes.fromhex(g.decode());rip=int.from_bytes(b[128:136],'little');rsp=int.from_bytes(b[56:64],'little')
            row['cpus'].append(dict(id=cpu,g=g.decode(),rip=hex(rip),code=m.query(('m%x,40'%rip).encode()).decode(),rsp=hex(rsp),stack=m.query(('m%x,80'%rsp).encode()).decode()))
    except Exception as exc:r['errors'].append(repr(exc))
    finally:
        if m:
            try:m.close()
            except Exception as exc:r['errors'].append('detach '+repr(exc))
            row['transcript']=m.rows
        r['samples'].append(row)
    if i==0:time.sleep(1)
try:r['tools_state']=vmrun(['checkToolsState',VMX],timeout=10)
except Exception as exc:r['errors'].append(str(exc))
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k!='samples'}));print([(s.get('stop'),[(c['id'],c['rip'],c['code'])for c in s['cpus']])for s in r['samples']])
