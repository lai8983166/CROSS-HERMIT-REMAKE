import json,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'vm-monitor-worker-stop-v1-20261110.json'
if out.exists():raise ValueError('fresh worker stop')
r=dict(accepted=False,host_input_actions=0,guest_before=json.loads(run_script(STATUS)))
if run_script("if(@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};'idle'").strip()!='idle':raise ValueError('idle only')
r['snapshots_before']=vmrun(['listSnapshots',VMX]);
if r['snapshots_before'].strip()!='Total snapshots: 0':raise ValueError('snapshot cleanup first')
fields=validate_vmx(VMX.read_text(encoding='utf8'))
if any(k.startswith('debugStub.')for k in fields):raise ValueError('restore owned debug configuration first')
r['soft_stop']=vmrun(['stop',VMX,'soft'],timeout=30)
for _ in range(10):
    running=vmrun(['list'])
    if str(VMX).lower()not in running.lower():break
    time.sleep(1)
else:raise ValueError('guest soft shutdown not complete')
r['running_vms_after']=running;r['vmem_remaining']=[str(p)for p in WORKER.rglob('*.vmem')];r['vmx_after']=identity(VMX)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r,indent=2))
if r['vmem_remaining']:raise SystemExit(1)
