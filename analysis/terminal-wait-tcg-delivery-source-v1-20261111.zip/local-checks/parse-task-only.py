import json,subprocess
from pathlib import Path
p=Path('F:/project/chaomofa/.venv-audit/native-worker/tcg-qualification-closeout-v2')
r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-File',str(p/'parse-task-only.ps1')],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
(p/'task-xml-parse-stdout.txt').write_bytes(r.stdout);(p/'task-xml-parse-stderr.txt').write_bytes(r.stderr)
print(r.returncode,r.stdout.decode('utf8',errors='replace'),r.stderr.decode('utf8',errors='replace'))
assert r.returncode==0
a=json.loads(r.stdout);assert a['parsed'] and not a['registered'] and a['logon_type']==3 and a['trigger_count']==0 and a['limit']=='PT2M'
