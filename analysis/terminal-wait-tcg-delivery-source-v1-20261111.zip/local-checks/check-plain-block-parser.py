import sys
sys.path.insert(0,'F:/project/chaomofa')
import base64,gzip,hashlib,json,subprocess
from pathlib import Path
from devtools.isolated_windows_vm import WORKER,environment
o=WORKER/'tcg-qualification-closeout-v2';p=o/'plain-block-parser.b64';p.write_bytes(b'')
raw=(WORKER/'tcg-qualification-build-v1/probe.exe').read_bytes();encoded=base64.b64encode(raw).decode();offset=0;wire=b'';results=[]
for i in range(0,len(encoded),4000):
 block=encoded[i:i+4000];script='for %I in ("'+str(p)+'") do @if %~zI=='+str(offset)+' (>>"'+str(p)+'" echo '+block+') else (exit /b 7)'
 r=subprocess.run('cmd.exe /d /c '+script,capture_output=True,timeout=5,env=environment(),creationflags=subprocess.CREATE_NO_WINDOW);assert r.returncode==0,(r.returncode,r.stderr);wire+=(block+chr(13)+chr(10)).encode();offset=len(wire);assert p.read_bytes()==wire;results.append(dict(index=i//4000,bytes=offset))
script='for %I in ("'+str(p)+'") do @if %~zI==0 (>>"'+str(p)+'" echo WRONG) else (exit /b 7)'
r=subprocess.run('cmd.exe /d /c '+script,capture_output=True,timeout=5,env=environment(),creationflags=subprocess.CREATE_NO_WINDOW);assert r.returncode==7 and p.read_bytes()==wire
result=dict(blocks=results,sha256=hashlib.sha256(wire).hexdigest(),bad_offset_rejected=True,original_executable_roundtrip=base64.b64decode(wire)==raw,host_input_actions=0)
(o/'plain-block-parser-proof.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
