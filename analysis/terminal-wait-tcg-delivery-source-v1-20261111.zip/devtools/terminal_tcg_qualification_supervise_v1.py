"""Fixed 540-second Job wrapper for one bounded multi-stage qualification worker."""
import json,subprocess,sys,tempfile,time
from pathlib import Path
from devtools.isolated_vm_bounded_query_v3 import Job,runtime_paths,MAX_OUTPUT
from devtools.isolated_windows_vm import WORKER,environment
def _supervise(payload,seconds,bootstrap=None):
    if not isinstance(seconds,(int,float))or not seconds==540:raise ValueError('bounded host deadline')
    wire=(json.dumps(payload)+'\n').encode()
    if len(wire)>1024:raise ValueError('bounded request before child creation')
    started=time.monotonic();deadline=started+seconds
    env=environment();job=None;process=None
    report=dict(deadline_seconds=seconds,host_input_actions=0,remote_completion='unknown',errors=[])
    try:
        job=Job()
        # Direct base interpreter, -S/-I: no venv launcher child or site startup hooks.
        base=Path(sys._base_executable).resolve()
        code=bootstrap or ('import sys;sys.path[:0]='+repr(runtime_paths())+
                           ';from devtools.isolated_vm_bounded_query_v3 import _worker;_worker()')
        with tempfile.TemporaryFile(dir=WORKER/'tmp')as output:
            process=subprocess.Popen([str(base),'-I','-S','-B','-X','utf8','-c',code],stdin=subprocess.PIPE,
                stdout=output,stderr=output,cwd=WORKER,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
            report['host_pid']=process.pid
            job.assign(process);report['assigned_before_request']=True
            process.stdin.write(wire);process.stdin.close()
            while process.poll()is None:
                if time.monotonic()>=deadline:
                    report['timed_out']=True;job.terminate();break
                output.seek(0,2)
                if output.tell()>MAX_OUTPUT:
                    report['errors'].append('output budget');job.terminate();break
                time.sleep(min(.02,max(0,deadline-time.monotonic())))
            if time.monotonic()>=deadline:
                report['timed_out']=True
                if process.poll() is None:job.terminate()
            # Cleanup budget is explicit and separate from the operation deadline.
            process.wait(timeout=2)
            if job.active():job.terminate()
            cleanup_end=time.monotonic()+2
            while job.active() and time.monotonic()<cleanup_end:time.sleep(.01)
            report['host_job_active_after']=job.active()
            if report['host_job_active_after']:report['errors'].append('host descendants remain')
            report['host_exit_code']=process.returncode
            output.seek(0,2);length=output.tell();report['output_bytes']=length
            if not report.get('timed_out') and not report['errors'] and length<=MAX_OUTPUT:
                output.seek(0)
                try:report['response']=json.loads(output.read().decode('utf8'))
                except (ValueError,UnicodeError):report['errors'].append('invalid worker response')
                else:report['remote_completion']=report['response'].get('remote_completion','unknown')
            elif length>MAX_OUTPUT and 'output budget' not in report['errors']:report['errors'].append('output budget')
    except Exception as exc:
        report['errors'].append('host supervision: '+type(exc).__name__)
    finally:
        # Each cleanup is attempted even if an earlier Win32 operation fails.
        if job:
            try:
                job.terminate()
            except Exception as exc:report['errors'].append('job termination: '+type(exc).__name__)
            try:
                job.close()
            except Exception as exc:report['errors'].append('job close: '+type(exc).__name__)
        try:
            if process and process.poll() is None:
                process.kill();process.wait(timeout=2)
        except Exception as exc:report['errors'].append('direct child cleanup: '+type(exc).__name__)
        report['elapsed_seconds']=time.monotonic()-started

    return report

