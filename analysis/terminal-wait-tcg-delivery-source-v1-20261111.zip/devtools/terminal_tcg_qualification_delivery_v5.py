"""Actual bounded native cmd/block delivery and guarded guest qualification.
No host input injection. Exactly one owned shell and no mutation resend.
"""
import csv,io,xml.etree.ElementTree as ET
import base64,datetime,gzip,hashlib,json,os,re,subprocess,sys,threading,time
from pathlib import Path
from devtools.isolated_windows_vm import ROOT,WORKER,environment
CASE=WORKER/'tcg-wait-native-v17'
UUID='626d1a20-6383-4cd3-85d5-6c9831d6f941'
NONCE=0x4f39edc6
GUEST='C:/ChaomofaWorker/tcg-qualification-v17'
TASK='Chaomofa-TCG-qualification-v17'

def save(name,value):
 with(CASE/name).open('x',encoding='utf8')as f:json.dump(value,f,indent=2)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def xml_receipt(value):
 raw=value.encode('utf8')if isinstance(value,str)else bytes(value)
 return dict(response_xml_base64=base64.b64encode(raw).decode(),response_bytes=len(raw),response_sha256=sha(raw))
def ps(s):return s.replace('DOLLAR',chr(36)).replace('BSLASH',chr(92))

def task_xml(guest,task,nonce,source_sha):
 ns='http://schemas.microsoft.com/windows/2004/02/mit/task';ET.register_namespace('',ns)
 def node(parent,name,text=None,**attrs):
  x=ET.SubElement(parent,'{'+ns+'}'+name,attrs);x.text=text;return x
 root=ET.Element('{'+ns+'}Task',{'version':'1.2'})
 node(root,'Triggers')
 principal=node(node(root,'Principals'),'Principal',id='Author')
 node(principal,'UserId','CHAOMOFA-WORKER'+chr(92)+'Administrator');node(principal,'LogonType','InteractiveToken');node(principal,'RunLevel','HighestAvailable')
 settings=node(root,'Settings')
 for key,value in [('MultipleInstancesPolicy','IgnoreNew'),('DisallowStartIfOnBatteries','false'),('StopIfGoingOnBatteries','false'),('AllowStartOnDemand','true'),('Enabled','true'),('ExecutionTimeLimit','PT120S')]:node(settings,key,value)
 action=node(node(root,'Actions',Context='Author'),'Exec')
 node(action,'Command',guest.replace('/',chr(92))+chr(92)+'probe.exe');node(action,'Arguments',guest+'/probe.json '+format(nonce,'x')+' '+source_sha);node(action,'WorkingDirectory',guest.replace('/',chr(92)))
 return ET.tostring(root,encoding='utf-16',xml_declaration=True)

def worker():
 json.loads(sys.stdin.readline()) # Work starts only after Job assignment.
 from devtools.isolated_vm_preflight import observe_host
 from devtools.terminal_tcg_qualification_verify_v1 import verify
 import winrm,xmltodict
 r=dict(accepted=False,game_executed=False,errors=[],stages={},host_input_injected=False)
 state=dict(deadline=time.monotonic()+60,name='initial');done=threading.Event();p=None;shell=None;task_created=False;task_started=False
 def stage(name,seconds):
  state.update(name=name,deadline=time.monotonic()+seconds)
  (CASE/'active-stage.json').write_text(json.dumps(dict(name=name,seconds=seconds,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())))
 def watch():
  while not done.wait(.1):
   if time.monotonic()>state['deadline']:
    save('stage-timeout.json',dict(stage=state['name'],remote_completion='unknown'));os._exit(124)
 threading.Thread(target=watch,daemon=True).start()
 def command(label,exe,args,seconds=40,mutation=False):
  stage(label,seconds);start=time.monotonic()
  # Command creation, receive and cleanup each use the current stage allowance.
  # A Receive tuning value must never leak into the next Command operation.
  p.operation_timeout_sec=min(40,max(5,int(seconds)-5))
  p.read_timeout_sec=p.operation_timeout_sec+5;p.transport.read_timeout_sec=p.read_timeout_sec
  if (CASE/(label+'-request.json')).exists():raise ValueError('no replay '+label)
  save(label+'-request.json',dict(executable=exe,arguments=args,mutation=mutation,shell=shell))
  command_id=p.run_command(shell,exe,args,console_mode_stdin=False,skip_cmd_shell=True)
  save(label+'-owned.json',dict(shell=shell,command=command_id))
  out=[];err=[];seq=0
  while True:
   try:a,b,code,finished=p.get_command_output_raw(shell,command_id)
   except winrm.exceptions.WinRMOperationTimeoutError:continue
   save(label+'-chunk-'+str(seq)+'.json',dict(stdout=base64.b64encode(a).decode(),stderr=base64.b64encode(b).decode(),stdout_sha256=sha(a),stderr_sha256=sha(b),done=finished,exit_code=code));seq+=1;out.append(a);err.append(b)
   if finished:break
  a=b''.join(out);b=b''.join(err)
  save(label+'-completed.json',dict(command=command_id,exit_code=code,stdout_base64=base64.b64encode(a).decode(),stderr_base64=base64.b64encode(b).decode(),elapsed_seconds=time.monotonic()-start))
  stage(label+'-cleanup',20);p.operation_timeout_sec=15;p.read_timeout_sec=20;p.transport.read_timeout_sec=20;p.cleanup_command(shell,command_id)
  result=dict(exit_code=code,stdout_base64=base64.b64encode(a).decode(),stderr_base64=base64.b64encode(b).decode(),stdout_bytes=len(a),stdout_sha256=sha(a),command_cleaned=True,elapsed_seconds=time.monotonic()-start)
  save(label+'-result.json',result)
  if code:raise RuntimeError(label+' guest exit '+str(code)+': '+b.decode('utf8',errors='replace')[:200])
  return a

 try:
  if not(CASE/'vm-ready.json').exists()or(CASE/'report.json').exists():raise ValueError('active owned VM')
  manifest=json.loads((WORKER/'tcg-qualification-build-v1/manifest.json').read_bytes())
  exe=Path(manifest['executable']['path']);raw=exe.read_bytes();source=Path(manifest['source']['path'])
  if sha(raw)!=manifest['executable']['sha256']or sha(source.read_bytes())!=manifest['source']['sha256']:raise ValueError('frozen helper identity')
  r.update(schema='terminal-tcg-qualification-v1',nonce=NONCE,source_sha256=sha(source.read_bytes()),guest_executable=manifest['executable'])
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  p=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER'+chr(92)+'Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=10,read_timeout_sec=15).protocol
  stage('service-ready',100)
  ready_start=time.monotonic()
  while True:
   req={'env:Envelope':p.build_wsman_header(resource_uri='http://schemas.microsoft.com/wbem/wsman/1/windows/shell',action='http://schemas.xmlsoap.org/ws/2004/09/enumeration/Enumerate')}
   req['env:Envelope']['env:Body']={'n:Enumerate':{'w:OptimizeEnumeration':None,'w:MaxElements':'64'}}
   try:wire=p.send_message(xmltodict.unparse(req))
   except Exception as e:
    with(CASE/'service-readiness-errors.txt').open('a')as f:f.write(type(e).__name__+chr(10))
    time.sleep(2);continue
   receipt=xml_receipt(wire);receipt['elapsed_seconds']=time.monotonic()-ready_start
   save('service-ready.json',receipt);break
  stage('open-shell',60);t=time.monotonic();p.operation_timeout_sec=40;p.read_timeout_sec=50;p.transport.read_timeout_sec=50
  shell=p.open_shell(noprofile=True);save('shell-owned.json',dict(shell=shell,seconds=time.monotonic()-t,vm_ready_sha256=sha((CASE/'vm-ready.json').read_bytes())))
  # Any stage watchdog exit aborts qualification; it never proves complete
  # observation or remote cleanup. The parent then stops the owned VM.
  # Use short Receive intervals; the stage watchdog, not a library retry, owns time.
  p.operation_timeout_sec=5;p.read_timeout_sec=10;p.transport.read_timeout_sec=10
  token='TCG-Q17-'+format(NONCE,'x')
  native=command('minimal-native','cmd.exe',['/d','/c','echo '+token],60)
  if native.strip()!=token.encode():raise ValueError('native exact return')
  r['stages']['minimal_native_return']=True
  r['guest_powershell_used']=False
  machine=command('actual-uuid','wmic.exe',['csproduct','get','UUID','/value'],40).decode('utf8')
  if UUID not in machine.lower():raise ValueError('actual guest UUID')
  boot=command('actual-boot','wmic.exe',['os','get','LastBootUpTime','/value'],40).decode('utf8')
  m=re.search(r'LastBootUpTime=(\d{14})\.(\d{6})([+-]\d{3})',boot)
  if not m:raise ValueError('actual boot')
  dt=datetime.datetime.strptime(m[1]+m[2],'%Y%m%d%H%M%S%f').replace(tzinfo=datetime.timezone(datetime.timedelta(minutes=int(m[3])))).astimezone(datetime.timezone.utc)
  r['expected_boot_utc']=dt.strftime('%Y-%m-%dT%H:%M:%S.')+format(dt.microsecond,'06d')+'0Z'
  console=command('actual-console','quser.exe',[],30).decode('utf8')
  if not re.search(r'Administrator\s+console\s+1\s+Active',console,re.I):raise ValueError('actual active console')
  target=GUEST.replace('/',chr(92))
  command('new-directory','cmd.exe',['/d','/c','if exist "'+target+'" (exit /b 9) else (mkdir "'+target+'")'],30,True)
  key='HKLM'+chr(92)+'SOFTWARE'+chr(92)+'Microsoft'+chr(92)+'Windows NT'+chr(92)+'CurrentVersion'+chr(92)+'Winlogon'
  command('disable-one-logon','reg.exe',['add','"'+key+'"','/v','AutoAdminLogon','/t','REG_SZ','/d','0','/f','/reg:64'],30,True)
  configured=command('verify-one-logon-disabled','reg.exe',['query','"'+key+'"','/v','AutoAdminLogon','/reg:64'],30).decode('utf8')
  if not re.search(r'AutoAdminLogon\s+REG_SZ\s+0\s*$',configured):raise ValueError('one-logon disabled')
  for value in ('DefaultPassword','AutoLogonCount'):
   errorfile=target+chr(92)+value+'-absence.txt'
   script='reg.exe delete "'+key+'" /v '+value+' /f /reg:64 >nul 2>&1 & reg.exe query "'+key+'" /v '+value+' /reg:64 >nul 2>"'+errorfile+'" & if errorlevel 1 (type "'+errorfile+'") else (exit /b 9)'
   absent=command('clear-'+value.lower(),'cmd.exe',['/d','/c',script],30,True)
   if b'unable to find the specified registry key or value'not in absent.lower():raise ValueError('registry absence not confirmed')
  r['one_logon_credential_cleared']=True
  def transfer(label,payload,filename):
   encoded=base64.b64encode(payload).decode();wire=b'';blocks=[];file=target+chr(92)+label+'.b64'
   command(label+'-new','cmd.exe',['/d','/c','if exist "'+file+'" (exit /b 9) else (type nul > "'+file+'")'],30,True)
   for i in range(0,len(encoded),4000):
    block=encoded[i:i+4000];n=i//4000;offset=len(wire)
    script='for %I in ("'+file+'") do @if %~zI=='+str(offset)+' (>>"'+file+'" echo '+block+') else (exit /b 7)'
    command(label+'-block-'+str(n),'cmd.exe',['/d','/c',script],30,True)
    piece=(block+chr(13)+chr(10)).encode();blocks.append(dict(index=n,offset=offset,bytes=len(piece),sha256=sha(piece)));wire+=piece
   actual=command(label+'-encoded-hash','certutil.exe',['-hashfile',file,'SHA256'],40).decode('utf8').replace(' ','').lower()
   if sha(wire)not in actual:raise ValueError('encoded block aggregate hash')
   destination=target+chr(92)+filename
   command(label+'-decode','certutil.exe',['-decode',file,destination],40,True)
   actual=command(label+'-decoded-hash','certutil.exe',['-hashfile',destination,'SHA256'],40).decode('utf8').replace(' ','').lower()
   if sha(payload)not in actual:raise ValueError('decoded file identity')
   save(label+'-blocks.json',dict(blocks=blocks,encoded_bytes=len(wire),encoded_sha256=sha(wire),payload_bytes=len(payload),payload_sha256=sha(payload)))
  transfer('probe',raw,'probe.exe');r['stages']['small_block_deployment']=True
  xml=task_xml(GUEST,TASK,NONCE,r['source_sha256'])
  with(CASE/'task.xml').open('xb')as f:f.write(xml)
  transfer('task',xml,'task.xml')
  command('register-task','schtasks.exe',['/create','/tn',TASK,'/xml',target+chr(92)+'task.xml'],40,True)
  task_created=True
  stage('host-identity',25)
  cmd='[pscustomobject]@{uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID}|ConvertTo-Json -Compress'
  r['host']=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command',cmd],env=environment(),creationflags=subprocess.CREATE_NO_WINDOW,timeout=20))
  stage('qualification',180)
  def observe():
   nonlocal task_started
   began=time.monotonic();task_started=True
   try:
    command('start-task','schtasks.exe',['/run','/tn',TASK],25,True)
    for n in range(120):
     if time.monotonic()-began>135:raise TimeoutError('probe report')
     try:
      raw_report=command('read-probe-'+str(n),'cmd.exe',['/d','/c','type "'+target+chr(92)+'probe.json"'],15)
      g=json.loads(raw_report)
      if g.get('nonce')!=NONCE:raise ValueError('actual nonce')
      with(CASE/'probe.json').open('xb')as f:f.write(raw_report)
      r['guest']=g;r['stages']['probe_actually_executed']=True;return
     except (RuntimeError,json.JSONDecodeError):time.sleep(1)
    raise TimeoutError('probe read bound')
   except Exception as e:
    r['errors'].append('observation: '+type(e).__name__+': '+str(e))
    stage('unknown-task-observation',max(1,165-(time.monotonic()-began)))
    while time.monotonic()-began<160:time.sleep(.2)
  r['host_observation']=observe_host(NONCE,observe,seconds=175)
  stage('verify',10)
  if 'guest'not in r:raise ValueError('no actual guest report')
  r['verification']=verify(r,expected_source_sha256=r['source_sha256'],expected_executable_sha256=r['guest_executable']['sha256'],expected_boot_utc=r['expected_boot_utc'],expected_nonce=NONCE)
 except Exception as e:r['errors'].append(type(e).__name__+': '+str(e)[:1500])
 finally:
  if task_created:
   try:
    status=command('task-status','schtasks.exe',['/query','/tn',TASK,'/fo','CSV','/v'],40).decode('utf-8-sig')
    rows=list(csv.DictReader(io.StringIO(status)))
    if len(rows)!=1 or rows[0].get('Status')not in ('Ready','Disabled'):raise ValueError('task not confirmed stopped')
    command('remove-task','schtasks.exe',['/delete','/tn',TASK,'/f'],30,True)
    r['task_cleanup']=dict(removed=True,status_before=rows[0]['Status'],last_result=rows[0].get('Last Result'))
   except Exception as e:r['errors'].append('task cleanup '+type(e).__name__)
  if shell:
   try:
    stage('close-shell',30);p.close_shell(shell);r['shell_closed']=True
   except Exception as e:r['errors'].append('shell cleanup '+type(e).__name__)
  done.set();save('delivery.json',r)
 print(json.dumps(dict(ok=not r['errors'],stages=r['stages'],verification=r.get('verification'),errors=r['errors'],remote_completion='observed')))

def main():
 from devtools.terminal_tcg_qualification_supervise_v1 import _supervise,runtime_paths
 bootstrap='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_delivery_v5 import worker;worker()'
 result=_supervise({},540,bootstrap);save('supervision.json',result)
 (CASE/'vm-stop').write_text('bounded qualification finished')
 print(json.dumps(result))
if __name__=='__main__':main()
