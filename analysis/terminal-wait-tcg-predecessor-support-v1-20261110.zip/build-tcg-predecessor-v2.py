import subprocess,json
from pathlib import Path
from devtools.isolated_windows_vm import WORKER,identity,environment
R=WORKER.parents[1];D=WORKER/'qemu-worker'
source=D/'qemu-w64-setup-20260811.exe';dest=D/'runtime/share/multiboot_dma.bin'
if dest.exists():raise ValueError('new firmware only')
if identity(source)['sha256']!='f98a8aeb5f7faea9765b6dee28316c266cd179d80354a2fed8e50176f9a2e59f':raise ValueError('installer identity')
subprocess.run(['C:/Program Files/7-Zip/7z.exe','x','-y','-o'+str(D/'runtime'),str(source),'share/multiboot_dma.bin'],check=True,capture_output=True,env=environment(),timeout=20)
(WORKER/'tcg-predecessor-firmware-v2.json').write_text(json.dumps(identity(dest),indent=2))
s=(R/'devtools/terminal_tcg_predecessor_probe.py').read_text().replace('tcg-predecessor-v1-20261110','tcg-predecessor-v2-20261110').replace('tcg-predecessor-supervision-v1.json','tcg-predecessor-supervision-v2.json').replace('terminal_tcg_predecessor_probe import','terminal_tcg_predecessor_probe_v2 import')
s=s.replace("code+=emit('S')+b'\\xe9'+word((base+0x300)-(base+0x120+len(code)+5))","code+=emit('S');code+=b'\\xe9'+word((base+0x300)-(base+0x120+len(code)+5))")
s=s.replace("elf=d/'guest.elf'","firmware=identity(root/'share/multiboot_dma.bin')\n    elf=d/'guest.elf'")
s=s.replace('executable=identity(exe),guest=identity(elf)','executable=identity(exe),firmware=firmware,guest=identity(elf)')
with (R/'devtools/terminal_tcg_predecessor_probe_v2.py').open('x',encoding='utf8')as f:f.write(s)
