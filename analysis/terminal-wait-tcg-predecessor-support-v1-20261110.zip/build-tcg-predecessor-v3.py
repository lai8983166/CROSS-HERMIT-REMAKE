from pathlib import Path
R=Path('F:/project/chaomofa')
s=(R/'devtools/terminal_tcg_predecessor_probe_v2.py').read_text()
s=s.replace('tcg-predecessor-v2-20261110','tcg-predecessor-v3-20261110').replace('supervision-v2.json','supervision-v3.json').replace('terminal_tcg_predecessor_probe_v2 import','terminal_tcg_predecessor_probe_v3 import')
s=s.replace("emit('D')+bytes.fromhex('814c24280000010061cf')","emit('D')+bytes.fromhex('8d742420b90c000000ace6e9e2fb0f21f05089e6b904000000ace6e9e2fb58814c24280000010061cf')")
s=s.replace("console.read_text()if console.exists()else None","console.read_bytes().hex()if console.exists()else None")
s=s.replace("r['guest_output']=='SHDR1E'","len(bytes.fromhex(r['guest_output'] or ''))==22 and bytes.fromhex(r['guest_output']).startswith(b'SHD') and bytes.fromhex(r['guest_output']).endswith(b'R1E')")
with (R/'devtools/terminal_tcg_predecessor_probe_v3.py').open('x',encoding='utf8')as f:f.write(s)
