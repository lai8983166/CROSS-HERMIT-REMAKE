import hashlib,json,zipfile
from pathlib import Path
from devtools.isolated_windows_vm import WORKER as W,VMX,identity,vmrun
R=W.parents[1];out=R/'analysis/terminal-wait-tcg-predecessor-closeout-v1-20261110.json'
if out.exists():raise ValueError('fresh output')
files=[p for v in (1,2,3)for p in (W/('tcg-predecessor-v%d-20261110'%v)).iterdir()if p.is_file()]
files+=list(W.glob('tcg-predecessor-supervision-v*.json'))+list(W.glob('build-tcg-predecessor-v*.py'))
files+=[W/'tcg-preservation-v1.json',W/'tcg-predecessor-firmware-v2.json',Path(__file__).resolve()]
rows=[dict(member=p.relative_to(W).as_posix(),**identity(p))for p in sorted(files)]
capsule=R/'analysis/terminal-wait-tcg-predecessor-support-v1-20261110.zip'
with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for row in rows:z.write(row['path'],row['member'])
with zipfile.ZipFile(capsule)as z:
    for row in rows:
        b=z.read(row['member'])
        if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('capsule identity')
running=vmrun(['list'],timeout=10)
if 'Total running VMs: 0'not in running:raise ValueError('VM idle')
native=[]
for v in (1,2,3):
    p=W/('tcg-predecessor-v%d-20261110'%v)/'report.json';r=json.loads(p.read_bytes())
    s=json.loads((W/('tcg-predecessor-supervision-v%d.json'%v)).read_bytes())
    if s['host_job_active_after']!=0 or s['errors']:raise ValueError('host cleanup')
    native.append(dict(version=v,report=identity(p),seconds=s['elapsed_seconds'],exit=r['exit_code'],errors=r['errors'],execution_complete=r['execution_complete'],job_active_after=0))
result=dict(accepted=False,fullstate=False,fullABI=False,tasks_completed=2,tasks_total=8,
            native=native,configured_cpu=2,configured_memory_GiB=4,measured_target_cpu=[0],original_game_starts=0,windows_boots=0,
            host_input_actions=0,host_configuration_changes=0,new_download_bytes=0,
            new_firmware=identity(W/'qemu-worker/runtime/share/multiboot_dma.bin'),
            validation=dict(normal_tests=6,optimized_tests=6,strict_openspec=True,preservation=json.loads((W/'tcg-preservation-v1.json').read_bytes())),
            source_files=rows,capsule=identity(capsule),
            cleanup='All three QEMU processes ended within their bounds; host Jobs empty. Windows VM stayed off. Small originals and one compressed same-disk recovery copy retained; no original assets/history deleted. Previously retained QEMU environment reused; one firmware file added, no old bytes changed.',
            limits=['Finite self-owned TCG predecessor/event chain only; not native Windows or game acceptance.',
                    'Old full57/FP and exact publisher-build correspondence gaps remain. No generic RF restoration authorized.',
                    'v1 missing firmware and its unused wrong jump remain frozen failed evidence; v2/v3 are separate input versions.'])
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps(dict(capsule=identity(capsule),source_bytes=sum(x['bytes']for x in rows),firmware=result['new_firmware'])))
