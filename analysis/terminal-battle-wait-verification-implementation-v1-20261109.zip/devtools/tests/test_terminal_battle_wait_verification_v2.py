import copy
import ctypes as C
import unittest
from devtools.terminal_menu_input import packet
from devtools.terminal_battle_wait_verification_v2 import verify_precise_submissions


class PreciseSubmissionTests(unittest.TestCase):
    def fixture(self):
        rows=[]
        for flags,start in ((2,110),(4,220)):
            p=packet(flags=flags)
            rows.append(dict(type=0,flags=flags,packet_hex=C.string_at(C.byref(p),C.sizeof(p)).hex(),
                begin_ns=start,end_ns=start+10,result=1,error=None))
        return dict(precise_input_submissions=rows,start_trigger='second_left_button_down_query',
                    start_trigger_ns=90,capture_interval=dict(begin_ns=100)),dict(moves=[],down_result=1,up_results=[1])

    def test_precise_original_submissions_pass_without_rewriting_coarse_clock(self):
        source,action=self.fixture()
        action.update(down_wall_time_ns=95,up_wall_time_ns=250)
        original=copy.deepcopy(action)
        self.assertFalse(verify_precise_submissions(source,action)['original_coarse_timestamps_modified'])
        self.assertEqual(action,original)

    def test_submissions_before_trace_overlap_wrong_packet_or_retry_rejected(self):
        for kind in ('before','overlap','packet','retry','result'):
            source,action=self.fixture();rows=source['precise_input_submissions']
            if kind=='before':rows[0]['begin_ns']=99
            if kind=='overlap':rows[0]['end_ns']=rows[1]['begin_ns']
            if kind=='packet':rows[0]['flags']=4
            if kind=='retry':rows.append(copy.deepcopy(rows[-1]))
            if kind=='result':rows[0]['result']=0
            with self.subTest(kind=kind),self.assertRaises(ValueError):verify_precise_submissions(source,action)


if __name__=='__main__':unittest.main()
