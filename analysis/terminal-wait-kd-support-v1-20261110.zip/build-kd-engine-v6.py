from pathlib import Path
old=Path('devtools/isolated_kd_engine_v5.py')
new=Path('devtools/isolated_kd_engine_v6.py')
if new.exists():raise ValueError('fresh version')
s=old.read_text()
s=s.replace("'dt nt!_EPROCESS UniqueProcessId DebugPort')", "'dt nt!_EPROCESS UniqueProcessId DebugPort','? @$tpid','? @$tid','? @$thread','? @$proc')")
needle="or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+',command),"
replacement='''or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+',command)
             or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+ "\.if \(@\$tpid == 0x[0-9a-f]+ && @\$tid == 0x[0-9a-f]+\) \{ \.echo OWNED_WAIT_RETURN \} \.else \{ gc \}"',command),'''
if needle not in s:raise ValueError('exact replacement')
s=s.replace(needle,replacement)
new.write_text(s)
