import json,sys,time
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,validate_vmx,identity
from devtools.isolated_vm_kd import run_guest,SETTINGS,validate_kd_vmx
from devtools.isolated_vm_guest_admin import STATUS
out=WORKER/'kd-worker/restore-v2.json'
if out.exists():raise ValueError('fresh restore')
validate_kd_vmx(VMX.read_text(encoding='utf8'));r=dict(accepted=False,errors=[],host_boot_configuration_changed=False)
try:
 r['guest_before']=json.loads(run_guest(STATUS))
 r['active_fixtures']=run_guest("@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,Path)|ConvertTo-Json -Compress")
 if r['active_fixtures'].strip():raise ValueError('owned fixture/supervisor still active')
 script=r"""$q='C:\ChaomofaWorker\kd-preflight-v1-20261110\bcd-before';
 if((Get-FileHash -LiteralPath $q -Algorithm SHA256).Hash -ne '3978CEE5E7AFCBB438842E1D0635095116E6C4AC339AAA0A702B1FD753C2E325'){throw 'original backup identity'};
 $x=(& bcdedit /import $q |Out-String);if($LASTEXITCODE){throw 'guest BCD import failed'};
 [pscustomobject]@{import=$x;current=(& bcdedit /enum '{current}'|Out-String);settings=(& bcdedit /dbgsettings|Out-String)}|ConvertTo-Json -Compress"""
 r['restored']=json.loads(run_guest(script))
 if 'debug                   Yes' in r['restored']['current']or 'debugtype               Local' not in r['restored']['settings']:raise ValueError('original guest debugger settings')
 r['soft_stop']=vmrun(['stop',VMX,'soft'],timeout=40)
 if str(VMX).lower()in vmrun(['list']).lower():raise ValueError('guest must be off before VMX restore')
 text=VMX.read_text(encoding='utf8');validate_kd_vmx(text)
 lines=[];removed=[]
 for line in text.splitlines(keepends=True):
  key=line.split('=',1)[0].strip()
  if key in SETTINGS:removed.append(key)
  else:lines.append(line)
 if set(removed)!=set(SETTINGS):raise ValueError('exact owned serial settings')
 restored=''.join(lines);validate_vmx(restored)
 VMX.write_text(restored,encoding='utf8',newline='');r['removed_serial_settings']=removed;r['vmx_after']=identity(VMX)
 r['running_after']=vmrun(['list']);r['snapshots']=vmrun(['listSnapshots',VMX])
 r['vmem_files']=[str(x)for x in WORKER.glob('*.vmem')]
except Exception as exc:r['errors'].append(repr(exc))
out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
if r['errors']:raise SystemExit(1)
