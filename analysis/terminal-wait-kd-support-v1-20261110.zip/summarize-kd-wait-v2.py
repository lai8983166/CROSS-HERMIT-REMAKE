import json
from pathlib import Path
r=json.loads(Path('.venv-audit/native-worker/kd-worker/wait-tail-v2.json').read_text())
print(json.dumps({k:v for k,v in r.items()if k not in ('output','fixture_inputs')},indent=2))
print(''.join(x['text']for x in r['output'])[-4000:])
