from pathlib import Path
s=Path('.venv-audit/native-worker/finish-kd-cli-v1.py').read_text().replace('cli-fixture-result-v1','cli-fixture-result-v2').replace('cli-fixture-final-v1','cli-fixture-final-v2').replace('kd-cli-wait-v1','kd-cli-wait-v2')
Path('.venv-audit/native-worker/finish-kd-cli-v2.py').write_text(s)
