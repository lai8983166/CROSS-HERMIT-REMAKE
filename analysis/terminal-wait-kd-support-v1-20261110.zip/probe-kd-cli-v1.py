"""One guest kernel tail hit using the installed SDK client, no fixture/game."""
import json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,environment,identity
from devtools.isolated_vm_kd import PIPE,validate_kd_vmx,run_guest
from devtools.isolated_vm_guest_admin import STATUS
d=WORKER/'kd-worker';out=d/'cli-channel-v1.json';log=d/'cli-channel-v1.log'
if out.exists()or log.exists():raise ValueError('fresh CLI probe')
validate_kd_vmx(VMX.read_text(encoding='utf8'))
exe=Path('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/kd.exe')
# This boot's base was independently read in channel-v5; current boot must match.
before=json.loads(run_guest(STATUS))
if before['boot']!='2026-11-10T01:00:17.5000000Z':raise ValueError('fixed current boot only')
command='bc *;ba e 1 fffff806208fcc6a ".if (0) { .echo IMPOSSIBLE } .else { .echo OWNED_KERNEL_TAIL; r; bc *; bl; gc }";.echo CLI_ARMED;g'
env=environment();env['_NT_SYMBOL_PATH']=str(WORKER/'symbols');env['_NT_ALT_SYMBOL_PATH']=''
r=dict(accepted=False,fullstate=False,original_game_started=False,host_input_actions=0,guest_before=before,client=identity(exe),command=command,errors=[])
t=time.monotonic();p=None
try:
 with log.open('xb')as f:
  p=subprocess.Popen([str(exe),'-k','com:pipe,port='+PIPE+',resets=0,reconnect','-bonc','-noshell','-sins','-y',str(WORKER/'symbols'),'-c',command],stdin=subprocess.PIPE,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=WORKER,creationflags=subprocess.CREATE_NO_WINDOW)
  r['client_pid']=p.pid
  deadline=time.monotonic()+20
  while time.monotonic()<deadline:
   data=log.read_text(errors='replace')
   if 'OWNED_KERNEL_TAIL\n' in data and 'gc }' in data and 'rax=' in data:break
   if p.poll()is not None:raise ValueError('client exited before kernel hit')
   time.sleep(.2)
  else:raise ValueError('bounded CLI kernel boundary deadline')
  r['guest_after']=json.loads(run_guest(STATUS))
  r['kernel_boundary_and_guest_resumed']=True
  p.terminate();p.wait(timeout=5);r['client_stopped_after_guest_resumed']=True
except Exception as e:r['errors'].append(repr(e))
finally:
 if p and p.poll()is None:p.terminate();p.wait(timeout=5);r['emergency_client_stop']=True
 r['elapsed_seconds']=time.monotonic()-t;r['log']=identity(log)
 out.write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
if r['errors']:raise SystemExit(1)
