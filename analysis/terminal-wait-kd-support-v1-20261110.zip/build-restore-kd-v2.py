from pathlib import Path
s=Path('.venv-audit/native-worker/restore-kd-guest-v1.py').read_text().replace('restore-v1.json','restore-v2.json').replace('script="""','script=r"""')
Path('.venv-audit/native-worker/restore-kd-guest-v2.py').write_text(s)
