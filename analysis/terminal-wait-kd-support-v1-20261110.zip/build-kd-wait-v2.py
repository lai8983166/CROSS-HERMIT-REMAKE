from pathlib import Path
s=Path('devtools/terminal_kd_wait_preflight.py').read_text()
s=s.replace('isolated_kd_engine_v6','isolated_kd_engine_v7').replace('wait-tail-v1.json','wait-tail-v2.json').replace('kd-wait-tail-v1-20261110','kd-wait-tail-v2-20261110').replace('max_workers=1','max_workers=2')
s=s.replace('e = None\n    ready = None', 'e = None\n    ready = None\n    launch = None\n    pending = None')
start=s.index('        command = "$p=Start-Process')
end=s.index("        r['ready'] = ready",start)
s=s[:start]+'''        gates(['ack-0', 'ack-1', 'ack-2', 'ack-3'])
        command = "$p=Start-Process -FilePath '" + q + "\\\\fixture.exe' -ArgumentList @('--owned-vmm-fixture','" + q + "') -WindowStyle Hidden -PassThru;if(!$p.WaitForExit(180000)){throw 'bounded fixture lifespan'};[pscustomobject]@{exit_code=$p.ExitCode;result=if(Test-Path -LiteralPath '" + q + "\\\\result.json'){Get-Content -LiteralPath '" + q + "\\\\result.json' -Raw|ConvertFrom-Json}else{$null}}|ConvertTo-Json -Depth 10 -Compress"
        launch = pool.submit(run_guest, command)
        ready_command = "$end=[DateTime]::UtcNow.AddSeconds(10);while(!(Test-Path -LiteralPath '" + q + "\\\\ready.json')){if([DateTime]::UtcNow -gt $end){throw 'ready deadline'};Start-Sleep -Milliseconds 50};Get-Content -LiteralPath '" + q + "\\\\ready.json' -Raw"
        ready = json.loads(run_guest(ready_command))
''' +s[end:]
s=s.replace('.if (@$tpid == 0x%x && @$tid == 0x%x) { .echo OWNED_WAIT_RETURN } .else { gc }', '.if (@$tpid == 0x%x) { .if (@$tid == 0x%x) { .echo OWNED_WAIT_RETURN } .else { gc } } .else { gc }')
start=s.index("            row['stack'] = capture")
end=s.index("        r['tail_after']",start)
s=s[:start]+'''            row['stack'] = capture('dq %x L20' % regs['rsp'])
            row['trap'] = capture('dq %x L32' % (regs['rbp']-0x80))
            def qwords(text):
                words = {}
                for line in text.splitlines():
                    fields = line.split()
                    if fields and re.fullmatch('[0-9a-f]{8}`[0-9a-f]{8}', fields[0]):
                        address = int(fields[0].replace('`', ''), 16)
                        for j, value in enumerate(fields[1:]):
                            if re.fullmatch('[0-9a-f]{8}`[0-9a-f]{8}', value):
                                words[address+8*j] = int(value.replace('`', ''), 16)
                return words
            stack = qwords(row['stack'])
            trap = qwords(row['trap'])
            sp, bp0 = regs['rsp'], regs['rbp']
            row['arguments'] = dict(handle=trap.get(bp0-0x48), alertable=trap.get(bp0-0x40), user_rip=trap.get(bp0+0xe8), user_cs=trap.get(bp0+0xf0), caller=stack.get(sp+0x38), timeout_pointer=stack.get(sp+0x50), timeout_value=stack.get(sp+0x58))
            a = row['arguments']
            need(a['caller'] == base+0x428c35, 'original syscall dispatcher caller')
            need(a['handle'] == ready['event_handle'] and (a['alertable'] & 0xff) == 0, 'actual fixture response event and Alertable')
            need(a['user_cs'] & 0xffff == 0x33, 'WOW64 native syscall return mode')
            need(a['timeout_pointer'] == sp+0x58 and a['timeout_value'] == (0xfffffffffeced300 if index < 3 else 0), 'captured original relative timeout')
            row['kernel_context_only'] = True
''' +s[end:]
s=s.replace("        pool.shutdown(wait=True)", "        if launch:\n            try:r['launch_result']=json.loads(launch.result(timeout=15))\n            except Exception as exc:r['errors'].append('launcher: '+repr(exc))\n        if pending:\n            try:r['go_result']=pending.result(timeout=5)\n            except Exception as exc:r['errors'].append('go: '+repr(exc))\n        pool.shutdown(wait=True)")
p=Path('devtools/terminal_kd_wait_preflight_v2.py')
if p.exists():raise ValueError('fresh version')
p.write_text(s)
