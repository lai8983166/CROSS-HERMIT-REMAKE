import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
d=WORKER/'kd-worker';gate=d/'release-fixture-v2-go.txt'
gate.write_text('continue')
r={}
try:r['gate_copy']=vmrun(['CopyFileFromHostToGuest',VMX,gate,PureWindowsPath('C:/ChaomofaWorker/kd-cli-wait-v2-20261110/go')],guest=True,timeout=10)
except Exception as e:r['error']=repr(e)
(d/'release-fixture-v2.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
