from pathlib import Path
p=Path('.venv-audit/native-worker/recover-kd-stop-v1.py')
s=p.read_text().replace('recovery-v1.json','recovery-v2.json')
s=s.replace("e.execute('bc *');r['breakpoints_after']=e.execute('bl');e.go()", "e.execute('bc *');r['breakpoints_after']=e.execute('bl');e.go()\n try:e.wait(1000)\n except RuntimeError as x:r['bounded_running_wait']=repr(x)")
Path('.venv-audit/native-worker/recover-kd-stop-v2.py').write_text(s)
