from pathlib import Path
s=Path('.venv-audit/native-worker/recover-kd-cli-v1.py').read_text().replace('cli-recovery-v1','cli-recovery-v2')
s=s.replace("  r['guest_after']=json.loads(run_guest(STATUS))", """  r['extra_break_continues']=[]
  last=0;deadline=time.monotonic()+8
  while time.monotonic()<deadline:
   data=log.read_text(errors='replace')
   if data.rstrip().endswith('kd>') and len(data)!=last:
    if len(r['extra_break_continues'])>=4:raise ValueError('bounded pending debugger breaks')
    r['extra_break_continues'].append(len(data));last=len(data)
    p.stdin.write(b'bc *;.echo OWNED_CONTINUE;g\\n');p.stdin.flush()
   time.sleep(.1)
  r['guest_after']=json.loads(run_guest(STATUS))""")
Path('.venv-audit/native-worker/recover-kd-cli-v2.py').write_text(s)
