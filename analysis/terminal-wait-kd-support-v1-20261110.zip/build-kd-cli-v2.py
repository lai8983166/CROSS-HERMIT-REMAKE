from pathlib import Path
s=Path('devtools/terminal_kd_wait_cli.py').read_text().replace('import concurrent.futures as cf','import concurrent.futures as cf\nimport base64')
s=s.replace('cli-wait-v1','cli-wait-v2').replace('kd-cli-wait-v1','kd-cli-wait-v2')
start=s.index("        r['modules']=")
end=s.index("        r['kernel_sha256']",start)
s=s[:start]+'''        source=Path('F:/project/chaomofa/devtools/terminal_kd_module_peb.cs')
        encoded=base64.b64encode(source.read_bytes()).decode()
        r['module_reader']=identity(source)
        script="$env:TEMP='C:\\\\ChaomofaWorker\\\\Temp';$env:TMP=$env:TEMP;Add-Type -TypeDefinition ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+encoded+"')));$a=[OwnedWow64Module]::Find("+str(ready['pid'])+");$a|Add-Member -NotePropertyName sha256 -NotePropertyValue (Get-FileHash -LiteralPath $a.path -Algorithm SHA256).Hash -PassThru|ConvertTo-Json -Compress"
        module=json.loads(run_guest(script));r['modules']=module
        need(module['sha256'].lower()=='6d3e9d039c22b58c577435ef0209d43668ef2003e284be9980e4ad1289045a66','actual loaded WOW64 CPU module')
''' +s[end:]
s=s.replace("    except Exception as exc:r['errors'].append(repr(exc))", "    except Exception as exc:r['errors'].append(repr(exc));print('preflight failure: '+repr(exc),flush=True)")
s=s.replace("        pool.shutdown(wait=True)", "        if launch and not launch.done() and p is None:\n            try:run_guest(\"[IO.File]::WriteAllText('\"+q+\"\\\\go','continue');'released preparation gate'\")\n            except Exception as exc:r['errors'].append('gate cleanup: '+repr(exc))\n        pool.shutdown(wait=True)\n        if launch and 'completion' not in r:\n            try:r['completion']=json.loads(launch.result())\n            except Exception as exc:r['errors'].append('launcher: '+repr(exc))")
p=Path('devtools/terminal_kd_wait_cli_v2.py')
if p.exists():raise ValueError('fresh version')
p.write_text(s)
