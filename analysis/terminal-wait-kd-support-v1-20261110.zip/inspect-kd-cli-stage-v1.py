import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_windows_vm import WORKER
r=run_guest("[pscustomobject]@{processes=@(Get-Process fixture -ErrorAction SilentlyContinue|Select-Object Id,Path);modules=@(Get-Process fixture -ErrorAction SilentlyContinue|ForEach-Object {$_.Modules|Select-Object ModuleName,@{n='base';e={$_.BaseAddress.ToInt64()}},FileName});files=@(Get-ChildItem -LiteralPath C:\\ChaomofaWorker\\kd-cli-wait-v1-20261110|Select-Object Name,Length)}|ConvertTo-Json -Depth 6 -Compress")
(WORKER/'kd-worker/cli-stage-v1.json').write_text(r)
v=json.loads(r);print(json.dumps(dict(processes=v['processes'],modules=[x for x in v['modules']if 'wow' in x['ModuleName'].lower()],files=v['files'])))
