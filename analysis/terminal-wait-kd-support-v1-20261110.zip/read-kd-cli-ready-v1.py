import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
r={}
try:
 target=WORKER/'kd-worker/cli-ready-copy-v1.json'
 if target.exists():raise ValueError('fresh output')
 r['copy']=vmrun(['CopyFileFromGuestToHost',VMX,PureWindowsPath('C:/ChaomofaWorker/kd-cli-wait-v1-20261110/ready.json'),target],guest=True,timeout=15)
 r['ready']=json.loads(target.read_text())
except Exception as e:r['error']=repr(e)
(WORKER/'kd-worker/cli-ready-transfer-v1.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
