from pathlib import Path
s=Path('.venv-audit/native-worker/run-kd-cli-v3.py').read_text().replace("out=D/'cli-wait-v3.json';log=D/'cli-wait-v3.log'", "out=D/'cli-wait-v3b.json';log=D/'cli-wait-v3b.log'")
s=s.replace("r=dict(accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,errors=[]);p=None;t=time.monotonic()", "r=json.loads((D/'cli-wait-v3.json').read_text());r['parent_error']=r.pop('errors');r['errors']=[];p=None;t=time.monotonic()")
start=s.index(" r['guest_before']=json.loads(run_guest(STATUS))")
end=s.index(" ready=collect('supervisor-ready.json',15)",start)
s=s[:start]+s[end:]
s=s.replace("  if vmrun(['fileExistsInGuest',VMX,guest/name],guest=True,timeout=5).strip()=='The file exists.':", "  try:exists=vmrun(['fileExistsInGuest',VMX,guest/name],guest=True,timeout=5).strip()=='The file exists.'\n  except RuntimeError as exc:\n   if 'The file does not exist.' not in str(exc):raise\n   exists=False\n  if exists:")
Path('.venv-audit/native-worker/run-kd-cli-v3b.py').write_text(s)
