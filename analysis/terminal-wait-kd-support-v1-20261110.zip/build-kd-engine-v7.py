from pathlib import Path
s=Path('devtools/isolated_kd_engine_v6.py').read_text()
s=s.replace("'dt nt!_EPROCESS UniqueProcessId DebugPort','? @$tpid'", "'dt nt!_EPROCESS UniqueProcessId DebugPort','? @$tpid'")
s=s.replace("or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+',command)", "or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+',command)\n             or re.fullmatch(r'ba e 1 ffff[0-9a-f`]+ \"\\.if \\(@\\$tpid == 0x[0-9a-f]+\\) \\{ \\.if \\(@\\$tid == 0x[0-9a-f]+\\) \\{ \\.echo OWNED_WAIT_RETURN \\} \\.else \\{ gc \\} \\} \\.else \\{ gc \\}\"',command)")
s=s.replace("'dt nt!_KTRAP_FRAME','dt nt!_KTHREAD'", "'dt nt!_KTRAP_FRAME','dt nt!_KTHREAD'")
# Kernel debugging executes pending GO only when it enters WaitForEvent.
old="if self.attached:self.check(method(self.client,26,H,U)(self.client,2),'EndSession active detach')"
new="""if self.attached:
                if self.status()==6:
                    self.execute('bc *')
                    self.go()
                try:self.wait(1000)
                except RuntimeError as exc:
                    if 'HRESULT=8000000a' not in str(exc):raise
                self.check(method(self.client,26,H,U)(self.client,2),'EndSession active detach')"""
if old not in s:raise ValueError('old close')
s=s.replace(old,new)
p=Path('devtools/isolated_kd_engine_v7.py')
if p.exists():raise ValueError('fresh version')
p.write_text(s)
