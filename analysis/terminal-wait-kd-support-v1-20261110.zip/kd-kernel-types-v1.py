"""Offline local-PE/PDB symbol extraction only; no KD connection or guest I/O."""
import ctypes as c,ctypes.wintypes as w,json,hashlib,struct,uuid
from pathlib import Path
import pefile,capstone
R=Path('F:/project/chaomofa'); root=R/'.venv-audit/native-worker'
exe=root/'guest-ntoskrnl.exe';pdb=root/'symbols/ntkrnlmp.pdb/D801A9AFC0FB7761380800F708633DEA1/ntkrnlmp.pdb'
raw=exe.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5669b9b8bfcf20f08b7d1d65dc2deccbf836279c0e3f66722d72ad33ee7f672a'
pe=pefile.PE(data=raw);cv=[pe.get_data(x.struct.AddressOfRawData,x.struct.SizeOfData) for x in pe.DIRECTORY_ENTRY_DEBUG if x.struct.Type==2];assert len(cv)==1 and cv[0][:4]==b'RSDS'
praw=pdb.read_bytes();assert praw.startswith(b'Microsoft C/C++ MSF 7.00')
block,free,blocks,ds,reserved,bmap=struct.unpack_from('<6I',praw,32)
indexes=struct.unpack_from('<'+'I'*((ds+block-1)//block),praw,bmap*block)
directory=b''.join(praw[i*block:(i+1)*block] for i in indexes)[:ds]
n=struct.unpack_from('<I',directory)[0];sizes=struct.unpack_from('<'+'I'*n,directory,4);off=4+4*n;streams=[]
for size in sizes:
 count=0 if size==0xffffffff else (size+block-1)//block
 ids=struct.unpack_from('<'+'I'*count,directory,off);off+=4*count
 streams.append(b''.join(praw[i*block:(i+1)*block] for i in ids)[:size])
print("IDENTITY",cv[0].hex(),streams[1][:32].hex(),block,ds,sizes[:3]);print("DBI",streams[3][:16].hex());assert streams[3][8:12]==cv[0][20:24] and streams[1][12:28]==cv[0][4:20]
dll=c.WinDLL('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/dbghelp.dll',use_last_error=True)
k=c.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=w.HANDLE;h=k.GetCurrentProcess()
dll.SymSetOptions.argtypes=[w.DWORD];dll.SymSetOptions.restype=w.DWORD;dll.SymSetOptions(0x400|0x80000|0x200|0x2)
dll.SymInitializeW.argtypes=[w.HANDLE,w.LPCWSTR,w.BOOL];dll.SymInitializeW.restype=w.BOOL
assert dll.SymInitializeW(h,str(root/'symbols'),False),c.get_last_error()
dll.SymLoadModuleExW.argtypes=[w.HANDLE,w.HANDLE,w.LPCWSTR,w.LPCWSTR,c.c_uint64,w.DWORD,c.c_void_p,w.DWORD];dll.SymLoadModuleExW.restype=c.c_uint64
base=dll.SymLoadModuleExW(h,None,str(exe),'nt',pe.OPTIONAL_HEADER.ImageBase,pe.OPTIONAL_HEADER.SizeOfImage,None,0);assert base,c.get_last_error()
class SI(c.Structure):
 _fields_=[('SizeOfStruct',w.ULONG),('TypeIndex',w.ULONG),('Reserved',c.c_uint64*2),('Index',w.ULONG),('Size',w.ULONG),('ModBase',c.c_uint64),('Flags',w.ULONG),('Value',c.c_uint64),('Address',c.c_uint64),('Register',w.ULONG),('Scope',w.ULONG),('Tag',w.ULONG),('NameLen',w.ULONG),('MaxNameLen',w.ULONG),('Name',c.c_char*1)]
dll.SymFromName.argtypes=[w.HANDLE,c.c_char_p,c.POINTER(SI)];dll.SymFromName.restype=w.BOOL

dll.SymGetTypeFromName.argtypes=[w.HANDLE,c.c_uint64,c.c_char_p,c.POINTER(SI)];dll.SymGetTypeFromName.restype=w.BOOL
dll.SymGetTypeInfo.argtypes=[w.HANDLE,c.c_uint64,w.ULONG,c.c_int,c.c_void_p];dll.SymGetTypeInfo.restype=w.BOOL
out={}
for name in ['_KTRAP_FRAME','_KTHREAD','_KEXCEPTION_FRAME','_XSAVE_FORMAT','_XSTATE_SAVE','_KPROCESSOR_STATE']:
 buf=c.create_string_buffer(c.sizeof(SI)+1024);si=c.cast(buf,c.POINTER(SI));si.contents.SizeOfStruct=c.sizeof(SI);si.contents.MaxNameLen=1024
 assert dll.SymGetTypeFromName(h,base,name.encode(),si),(name,c.get_last_error())
 tid=si.contents.TypeIndex;length=c.c_uint64();assert dll.SymGetTypeInfo(h,base,tid,2,c.byref(length))
 count=w.ULONG();assert dll.SymGetTypeInfo(h,base,tid,13,c.byref(count));kids=(w.ULONG*(count.value+2))();kids[0]=count.value;kids[1]=0;assert dll.SymGetTypeInfo(h,base,tid,7,c.byref(kids))
 fields=[]
 for child in kids[2:]:
  n=c.c_wchar_p();off=w.ULONG()
  assert dll.SymGetTypeInfo(h,base,child,1,c.byref(n))
  if dll.SymGetTypeInfo(h,base,child,10,c.byref(off)):fields.append(dict(name=n.value,offset=off.value))
 out[name]=dict(bytes=length.value,fields=fields)
p=root/'kd-kernel-types-v1.json';p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
