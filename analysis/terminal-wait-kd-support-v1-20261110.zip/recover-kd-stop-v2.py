import json,sys
from pathlib import Path
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_kd_engine_v6 import Engine
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_vm_guest_admin import STATUS
from devtools.isolated_windows_vm import WORKER
p=WORKER/'kd-worker/recovery-v2.json'
if p.exists():raise ValueError('fresh recovery')
e=Engine();r={}
try:
 e.attach();e.interrupt();e.wait(10000)
 r['registers']=e.execute('r');r['breakpoints_before']=e.execute('bl')
 e.execute('bc *');r['breakpoints_after']=e.execute('bl');e.go()
 try:e.wait(1000)
 except RuntimeError as x:r['bounded_running_wait']=repr(x)
finally:e.close();r['output']=e.output;r['calls']=e.calls
try:r['guest']=json.loads(run_guest(STATUS))
except Exception as x:r['guest_error']=repr(x)
p.write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items()if k not in ('output','calls')}))
