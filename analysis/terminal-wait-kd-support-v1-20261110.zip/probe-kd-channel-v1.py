import ctypes as C,json,re,sys,time
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_kd import PIPE,validate_kd_vmx,run_guest
from devtools.isolated_vm_guest_admin import STATUS
from devtools.isolated_kd_engine import Engine
D=WORKER/'kd-worker';out=D/'channel-v1.json'
if out.exists():raise ValueError('fresh KD channel probe')
validate_kd_vmx(VMX.read_text(encoding='utf8'))
if str(VMX).lower()in vmrun(['list']).lower():raise ValueError('owned worker must begin off')
r=dict(accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,errors=[]);e=None;t=time.monotonic()
try:
    r['start']=vmrun(['start',VMX,'nogui'],timeout=30)
    k=C.WinDLL('kernel32',use_last_error=True);k.WaitNamedPipeW.argtypes=[C.c_wchar_p,C.c_ulong];k.WaitNamedPipeW.restype=C.c_int
    if not k.WaitNamedPipeW(PIPE,10000):raise OSError(C.get_last_error(),'owned virtual pipe unavailable')
    k.CreateFileW.argtypes=[C.c_wchar_p,C.c_ulong,C.c_ulong,C.c_void_p,C.c_ulong,C.c_ulong,C.c_void_p];k.CreateFileW.restype=C.c_void_p
    h=k.CreateFileW(PIPE,0,0,None,3,0,None)
    if h==C.c_void_p(-1).value:raise OSError(C.get_last_error(),'owned virtual pipe identity open')
    try:
        pid=C.c_ulong();k.GetNamedPipeServerProcessId.argtypes=[C.c_void_p,C.POINTER(C.c_ulong)];k.GetNamedPipeServerProcessId.restype=C.c_int
        if not k.GetNamedPipeServerProcessId(h,C.byref(pid)):raise OSError(C.get_last_error(),'pipe owner PID')
        log=(WORKER/'vmware.log').read_text(encoding='utf8');m=re.search(r'Log for VMware Workstation pid=(\d+)',log)
        if not m or pid.value!=int(m[1])or 'Config file: '+str(VMX)not in log:raise ValueError('pipe server must own this boot dedicated VM')
        r['pipe_server_pid']=pid.value
    finally:k.CloseHandle.argtypes=[C.c_void_p];k.CloseHandle(h)
    e=Engine();r['engine_identities']=e.identities;e.attach();e.interrupt()
    for _ in range(6):
        if e.wait(10000):break
    else:raise ValueError('bounded initial KD event deadline')
    r['initial_status']=e.status();r['initial_target']=e.execute('vertarget');r['initial_registers']=e.execute('r');r['module']=e.execute('lm m nt')
    e.go();e.wait(100)
    r['continued']=True
except Exception as exc:r['errors'].append(repr(exc))
finally:
    if e:
        try:e.close();r['detached']=True
        except Exception as exc:r['errors'].append('detach: '+repr(exc))
        r['output']=e.output;r['calls']=e.calls
    r['elapsed_seconds']=time.monotonic()-t
    with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('output','calls')},indent=2))
if r['errors']:raise SystemExit(1)
