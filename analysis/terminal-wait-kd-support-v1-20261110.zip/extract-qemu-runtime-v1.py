import json,subprocess,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,environment,identity
D=WORKER/'qemu-worker';runtime=D/'runtime';out=D/'runtime-v1.json'
if runtime.exists()or out.exists():raise ValueError('fresh portable runtime')
source=D/'qemu-w64-setup-20260811.exe';proof=json.loads((D/'download-v1.json').read_bytes())
if identity(source)['sha256']!=proof['file']['sha256']:raise ValueError('fixed publisher verified bytes')
listing=(D/'installer-members-v1.txt').read_text(encoding='utf8');entries=[]
for block in listing.split('\n\n'):
    fields=dict(line.split(' = ',1)for line in block.splitlines()if ' = 'in line)
    if 'Path'in fields:entries.append(fields)
firmware={'share/bios-256k.bin','share/bios.bin','share/kvmvapic.bin','share/vgabios-stdvga.bin','share/vgabios-vmware.bin','share/keymaps/en-us'}
selected=[]
for e in entries:
    p=PureWindowsPath(e['Path']);s=p.as_posix()
    if (len(p.parts)==1 and (p.suffix=='.dll' or p.name in('qemu-system-x86_64.exe','qemu-img.exe')))or s in firmware:selected.append(e)
if len(selected)<10:raise ValueError('expected runtime members')
runtime.mkdir();cmd=['C:/Program Files/7-Zip/7z.exe','x','-y','-o'+str(runtime),str(source)]+[e['Path']for e in selected]
p=subprocess.run(cmd,capture_output=True,env=environment(),timeout=60)
if p.returncode:raise RuntimeError('bounded portable extraction failed')
rows=[identity(p)for p in runtime.rglob('*')if p.is_file()]
if len(rows)!=len(selected):raise ValueError('exact extracted member set')
version=subprocess.check_output([str(runtime/'qemu-system-x86_64.exe'),'--version'],env=environment(),timeout=10).decode()
r=dict(accepted=False,source=identity(source),version=version,files=rows,total_bytes=sum(x['bytes']for x in rows),host_installer_run=False,registry_or_host_virtualization_changes=False)
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k!='files'},indent=2))
