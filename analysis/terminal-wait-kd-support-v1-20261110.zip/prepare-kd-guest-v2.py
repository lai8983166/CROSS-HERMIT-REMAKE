import json,sys
from pathlib import Path,PureWindowsPath
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_vm_kd import SETTINGS,validate_kd_vmx
D=WORKER/'kd-worker';D.mkdir(exist_ok=True);out=D/'prepare-v2.json';guest=PureWindowsPath('C:/ChaomofaWorker/kd-preflight-v1-20261110');q=str(guest)
if out.exists()or (D/'bcd-before').exists():raise ValueError('fresh KD preparation')
if run_script("if(@(Get-Process 'CROSS HERMIT',python,pythonw,helper,fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};'idle'").strip()!='idle':raise ValueError('idle owned guest')
r=dict(accepted=False,host_input_actions=0,original_game_started=False,guest_before=json.loads(run_script(STATUS)),host_boot_configuration_changed=False)
script="$current=(& bcdedit /enum '{current}'|Out-String);if($LASTEXITCODE){throw 'current BCD query'};$settings=(& bcdedit /dbgsettings|Out-String);if($LASTEXITCODE){throw 'settings query'};if($current -match '(?im)^debug\s+Yes'){throw 'preexisting debugger'};[pscustomobject]@{current=$current;settings=$settings;backup=(Get-FileHash -LiteralPath '"+q+"\bcd-before' -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json -Compress"
r['preparation_note']='v1 exported BCD before any modification; JSON parse rejected mixed bcdedit stdout. v2 rechecks still-disabled current setting and uses that preserved backup.'
r['boot_before']=json.loads(run_script(script))
vmrun(['CopyFileFromGuestToHost',VMX,guest/'bcd-before',D/'bcd-before'],guest=True)
if identity(D/'bcd-before')['sha256']!=r['boot_before']['backup']:raise ValueError('exact BCD recovery copy')
r['boot_after']=run_script("& bcdedit /dbgsettings serial debugport:1 baudrate:115200;if($LASTEXITCODE){throw 'guest serial debugger settings'};& bcdedit /debug '{current}' on;if($LASTEXITCODE){throw 'guest debugger enable'};& bcdedit /enum '{current}';if($LASTEXITCODE){throw 'current readback'};& bcdedit /dbgsettings;if($LASTEXITCODE){throw 'debug readback'}")
r['soft_stop']=vmrun(['stop',VMX,'soft'],timeout=30);r['running_after']=vmrun(['list'])
if str(VMX).lower()in r['running_after'].lower():raise ValueError('guest must be off for virtual port configuration')
raw=VMX.read_bytes();validate_vmx(raw.decode('utf8'))
with(D/'vmx-before.txt').open('xb')as f:f.write(raw)
r['vmx_before']=identity(VMX)
new=raw+b'\r\n'+''.join(k+' = "'+v+'"\r\n'for k,v in SETTINGS.items()).encode()
validate_kd_vmx(new.decode('utf8'));VMX.write_bytes(new);r['vmx_after']=identity(VMX);r['virtual_pipe_settings']=SETTINGS
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps({k:v for k,v in r.items()if k not in ('boot_before','boot_after')},indent=2))
