import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_vm_guest_admin import STATUS
r={}
try:
 target=WORKER/'kd-worker/cli-fixture-result-v1.json'
 if target.exists():raise ValueError('fresh output')
 r['copy']=vmrun(['CopyFileFromGuestToHost',VMX,PureWindowsPath('C:/ChaomofaWorker/kd-cli-wait-v1-20261110/result.json'),target],guest=True,timeout=15)
 r['result']=json.loads(target.read_text())
except Exception as e:r['copy_error']=repr(e)
try:
 r['guest']=json.loads(run_guest(STATUS))
 r['processes']=run_guest("@(Get-Process fixture -ErrorAction SilentlyContinue|Select-Object Id,Path)|ConvertTo-Json -Compress")
except Exception as e:r['guest_error']=repr(e)
(WORKER/'kd-worker/cli-fixture-final-v1.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items()if k!='result'}))
