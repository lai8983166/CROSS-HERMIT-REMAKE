"""Offline local-PE/PDB symbol extraction only; no KD connection or guest I/O."""
import ctypes as c,ctypes.wintypes as w,json,hashlib,struct,uuid
from pathlib import Path
import pefile,capstone
R=Path('F:/project/chaomofa'); root=R/'.venv-audit/native-worker'
exe=root/'guest-ntoskrnl.exe';pdb=root/'symbols/ntkrnlmp.pdb/D801A9AFC0FB7761380800F708633DEA1/ntkrnlmp.pdb'
raw=exe.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5669b9b8bfcf20f08b7d1d65dc2deccbf836279c0e3f66722d72ad33ee7f672a'
pe=pefile.PE(data=raw);cv=[pe.get_data(x.struct.AddressOfRawData,x.struct.SizeOfData) for x in pe.DIRECTORY_ENTRY_DEBUG if x.struct.Type==2];assert len(cv)==1 and cv[0][:4]==b'RSDS'
praw=pdb.read_bytes();assert praw.startswith(b'Microsoft C/C++ MSF 7.00')
block,free,blocks,ds,reserved,bmap=struct.unpack_from('<6I',praw,32)
indexes=struct.unpack_from('<'+'I'*((ds+block-1)//block),praw,bmap*block)
directory=b''.join(praw[i*block:(i+1)*block] for i in indexes)[:ds]
n=struct.unpack_from('<I',directory)[0];sizes=struct.unpack_from('<'+'I'*n,directory,4);off=4+4*n;streams=[]
for size in sizes:
 count=0 if size==0xffffffff else (size+block-1)//block
 ids=struct.unpack_from('<'+'I'*count,directory,off);off+=4*count
 streams.append(b''.join(praw[i*block:(i+1)*block] for i in ids)[:size])
print("IDENTITY",cv[0].hex(),streams[1][:32].hex(),block,ds,sizes[:3]);print("DBI",streams[3][:16].hex());assert streams[3][8:12]==cv[0][20:24] and streams[1][12:28]==cv[0][4:20]
dll=c.WinDLL('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/dbghelp.dll',use_last_error=True)
k=c.WinDLL('kernel32',use_last_error=True);k.GetCurrentProcess.restype=w.HANDLE;h=k.GetCurrentProcess()
dll.SymSetOptions.argtypes=[w.DWORD];dll.SymSetOptions.restype=w.DWORD;dll.SymSetOptions(0x400|0x80000|0x200|0x2)
dll.SymInitializeW.argtypes=[w.HANDLE,w.LPCWSTR,w.BOOL];dll.SymInitializeW.restype=w.BOOL
assert dll.SymInitializeW(h,str(root/'symbols'),False),c.get_last_error()
dll.SymLoadModuleExW.argtypes=[w.HANDLE,w.HANDLE,w.LPCWSTR,w.LPCWSTR,c.c_uint64,w.DWORD,c.c_void_p,w.DWORD];dll.SymLoadModuleExW.restype=c.c_uint64
base=dll.SymLoadModuleExW(h,None,str(exe),'nt',pe.OPTIONAL_HEADER.ImageBase,pe.OPTIONAL_HEADER.SizeOfImage,None,0);assert base,c.get_last_error()
class SI(c.Structure):
 _fields_=[('SizeOfStruct',w.ULONG),('TypeIndex',w.ULONG),('Reserved',c.c_uint64*2),('Index',w.ULONG),('Size',w.ULONG),('ModBase',c.c_uint64),('Flags',w.ULONG),('Value',c.c_uint64),('Address',c.c_uint64),('Register',w.ULONG),('Scope',w.ULONG),('Tag',w.ULONG),('NameLen',w.ULONG),('MaxNameLen',w.ULONG),('Name',c.c_char*1)]
dll.SymFromName.argtypes=[w.HANDLE,c.c_char_p,c.POINTER(SI)];dll.SymFromName.restype=w.BOOL
names=['KiDispatchException','KdTrap','KdpTrap','KdIgnoreUmExceptions','KiDebugRoutine','KdIsThisAKdTrap','DbgkForwardException','PsGetProcessDebugPort','KiDebugTrapOrFault','KiExceptionDispatch','KdpReportExceptionStateChange','KdDebuggerEnabled','KdDebuggerNotPresent','NtWaitForSingleObject','KiSystemCall64','KiSystemCall64Shadow','KiSystemServiceExit','KiSystemServiceUser','KiSystemServiceCopyEnd','KiServiceExit','KiSystemServiceRepeat','KeWaitForSingleObject']
rows={}
for name in names:
 buf=c.create_string_buffer(c.sizeof(SI)+1024);s=c.cast(buf,c.POINTER(SI));s.contents.SizeOfStruct=c.sizeof(SI);s.contents.MaxNameLen=1024
 ok=dll.SymFromName(h,('nt!'+name).encode(),s)
 rows[name]={'available':bool(ok),'error':c.get_last_error() if not ok else 0}
 if ok:rows[name].update(rva=s.contents.Address-base,size=s.contents.Size,tag=s.contents.Tag)
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64);md.detail=True
for name,row in rows.items():
 if row['available'] and name not in ['KdIgnoreUmExceptions','KdDebuggerEnabled','KdDebuggerNotPresent']:
  if not row['size']:
   spans=[e.struct for e in pe.DIRECTORY_ENTRY_EXCEPTION if e.struct.BeginAddress<=row['rva']<e.struct.EndAddress]
   assert len(spans)==1,(name,len(spans))
   row['size']=spans[0].EndAddress-row['rva']
  size=min(row['size'],0x4000);data=pe.get_data(row['rva'],size)
  row['raw_hex']=data.hex();row['instructions']=[dict(rva=i.address,hex=i.bytes.hex(),mnemonic=i.mnemonic,op_str=i.op_str) for i in md.disasm(data,row['rva'])]
out={'scope':'offline source bytes only; no live KD session','accepted':False,'kernel':{'path':str(exe),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)},'pdb':{'path':str(pdb),'sha256':hashlib.sha256(praw).hexdigest(),'bytes':len(praw),'guid':str(uuid.UUID(bytes_le=cv[0][4:20])),'age':struct.unpack_from('<I',cv[0],20)[0],'identity_matches':True,'pdb_info_age':struct.unpack_from('<I',streams[1],8)[0],'dbi_age':struct.unpack_from('<I',streams[3],8)[0],'match_basis':'PE GUID matches PDB info GUID; PE age matches DBI age; exact-symbol DbgHelp lookup'},'symbols':rows}
p=root/'kd-kernel-boundaries-v1.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({n:{k:v for k,v in r.items() if k not in ['instructions','raw_hex']} for n,r in rows.items()},indent=2));print('output',p,p.stat().st_size)
dll.SymCleanup.argtypes=[w.HANDLE];dll.SymCleanup(h)
