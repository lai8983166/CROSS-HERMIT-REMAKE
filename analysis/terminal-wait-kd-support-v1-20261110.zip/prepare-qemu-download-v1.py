import hashlib,json,sys,time,urllib.request
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_windows_vm import WORKER,identity
D=WORKER/'qemu-worker';D.mkdir(exist_ok=True)
url='https://qemu.weilnetz.de/w64/qemu-w64-setup-20260811.exe'
expected='5bcf9eed634e8575a37b74f445af41a2fe4106da512d0c30c368301d4c105037fdfab40a5287367a28a957624cddebbc8c07e16c88ab6634f554cdf3d16bf543'
out=D/'download-v1.json';target=D/'qemu-w64-setup-20260811.exe';partial=target.with_suffix('.exe.part')
if out.exists()or target.exists()or partial.exists():raise ValueError('fresh bounded download')
t=time.monotonic();h=hashlib.sha512();count=0
with urllib.request.urlopen(url,timeout=30)as src,partial.open('xb')as dst:
    length=int(src.headers['Content-Length']);final_url=src.url
    if not 0<length<220*1024**2 or final_url!=url:raise ValueError('publisher URL and bounded expected length')
    for block in iter(lambda:src.read(1024*1024),b''):
        count+=len(block)
        if count>length or time.monotonic()-t>240:raise ValueError('bounded download deadline/length')
        h.update(block);dst.write(block)
if count!=length or h.hexdigest()!=expected:raise ValueError('publisher SHA512 mismatch')
partial.rename(target)
r=dict(accepted=False,url=url,publisher_checksum_url=url.replace('.exe','.sha512'),publisher_sha512=expected,actual_sha512=h.hexdigest(),file=identity(target),elapsed_seconds=time.monotonic()-t,installed=False,storage='F-drive portable extraction only; no host installer execution')
with out.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r,indent=2))
