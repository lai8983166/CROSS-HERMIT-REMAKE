from pathlib import Path
s=Path('.venv-audit/native-worker/recover-kd-stop-v2.py').read_text().replace('recovery-v2.json','recovery-v3.json')
Path('.venv-audit/native-worker/recover-kd-stop-v3.py').write_text(s)
