import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_vm_guest_admin import STATUS
from devtools.isolated_windows_vm import WORKER
r={}
try:r['guest']=json.loads(run_guest(STATUS));r['fixtures']=run_guest("@(Get-Process fixture -ErrorAction SilentlyContinue|Select-Object Id,Path)|ConvertTo-Json -Compress")
except Exception as e:r['error']=repr(e)
(WORKER/'kd-worker/guest-status-v1.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
