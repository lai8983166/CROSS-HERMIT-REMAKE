import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_windows_vm import WORKER
q='C:\\ChaomofaWorker\\kd-wait-tail-v1-20261110'
s=';'.join("[IO.File]::WriteAllText('"+q+'\\'+n+"','continue')"for n in ('go','ack-0','ack-1','ack-2','ack-3'))
s+=";Start-Sleep -Milliseconds 1000;[pscustomobject]@{processes=@(Get-Process fixture -ErrorAction SilentlyContinue|Select-Object Id,Path);files=@(Get-ChildItem -LiteralPath '"+q+"'|Select-Object Name,Length);result=if(Test-Path -LiteralPath '"+q+"\\result.json'){Get-Content -LiteralPath '"+q+"\\result.json' -Raw}else{$null};watchdog=Test-Path -LiteralPath '"+q+"\\result.json.watchdog.json'}|ConvertTo-Json -Depth 5 -Compress"
r=json.loads(run_guest(s));(WORKER/'kd-worker/fixture-v1-final.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:v for k,v in r.items()if k!='result'}))
