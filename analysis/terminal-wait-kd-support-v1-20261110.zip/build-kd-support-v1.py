import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path('F:/project/chaomofa');w=root/'.venv-audit/native-worker';d=w/'kd-worker'
out=root/'analysis/terminal-wait-kd-support-v1-20261110.zip'
if out.exists():raise ValueError('fresh capsule')
baseline=1794242373
files=[]
for p in w.iterdir():
 if p.is_file()and p.stat().st_mtime>baseline and p.suffix in ('.py','.json','.txt') and p.stat().st_size<2*1024*1024 and p.name!='credentials.private.json':
  files.append(p)
files += [p for p in d.rglob('*')if p.is_file()]
q=w/'qemu-worker'
files += [p for p in q.rglob('*')if p.is_file()and 'runtime' not in p.relative_to(q).parts and p.suffix!='.exe']
files=sorted(set(files));rows=[]
secret=json.loads((w/'credentials.private.json').read_bytes())['password']
needles=[secret.encode(),secret.encode('utf-16le')]
if sum(p.stat().st_size for p in files)>16*1024*1024:raise ValueError('bounded support capsule')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in files:
  b=p.read_bytes()
  if any(n in b for n in needles):raise ValueError('private secret in candidate support')
  name=p.relative_to(w).as_posix();z.writestr(name,b)
  rows.append(dict(path=str(p),member=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
manifest=dict(capsule=dict(path=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest()),members=rows,uncompressed_bytes=sum(x['bytes']for x in rows),note='One compressed recovery copy of bounded raw receipts and execution drivers; native code is committed separately. QEMU installer/runtime excluded and remain local, deletion blocked by tool policy.')
(d/'support-manifest-v1.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items()if k!='members'}));print('members',len(rows))
