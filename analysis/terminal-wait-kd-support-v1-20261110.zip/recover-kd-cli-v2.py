import json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,environment,identity
from devtools.isolated_vm_kd import PIPE,run_guest
from devtools.isolated_vm_guest_admin import STATUS
d=WORKER/'kd-worker';log=d/'cli-recovery-v2.log';out=d/'cli-recovery-v2.json'
if log.exists()or out.exists():raise ValueError('fresh recovery')
env=environment();env['_NT_SYMBOL_PATH']=str(WORKER/'symbols');env['_NT_ALT_SYMBOL_PATH']=''
exe=Path('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/kd.exe');r=dict(errors=[])
p=None;t=time.monotonic()
try:
 with log.open('xb')as f:
  p=subprocess.Popen([str(exe),'-k','com:pipe,port='+PIPE+',resets=0,reconnect','-bonc','-noshell','-sins','-y',str(WORKER/'symbols'),'-c','bc *;bl;r;.echo OWNED_RECOVERED;g'],stdin=subprocess.PIPE,stdout=f,stderr=subprocess.STDOUT,cwd=WORKER,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
  end=time.monotonic()+20
  while '\nOWNED_RECOVERED\n' not in log.read_text(errors='replace'):
   if p.poll()is not None or time.monotonic()>end:raise ValueError('bounded recovery marker')
   time.sleep(.1)
  r['extra_break_continues']=[]
  last=0;deadline=time.monotonic()+8
  while time.monotonic()<deadline:
   data=log.read_text(errors='replace')
   if data.rstrip().endswith('kd>') and len(data)!=last:
    if len(r['extra_break_continues'])>=4:raise ValueError('bounded pending debugger breaks')
    r['extra_break_continues'].append(len(data));last=len(data)
    p.stdin.write(b'bc *;.echo OWNED_CONTINUE;g\n');p.stdin.flush()
   time.sleep(.1)
  r['guest_after']=json.loads(run_guest(STATUS))
  p.terminate();p.wait(timeout=5);r['client_stopped_after_resumed']=True
except Exception as e:r['errors'].append(repr(e))
finally:
 if p and p.poll()is None:p.terminate();p.wait(timeout=5);r['emergency_client_stop']=True
 r['log']=identity(log);r['elapsed_seconds']=time.monotonic()-t;out.write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
