import json,re,subprocess,sys,time
from pathlib import Path,PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,environment,identity
from devtools.isolated_vm_kd import run_guest,validate_kd_vmx,PIPE
from devtools.isolated_vm_guest_admin import STATUS
D=WORKER/'kd-worker';out=D/'cli-wait-v3.json';log=D/'cli-wait-v3.log'
guest=PureWindowsPath('C:/ChaomofaWorker/kd-cli-wait-v3-20261110');q=str(guest)
source=WORKER/'vm-wait-fixture-v1-20261110'
if out.exists()or log.exists():raise ValueError('fresh v3')
validate_kd_vmx(VMX.read_text(encoding='utf8'))
r=dict(accepted=False,fullstate=False,fullABI=False,original_game_started=False,host_input_actions=0,errors=[]);p=None;t=time.monotonic()
def collect(name,seconds):
 target=D/('cli-v3-'+name)
 if target.exists():raise ValueError('fresh transfer '+name)
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if vmrun(['fileExistsInGuest',VMX,guest/name],guest=True,timeout=5).strip()=='The file exists.':
   vmrun(['CopyFileFromGuestToHost',VMX,guest/name,target],guest=True,timeout=5)
   return json.loads(target.read_text())
  time.sleep(.2)
 raise ValueError('bounded file deadline '+name)
try:
 r['guest_before']=json.loads(run_guest(STATUS))
 if r['guest_before']['boot']!='2026-11-10T01:00:17.5000000Z':raise ValueError('fixed boot kernel base')
 run_guest("if(@(Get-Process fixture -ErrorAction SilentlyContinue).Count){throw 'busy'};if(Test-Path -LiteralPath '"+q+"'){throw 'fresh'};New-Item -ItemType Directory -Path '"+q+"'|Out-Null;'ready'")
 r['kernel_sha256']=run_guest('(Get-FileHash C:\\Windows\\System32\\ntoskrnl.exe -Algorithm SHA256).Hash').strip().lower()
 for name in('fixture.bin','fixture.exe','manifest.json','terminal_vm_wait_fixture.cs'):
  vmrun(['CopyFileFromHostToGuest',VMX,source/name,guest/name],guest=True)
 supervisor=Path('F:/project/chaomofa/devtools/terminal_kd_fixture_supervisor.py');r['supervisor']=identity(supervisor)
 vmrun(['CopyFileFromHostToGuest',VMX,supervisor,guest/'supervisor.py'],guest=True)
 r['launch']=vmrun(['runProgramInGuest',VMX,'-noWait',PureWindowsPath('C:/ChaomofaWorker/Python/pythonw.exe'),'-B',guest/'supervisor.py',guest],guest=True,timeout=10)
 ready=collect('supervisor-ready.json',15);r['prepared']=ready;fixture=ready['ready'];module=ready['module']
 if module['sha256']!='6d3e9d039c22b58c577435ef0209d43668ef2003e284be9980e4ad1289045a66':raise ValueError('actual module file')
 count=fixture['data']+0x200
 body='.echo OWNED_WAIT_BEGIN;r;? @$tpid;? @$tid;dq @rsp L20;dq @rbp-0x80 L32;dq %x L1;u poi(@rbp+0xe8)-2 L8;.echo OWNED_WAIT_END;.if (dwo(%x) == 3) { bc *;bl;.echo OWNED_FOUR_COMPLETE;gc } .else { gc }'%(count,count)
 condition='.if (@$tpid == 0x%x) { .if (@$tid == 0x%x) { .if (poi(@rbp-0x48) == 0x%x) { %s } .else { gc } } .else { gc } } .else { gc }'%(fixture['pid'],fixture['tid'],fixture['event_handle'],body)
 command='bc *;ba e 1 fffff806208fcc6a "'+condition+'";.echo OWNED_CLI_ARMED;g';r['command']=command
 exe=Path('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/kd.exe');r['client']=identity(exe)
 env=environment();env['_NT_SYMBOL_PATH']=str(WORKER/'symbols');env['_NT_ALT_SYMBOL_PATH']=''
 with log.open('xb')as f:
  p=subprocess.Popen([str(exe),'-k','com:pipe,port='+PIPE+',resets=0,reconnect','-bonc','-noshell','-sins','-y',str(WORKER/'symbols'),'-c',command],stdin=subprocess.PIPE,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=WORKER,creationflags=subprocess.CREATE_NO_WINDOW)
  r['client_pid']=p.pid;end=time.monotonic()+15
  while not re.search(r'^OWNED_CLI_ARMED\r?$',log.read_text(errors='replace'),re.M):
   if p.poll()is not None or time.monotonic()>end:raise ValueError('bounded KD arm')
   time.sleep(.1)
  gate=D/'cli-v3-go.txt';gate.write_text('continue');vmrun(['CopyFileFromHostToGuest',VMX,gate,guest/'go'],guest=True,timeout=5)
  r['completion']=collect('supervisor.json',25)
  r['guest_after']=json.loads(run_guest(STATUS))
  if not re.search(r'^OWNED_FOUR_COMPLETE\r?$',log.read_text(errors='replace'),re.M):raise ValueError('missing four-return complete marker')
  p.terminate();p.wait(timeout=5);r['client_stopped_after_guest_resumed']=True
except Exception as e:r['errors'].append(repr(e));print('preflight failure: '+repr(e),flush=True)
finally:
 if p and p.poll()is None:p.terminate();p.wait(timeout=5);r['emergency_client_stop']=True
 r['elapsed_seconds']=time.monotonic()-t
 if log.exists():r['log']=identity(log)
 out.write_text(json.dumps(r,indent=2))
print(json.dumps(dict(errors=r['errors'],elapsed_seconds=r['elapsed_seconds'],path=str(out))))
