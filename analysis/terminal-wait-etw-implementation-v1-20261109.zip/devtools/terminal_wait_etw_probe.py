"""Guest-only, bounded ETW capability fixture; never starts or attaches to a game.

This tests kernel event availability, not original-game behavior or full ABI.
StartTrace owns NT Kernel Logger only on ERROR_SUCCESS. An existing logger is
never stopped, updated or reused. Unsupported privilege/schema is a blockage.
"""
import argparse
import ctypes as C
import datetime as DT
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import struct
import subprocess
import sys
import threading
import time
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
LOGGER = 'NT Kernel Logger'
ETL_LIMIT = 4 * 1024 * 1024
XML_LIMIT = 24 * 1024 * 1024
EVENT_LIMIT = 150000
WALL_SECONDS = 30
PERF_GUID = 'ce1dbfb4-137e-4da6-87b0-3f59aa102cbc'
THREAD_GUID = '3d6fa8d1-fe05-11d0-9dda-00c04fd7ba7c'
SYSTEM_GUID = '9e814aad-3204-11d2-9a82-006008a86939'
REFERENCES = [
    'https://learn.microsoft.com/en-us/windows/win32/etw/syscallenter',
    'https://learn.microsoft.com/en-us/windows/win32/etw/syscallexit',
    'https://learn.microsoft.com/en-us/windows/win32/etw/cswitch',
    'https://learn.microsoft.com/en-us/windows/win32/api/evntrace/nf-evntrace-starttracew',
    'https://learn.microsoft.com/en-us/windows/win32/etw/configuring-and-starting-the-nt-kernel-logger-session',
    'https://learn.microsoft.com/en-us/windows/win32/etw/logging-mode-constants',
    'https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracerpt',
]


def need(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def number(value):
    s = str(value).strip()
    return int(s, 16 if s.lower().startswith('0x') else 10)


def utc_ns(value):
    match = re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,9}))?Z', value)
    need(match, 'unsupported tracerpt UTC timestamp: ' + value[:80])
    seconds = int(DT.datetime.fromisoformat(match[1]).replace(tzinfo=DT.timezone.utc).timestamp())
    return seconds * 10**9 + int((match[2] or '').ljust(9, '0'))


class WNODE(C.Structure):
    _fields_ = [('BufferSize', C.c_uint32), ('ProviderId', C.c_uint32),
                ('HistoricalContext', C.c_uint64), ('TimeStamp', C.c_int64),
                ('Guid', C.c_ubyte * 16), ('ClientContext', C.c_uint32), ('Flags', C.c_uint32)]


class PROPERTIES(C.Structure):
    _fields_ = [('Wnode', WNODE)] + [(n, C.c_uint32) for n in (
        'BufferSize', 'MinimumBuffers', 'MaximumBuffers', 'MaximumFileSize',
        'LogFileMode', 'FlushTimer', 'EnableFlags', 'AgeLimit', 'NumberOfBuffers',
        'FreeBuffers', 'EventsLost', 'BuffersWritten', 'LogBuffersLost', 'RealTimeBuffersLost')]
    _fields_ += [('LoggerThreadId', C.c_void_p), ('LogFileNameOffset', C.c_uint32),
                 ('LoggerNameOffset', C.c_uint32)]


def properties(path=None):
    """Explicit 64-bit Windows layout, UTF16 strings, bounded sequential file."""
    need(C.sizeof(C.c_void_p) == 8 and C.sizeof(WNODE) == 48 and C.sizeof(PROPERTIES) == 120,
         '64-bit ETW controller ABI required')
    buf = C.create_string_buffer(120 + 4096)
    p = PROPERTIES.from_buffer(buf)
    p.Wnode.BufferSize = len(buf)
    p.Wnode.Flags = 0x20000  # WNODE_FLAG_TRACED_GUID
    p.Wnode.Guid[:] = uuid.UUID(SYSTEM_GUID).bytes_le
    p.Wnode.ClientContext = 1  # QPC: recommended common clock for system loggers
    p.LoggerNameOffset = 120
    name = (LOGGER + '\0').encode('utf-16-le')
    C.memmove(C.addressof(buf) + 120, name, len(name))
    if path is not None:
        text = (str(path) + '\0').encode('utf-16-le')
        need(len(text) <= 2048, 'bounded ETL path')
        p.LogFileNameOffset = 120 + 2048
        C.memmove(C.addressof(buf) + p.LogFileNameOffset, text, len(text))
        p.BufferSize = 64
        p.MinimumBuffers = 4
        p.MaximumBuffers = 8  # <=512 KiB configured buffer pool
        p.MaximumFileSize = 4  # MiB; sequential logging stops at maximum
        p.LogFileMode = 1
        p.FlushTimer = 1
        p.EnableFlags = 0x97  # PROCESS | THREAD | IMAGE_LOAD | CSWITCH | SYSTEMCALL
    return buf, p


class Session:
    def __init__(self, advapi, path):
        self.api = advapi
        self.path = path
        self.handle = C.c_uint64()
        self.owned = False
        self.record = dict(logger=LOGGER, owned=False, start_status=None, stop_status=None)

    def start(self):
        buf, p = properties(self.path)
        self.record['requested_properties_hex'] = bytes(p).hex()
        status = int(self.api.StartTraceW(C.byref(self.handle), LOGGER, C.byref(p)))
        self.record['start_status'] = status
        if status == 0:
            self.owned = True
            self.record.update(owned=True, handle=self.handle.value)
        need(status == 0, 'StartTraceW status=' + str(status) + '; existing/denied logger never modified')

    def stop(self):
        if not self.owned:
            return self.record
        buf, p = properties()
        # The documented kernel-logger API requires KERNEL_LOGGER_NAME; retain
        # the exact acquired nonzero handle as well. Never stop after failed start.
        status = int(self.api.ControlTraceW(self.handle.value, LOGGER, C.byref(p), 1))
        self.record.setdefault('stop_attempts', []).append(status)
        self.record.update(stop_status=status, statistics={name: int(getattr(p, name)) for name in (
            'EventsLost', 'LogBuffersLost', 'RealTimeBuffersLost', 'BuffersWritten', 'NumberOfBuffers')})
        self.record['returned_stop_properties_hex'] = bytes(p).hex()
        # ERROR_MORE_DATA is documented as stopped; NOT_FOUND may be a full
        # sequential log. Neither supplies a successful complete statistics set.
        self.owned = status not in (0, 234, 4201)
        self.record['stopped'] = status == 0
        # Failed stops are explicit blockers, never silently called successful.
        return self.record


def qualify():
    from devtools.native_input_isolation import require_qualified_guest
    return require_qualified_guest()


def bind_windows():
    need(sys.platform == 'win32', 'Windows guest required')
    k = C.WinDLL('kernel32', use_last_error=True)
    signatures = {
        'GetCurrentThreadId': (C.c_uint32, []),
        'CreateEventW': (C.c_void_p, [C.c_void_p, C.c_int, C.c_int, C.c_wchar_p]),
        'SetEvent': (C.c_int, [C.c_void_p]),
        'WaitForSingleObject': (C.c_uint32, [C.c_void_p, C.c_uint32]),
        'CloseHandle': (C.c_int, [C.c_void_p]),
        'GetSystemTimePreciseAsFileTime': (None, [C.POINTER(C.c_uint64)]),
    }
    for name, (restype, args) in signatures.items():
        f = getattr(k, name); f.restype = restype; f.argtypes = args
    a = C.WinDLL('advapi32', use_last_error=True)
    a.StartTraceW.restype = a.ControlTraceW.restype = C.c_uint32
    a.StartTraceW.argtypes = [C.POINTER(C.c_uint64), C.c_wchar_p, C.POINTER(PROPERTIES)]
    a.ControlTraceW.argtypes = [C.c_uint64, C.c_wchar_p, C.POINTER(PROPERTIES), C.c_uint32]
    return k, a


def fixture():
    """Owned helper only: readiness before trace, two waits, all handles closed."""
    qualify()
    k, unused = bind_windows()
    tid = k.GetCurrentThreadId()
    events = [k.CreateEventW(None, False, False, None) for _ in range(2)]
    report = dict(pid=os.getpid(), tid=tid, rows=[], closed=[], error=None)
    def utc_now_ns():
        ticks = C.c_uint64()
        k.GetSystemTimePreciseAsFileTime(C.byref(ticks))
        return (ticks.value - 116444736000000000) * 100
    signal = None
    try:
        need(all(events), 'fixture CreateEventW error=' + str(C.get_last_error()))
        print(json.dumps(dict(ready=True, pid=os.getpid(), tid=tid)), flush=True)
        command = queue.Queue()
        threading.Thread(target=lambda: command.put(sys.stdin.buffer.readline(16)), daemon=True).start()
        need(command.get(timeout=10) == b'GO\n', 'owned controller GO required within ten seconds')
        signal_result = []
        def signal_later():
            time.sleep(.05)
            signal_result.append(bool(k.SetEvent(events[0])))
        signal = threading.Thread(target=signal_later, daemon=True)
        signal.start()
        for label, handle, timeout, expected in (
                ('success', events[0], 500, 0), ('timeout', events[1], 80, 258)):
            begin = utc_now_ns()
            value = k.WaitForSingleObject(handle, timeout)
            end = utc_now_ns()
            report['rows'].append(dict(label=label, begin_ns=begin, end_ns=end,
                timeout_ms=timeout, Win32_result=value, expected_NTSTATUS=expected,
                tid=tid, handle=int(handle)))
            need(value == expected, 'fixture wait result mismatch')
        signal.join(1)
        need(not signal.is_alive() and signal_result == [True], 'fixture signaling completed')
    except Exception as exc:
        report['error'] = repr(exc)
    finally:
        if signal is not None:
            signal.join(1)
        for handle in events:
            if handle:
                report['closed'].append(bool(k.CloseHandle(handle)))
    print(json.dumps(report), flush=True)
    return 1 if report['error'] or report['closed'] != [True, True] else 0


def local(tag):
    return tag.rsplit('}', 1)[-1]


def decode_event(element):
    """Only documented GUID/opcode/payload schemas; unfamiliar XML blocks."""
    system = next((x for x in element if local(x.tag) == 'System'), None)
    if system is None:
        return None
    fields = {local(x.tag): x for x in system}
    provider = fields.get('Provider')
    if provider is None:
        return None
    guid = provider.attrib.get('Guid', '').strip('{}').lower()
    if guid not in (PERF_GUID, THREAD_GUID):
        return None
    opcode = number(fields['Opcode'].text)
    if (guid, opcode) not in ((PERF_GUID, 51), (PERF_GUID, 52), (THREAD_GUID, 36)):
        return None
    execution = fields['Execution'].attrib
    data = {x.attrib['Name']: x.text for x in element.iter()
            if local(x.tag) == 'Data' and 'Name' in x.attrib}
    # Some tracerpt schema renderers use named UserData leaves instead.
    for x in element.iter():
        name = local(x.tag)
        if name in ('SysCallAddress', 'SysCallNtStatus', 'NewThreadId', 'OldThreadId'):
            need(name not in data or data[name] == x.text, 'conflicting ETW payload representations')
            data[name] = x.text
    timestamp = utc_ns(fields['TimeCreated'].attrib['SystemTime'])
    cpu = execution.get('ProcessorID', execution.get('ProcessorNumber'))
    return dict(guid=guid, opcode=opcode, ns=timestamp,
        tid=number(execution.get('ThreadID', '-1')), pid=number(execution.get('ProcessID', '-1')),
        cpu=number(cpu) if cpu is not None else None, data=data)


def analyze_events(events, helper, statistics):
    """Conservative syscall pairing, no invented TID or completion events."""
    need(helper['error'] is None and helper['closed'] == [True, True], 'owned helper failed cleanup/waits')
    need(all(statistics.get(k) == 0 for k in ('EventsLost', 'LogBuffersLost', 'RealTimeBuffersLost')),
         'all three ETW loss counters must be present and zero')
    tid = helper['tid']; pid = helper['pid']; cpu_current = {}; open_calls = {}
    pairs = []; unmatched = []; switches = 0; last_ns = -1
    for e in events:
        need(e['ns'] >= last_ns, 'tracerpt kernel records not monotonic; no guessed reorder')
        last_ns = e['ns']; data = e['data']; cpu = e['cpu']
        if e['opcode'] == 36:
            switches += 1
            if cpu is not None:
                cpu_current[cpu] = number(data['NewThreadId'])
            continue
        event_tid = e['tid']
        if event_tid in (-1, 0, 0xffffffff):
            event_tid = cpu_current.get(cpu)
            method = 'CSwitch_current_thread'
        else:
            method = 'event_header'
            if cpu in cpu_current:
                need(cpu_current[cpu] == event_tid, 'header/current-CPU TID conflict')
        if event_tid != tid:
            continue
        need(e['pid'] in (-1, 0, 0xffffffff, pid), 'target TID reused by another PID')
        if e['opcode'] == 51:
            need(tid not in open_calls, 'overlapping/unclosed target syscall')
            open_calls[tid] = dict(ns=e['ns'], address=number(data['SysCallAddress']), method=method)
        else:
            before = open_calls.pop(tid, None)
            if before is None:
                unmatched.append(dict(kind='exit_without_entry', ns=e['ns']))
                continue
            pairs.append(dict(tid=tid, begin_ns=before['ns'], end_ns=e['ns'],
                syscall_address=before['address'], NTSTATUS=number(data['SysCallNtStatus']),
                entry_tid_method=before['method'], exit_tid_method=method))
    matches = []
    for row in helper['rows']:
        need(row['tid'] == tid and row['begin_ns'] <= row['end_ns'], 'fixture identity/time window')
        need(row['Win32_result'] == row['expected_NTSTATUS']
             and row['expected_NTSTATUS'] in (0, 258), 'actual helper success/timeout result')
        candidates = [p for p in pairs if row['begin_ns'] <= p['begin_ns'] <= p['end_ns'] <= row['end_ns']
                      and p['NTSTATUS'] == row['expected_NTSTATUS']]
        matches.append((row, candidates))
        need(not any(row['begin_ns'] <= x['ns'] <= row['end_ns'] for x in unmatched),
             'unpaired syscall inside fixture wait window')
    need([x[0]['label'] for x in matches] == ['success', 'timeout'], 'both fixture wait outcomes required')
    need(matches[0][0]['end_ns'] <= matches[1][0]['begin_ns'], 'ordered fixture wait intervals')
    need([x[0]['expected_NTSTATUS'] for x in matches] == [0, 258], 'success then timeout statuses')
    common = set(p['syscall_address'] for p in matches[0][1]) & set(p['syscall_address'] for p in matches[1][1])
    need(len(common) == 1 and 0 not in common, 'no unique common syscall address for both outcomes')
    address = next(iter(common)); selected = []
    for row, candidates in matches:
        candidates = [p for p in candidates if p['syscall_address'] == address]
        need(len(candidates) == 1, 'ambiguous target syscall in fixture interval')
        selected.append(dict(label=row['label'], **candidates[0]))
    need(switches > 0, 'CSwitch event capability absent')
    return dict(capability_observed=True, selected_pairs=selected, context_switch_records=switches,
        target_pairs=len(pairs), unmatched_target_exits=len(unmatched),
        correlation='unique same-address kernel syscall spans inside owned wait intervals',
        kernel_symbol_identity_verified=False, argument_handles_in_ETW=False,
        original_game_observed=False, full_ABI_verified=False, accepted=False)


def read_events(path):
    need(path.stat().st_size <= XML_LIMIT, 'bounded tracerpt XML exceeded')
    # Reject entities/DTD rather than expanding arbitrary XML declarations.
    with path.open('rb') as f:
        previous = b''
        for chunk in iter(lambda: f.read(65536), b''):
            scan = (previous + chunk).replace(b'\0', b'')
            need(b'<!DOCTYPE' not in scan and b'<!ENTITY' not in scan, 'DTD is not tracerpt event data')
            previous = scan[-32:]
    count = 0
    for event, element in ET.iterparse(path, events=('end',)):
        if local(element.tag) == 'Event':
            count += 1
            need(count <= EVENT_LIMIT, 'bounded decoded event count')
            row = decode_event(element)
            if row is not None:
                yield row
            element.clear()


def run(out):
    begun = time.monotonic(); deadline = begun + WALL_SECONDS
    qualification = qualify()  # Before output creation, kernel API or helper launch.
    out = out.resolve()
    need(out.parent == ROOT / 'analysis' and not out.exists() and out.suffix == '.json', 'new guest analysis JSON required')
    folder = out.with_suffix('')
    need(not folder.exists(), 'new bounded evidence directory required')
    folder.mkdir()
    etl = folder / 'trace.etl'; xml = folder / 'events.xml'
    result = dict(kind='owned_ETW_capability_fixture', accepted=False, status='blocked',
        original_game_observed=False, full_ABI_verified=False, qualification=qualification,
        implementation=identity(Path(__file__)), references=REFERENCES, errors=[],
        limits=dict(trace_bytes=ETL_LIMIT, decoded_XML_bytes=XML_LIMIT, wall_seconds=WALL_SECONDS),
        clock='ETW QPC converted to UTC by tracerpt; helper GetSystemTimePreciseAsFileTime; no matching tolerance',
        trace=None, helper=None, analysis=None, cleanup={})
    child = None; session = None
    def remaining(cap):
        value = min(cap, deadline-time.monotonic())
        need(value > 0, '30-second ETW fixture budget exhausted')
        return value
    try:
        k, advapi = bind_windows()
        child = subprocess.Popen([sys.executable, '-B', '-X', 'utf8', '-m',
            'devtools.terminal_wait_etw_probe', '--fixture'], cwd=ROOT,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        lines = queue.Queue()
        threading.Thread(target=lambda: lines.put(child.stdout.readline(65536)), daemon=True).start()
        ready = json.loads(lines.get(timeout=remaining(22)))
        need(ready.get('ready') is True and ready['pid'] == child.pid, 'exact owned fixture ready')
        result['helper_ready'] = ready
        session = Session(advapi, etl)
        try:
            session.start()
            output, error = child.communicate(b'GO\n', timeout=remaining(3))
            need(len(output) <= 65536 and len(error) <= 8192, 'bounded helper output')
            result['helper_exit'] = child.returncode
            result['helper_stderr'] = error.decode('utf8', errors='replace')
            result['helper'] = json.loads(output)
            need(child.returncode == 0 and result['helper']['pid'] == child.pid
                 and result['helper']['tid'] == ready['tid'], 'same successful owned helper')
        finally:
            result['trace'] = session.stop()
        need(result['trace'].get('stop_status') == 0, 'owned ETW stop failed or trace already exhausted')
        need(etl.exists() and 0 < etl.stat().st_size <= ETL_LIMIT, '4 MiB ETL limit')
        need(etl.stat().st_size < ETL_LIMIT, 'trace reached sequential limit; completeness not assumed')
        tracerpt = Path(os.environ['SystemRoot']) / 'System32' / 'tracerpt.exe'
        need(tracerpt.is_file(), 'built-in tracerpt unavailable; no install fallback')
        result['tracerpt'] = identity(tracerpt)
        # No -lr fallback, overwrite flags, default report files or symbol downloads.
        with (folder / 'tracerpt.log').open('xb') as log:
            process = subprocess.Popen([str(tracerpt), str(etl), '-o', str(xml), '-of', 'XML'],
                cwd=folder, stdout=log, stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            try:
                while process.poll() is None:
                    remaining(1)
                    need(not xml.exists() or xml.stat().st_size <= XML_LIMIT, 'tracerpt decoded size limit')
                    need((folder / 'tracerpt.log').stat().st_size <= 65536, 'tracerpt output size limit')
                    time.sleep(.025)
            finally:
                if process.poll() is None:
                    process.kill(); process.wait(timeout=2)
        need(process.returncode == 0, 'tracerpt exit=' + str(process.returncode))
        result['analysis'] = analyze_events(read_events(xml), result['helper'], result['trace']['statistics'])
        result['status'] = 'capability_observed'
    except Exception as exc:
        result['errors'].append(repr(exc))
    finally:
        if session is not None and session.owned:
            result['trace'] = session.stop()
        if session is not None and session.owned:
            result['errors'].append('owned trace stop unresolved; retained exact logger handle in trace receipt')
            result['status'] = 'blocked'
        if child is not None:
            forced = child.poll() is None
            if forced:
                child.kill(); child.wait(timeout=2)
            result['cleanup']['owned_helper_forced'] = forced
            for pipe in (child.stdin, child.stdout, child.stderr):
                if pipe is not None:
                    pipe.close()
        result['elapsed_seconds'] = time.monotonic()-begun
        result['implementation_after'] = identity(Path(__file__))
        if result['implementation_after'] != result['implementation']:
            result['status'] = 'blocked'; result['errors'].append('fixture implementation changed during observation')
        result['artifacts'] = [identity(p) for p in folder.iterdir() if p.is_file()]
        if result['elapsed_seconds'] > WALL_SECONDS:
            result['status'] = 'blocked'; result['errors'].append('wall budget exceeded')
        with out.open('x', encoding='utf8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2); f.write('\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--fixture', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.fixture:
        raise SystemExit(fixture())
    parser.error('--out is required') if args.out is None else None
    result = run(args.out)
    print(json.dumps(dict(status=result['status'], errors=result['errors'], accepted=False)))
    raise SystemExit(0 if result['status'] == 'capability_observed' else 1)
