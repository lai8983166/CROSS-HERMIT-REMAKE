"""Close the bounded clock/endpoint increment without granting formal acceptance."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def ident(p):
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_bytes())
cutoff=1794224497
if list(W.rglob('*.vmem')):raise ValueError('VM memory file remains')
paths=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=A','-z'],cwd=R).decode().split('\0')
analysis=[ident(R/p)for p in paths if p.startswith('analysis/')]
files=[];environment=[];worker_bytes=0
for p in W.rglob('*'):
    if not p.is_file():continue
    st=p.stat();worker_bytes+=st.st_size
    if st.st_mtime<cutoff:continue
    if p.suffix.lower()in {'.vmdk','.vmem','.vmx','.vmxf','.nvram','.vmsd','.vmss','.lck'}or p.name.startswith('vmware'):
        environment.append(dict(path=p.relative_to(R).as_posix(),bytes=st.st_size));continue
    if 'credentials'in p.name.lower()or '.private.'in p.name.lower():continue
    if st.st_size>256*1024*1024:raise ValueError('unclassified large new file '+str(p))
    files.append(ident(p))
guest_path=W/'battle-wait-guest-storage-clock-v1-20261109.json';guest=read(guest_path)
cleanup_path=W/'battle-wait-guest-transfer-retirement-clock-v1-20261109.json';cleanup=read(cleanup_path)
tests_path=W/'battle-wait-unit-checks-gaps-v1-20261109.json';tests=read(tests_path)
if len(tests)!=2 or any(x['returncode']for x in tests):raise ValueError('ordinary and optimized regressions required')
if guest['game_and_python_processes']or not cleanup['all_removed']:raise ValueError('idle guest and completed cleanup required')
for row in cleanup['removed']:
    if row['guest']in {x['path'].replace('\\','/')for x in guest['files']}:raise ValueError('retired guest leaf remains')
parent=R/'analysis/terminal-battle-wait-closeout-v1-20261109.json'
review=R/'analysis/terminal-battle-wait-clock-settled-independent-review-v1-20261109.json'
if not review.is_file():raise ValueError('independent settled review required')
disk_bytes=sum(p.stat().st_size for p in W.glob('*.vmdk'))
out=R/'analysis/terminal-battle-wait-clock-closeout-v1-20261109.json'
report=dict(kind='clock_boundary_and_original_endpoint_increment',created_utc=datetime.now(timezone.utc).isoformat(),
    parent=ident(parent),accepted=False,formal_tasks_completed=2,formal_tasks_total=8,
    fullABI=False,fullstate=False,PTDcleanup=False,continuous_result_consumption_proved=False,
    full_resource_lifetime_proved=False,two_fresh_full_native_cases_verified=False,
    progress=dict(retained_same_battle_source_reused=True,recovered_result_endpoint='453CB5 inner_result=1',
        recovered_tail_endpoint='451758 tail_counter=0 callback_result=1',added_old_successful_waits=0,
        old_crossing_frames_still_unproved=[213,239,383,419],
        clock_armed=dict(snapshots=344,raw_QPC_qualified=343,converted_UTC_false_crossings=17,true_QPC_crossings=1),
        clock_settled=dict(snapshots=218,raw_QPC_qualified=218,distinct_waits=61,true_QPC_crossings=0,
            complete_ETL_events=94597,selected_records=1501),
        actual_startup_PTD_debug_header_and_heap_mode_observed=True),
    limitations=['old snapshots contain no raw QPC and cannot be retrospectively accepted',
        'supplemental battle endpoints lack complete precise brackets and raw Nt argument stack',
        'new data brackets exclude original context acquisition and settling; no complete state/ABI/instruction coverage',
        'nonwait settling timing absent; no full-attempt cumulative holding duration claimed',
        'current startup allocator observations do not prove old battle free, TLS clear, handle closure or scene cleanup',
        'legacy UTC diagnostic local long-preflight flag is not production authorization for new collector'],
    efficiency=dict(new_full_battle_prefix_attempts=0,new_formal_full_replays=0,new_bounded_native_attempts=4,
        attempts=['clock-v1 readiness failure','clock-v2 dual-clock diagnostic','clock-armed-v1 delayed sampling start','clock-settled-v1 held-thread settling'],
        decoder_fixes_reused_same_ETL=True,final_native_observation_seconds=21.953,
        complete_path_speedup_claimed=False),
    tests=dict(receipt=ident(tests_path),ordinary_count=429,optimized_count=429,
        ordinary_seconds=tests[0]['elapsed'],optimized_seconds=tests[1]['elapsed'],passed=True),
    preservation=read(W/'battle-wait-preservation-clock-v1-20261109.json'),
    independent_review=ident(review),strict_OpenSpec_valid=True,
    host_evidence_files=files,analysis_evidence_files_before_closeout=analysis,
    guest_inventory=ident(guest_path),guest_retained_files=guest['files'],
    cleanup=dict(receipt=ident(cleanup_path),guest_duplicate_files_removed=len(cleanup['removed']),
        guest_duplicate_bytes_removed=cleanup['total_bytes'],host_originals_retained=True,
        retirement_scope='only current clock transport leaf copies verified against retained F-drive originals',
        previous_kernel_duplicate_retained_bytes=11597168,
        previous_kernel_duplicate_deletion='previous automatic approval review rejection; not retried'),
    environment=dict(host_drive='F',guest_logical_C_inside_F_disk=True,cpu=2,memory_bytes=guest['memory'],
        VM_soft_stopped=True,VMEM_files_remaining=0,guest_game_and_python_processes_before_shutdown=0,
        host_interactive_input_used=False,continuous_host_performance_unaffected_proved=False,
        VM_disk_bytes=disk_bytes,baseline_VM_disk_bytes=16640507904,
        VM_disk_growth_bytes=disk_bytes-16640507904,baseline_worker_logical_bytes=22007431229,
        worker_logical_bytes_at_inventory=worker_bytes,mutable_environment_files=environment),
    storage_scope='Logical new evidence since parent commit 2026-11-09T11:41:37Z includes local helpers, all source/ETL/records, reports, capsules and guest retained copies. VM physical growth is separate, not double-counted as evidence. Repository implementation code is counted in Git size.',
    same_disk_backup_is_independent_disaster_recovery=False,
    staged_code_and_evidence_equal_executed_bytes=True,private_credential_scan_passed=True,
    host_new_evidence_bytes_including_closeout=0,total_new_local_evidence_bytes_including_guest_and_backups=0,
    Git_added_file_bytes_including_closeout=0,closeout_bytes=0)
base=sum(x['bytes']for x in files+analysis);git_base=sum((R/p).stat().st_size for p in paths if p)
for _ in range(12):
    report['host_new_evidence_bytes_including_closeout']=base+report['closeout_bytes']
    report['total_new_local_evidence_bytes_including_guest_and_backups']=base+report['closeout_bytes']+guest['remaining_current_round_guest_files_bytes']
    report['Git_added_file_bytes_including_closeout']=git_base+report['closeout_bytes']
    raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
    if len(raw)==report['closeout_bytes']:break
    report['closeout_bytes']=len(raw)
else:raise ValueError('fixed-point manifest size')
if report['total_new_local_evidence_bytes_including_guest_and_backups']>256*1024*1024:raise ValueError('evidence budget')
with out.open('xb')as f:f.write(raw)
print(json.dumps(dict(report=ident(out),local_evidence_bytes=report['total_new_local_evidence_bytes_including_guest_and_backups'],Git_added_file_bytes=report['Git_added_file_bytes_including_closeout'],VM_disk_growth_bytes=report['environment']['VM_disk_growth_bytes'])))
