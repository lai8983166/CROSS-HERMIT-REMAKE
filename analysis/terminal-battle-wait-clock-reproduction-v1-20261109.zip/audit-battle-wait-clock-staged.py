import hashlib,io,json,subprocess,sys,zipfile
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
secret=json.loads((W/'credentials.private.json').read_bytes())['password']
needles=[secret.encode(),secret.encode('utf-16le')]
paths=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=R).decode().split('\0')
added=set(subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=A','-z'],cwd=R).decode().split('\0'))
rows=[];members=0
for name in paths:
    if not name:continue
    data=subprocess.check_output(['git','show',':'+name],cwd=R)
    if any(x in data for x in needles):raise ValueError('private credential found in staged artifact')
    if name.startswith(('devtools/','analysis/'))and data!=(R/name).read_bytes():raise ValueError('staged/executed byte mismatch '+name)
    if len(data)>50*1024*1024:raise ValueError('new artifact requires explicit storage handling')
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data))as z:
            if sum(x.file_size for x in z.infolist())>16*1024*1024:raise ValueError('bounded capsule')
            for x in z.infolist():
                if any(n in z.read(x)for n in needles):raise ValueError('private credential found in capsule')
                members+=1
    rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),added=name in added))
check=subprocess.run(['git','diff','--cached','--check'],cwd=R,capture_output=True,text=True)
if check.returncode:raise ValueError('staged whitespace check failed')
out=W/('battle-wait-clock-staged-audit-'+sys.argv[1]+'.json')
result=dict(files=rows,staged_files=len(rows),added_file_bytes=sum(x['bytes']for x in rows if x['added']),
    largest_staged_file_bytes=max(x['bytes']for x in rows),capsule_members_scanned=members,
    code_and_evidence_staged_bytes_match_executed_files=True,credential_plaintext_and_UTF16_scan_passed=True,
    no_file_exceeds_50_MiB=True,diff_check_passed=True)
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items()if k!='files'}))
