"""Read-only installed-tool inventory; no heap logger or game is started."""
import hashlib,json,sys
from pathlib import Path
R=Path('F:/project/chaomofa');sys.path.insert(0,str(R))
from devtools.isolated_vm_guest_admin import run_script
script=r"""$busy=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*'});if($busy.Count){throw 'guest busy'};
$out=@();foreach($name in @('wpr.exe','xperf.exe','StartHeapTrace.exe')){$cmd=Get-Command $name -ErrorAction SilentlyContinue;if($cmd){$p=$cmd.Source;$f=Get-Item -LiteralPath $p;$out+=[pscustomobject]@{name=$name;path=$p;bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}else{$out+=[pscustomobject]@{name=$name;present=$false}}};
$wpt=@();foreach($p in @('C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit','C:\Program Files\Windows Kits\10\Windows Performance Toolkit')){$wpt+=[pscustomobject]@{path=$p;present=(Test-Path -LiteralPath $p)}};
[pscustomobject]@{computer=$env:COMPUTERNAME;boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o');commands=$out;WPT_directories=$wpt;busy_count=$busy.Count}|ConvertTo-Json -Depth 5 -Compress"""
raw=run_script(script);data=json.loads(raw)
report=dict(kind='read_only_guest_heap_observer_inventory',guest=data,accepted=False,
    game_started=False,logger_started=False,registry_changed=False,host_input_actions=0,
    actual_heap_free_verified=False,PTDcleanup=False,
    limitation='Installed command/path inventory only. Does not prove absence of native ETW APIs or qualify a PID-targeted observer.',
    implementation=dict(path=str(Path(__file__)),sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
p=R/'analysis/terminal-battle-wait-heap-capability-inventory-v1-20261109.json'
with p.open('x',encoding='utf8')as f:json.dump(report,f,indent=2)
print(json.dumps(report))
