import gzip,hashlib,json,struct,sys
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def ident(p):
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def gz(p):
    with gzip.open(p,'rb')as f:return json.load(f)
sp=W/'terminal-battle-wait-window-clock-settled-v1-20261109.json.gz'
up=W/'terminal-battle-wait-decode-clock-settled-utc-v1-20261109.records.json.gz'
rp=W/'terminal-battle-wait-decode-clock-settled-raw-v1-20261109.records.json.gz'
cp=R/'analysis/terminal-battle-wait-clock-settled-review-v1-20261109.json'
s=gz(sp);utc=gz(up)['records'];raw=gz(rp)['records'];review=json.loads(cp.read_bytes())
need(ident(sp)['sha256']=='53c8e6755188543eead8326d2dd6799ab9196f3784dd1dff8502c073c0e7a1df','fixed native source')
need(len(utc)==len(raw)==1501 and len(s['window_snapshots'])==len(review['snapshots'])==218,'complete independent source counts')
for a,b in zip(utc,raw):
    need(a['index']==b['index']and a['payload_hex']==b['payload_hex']and a['data']==b['data'],'same original selected event')
    x=bytearray.fromhex(a['record_header_hex']);y=bytearray.fromhex(b['record_header_hex'])
    need(struct.unpack_from('<q',y,16)[0]==b['qpc_ticks'],'raw header QPC')
    x[16:24]=y[16:24]=b'\0'*8;need(x==y,'only native timestamp changed')
positions={row['index']:i for i,row in enumerate(raw)};tid=s['subject']['tid'];margins=[];waits=set()
for index,(snap,claim)in enumerate(zip(s['window_snapshots'],review['snapshots'])):
    lo,hi=snap['timing_diagnostic']['data_interval_qpc']
    need(claim['snapshot_index']==index and claim['QPC_data_interval']==[lo,hi],'same exact snapshot interval')
    a,b=(positions[i]for i in claim['global_syscall_pair'])
    need(raw[a]['data']['SysCallAddress']==s['kernel_wait_export']['target']and raw[b]['data']['SysCallNtStatus']==0,'actual kernel wait/return')
    switches=[r for r in raw[a+1:b]if r['opcode']==36]
    found=[(x,y)for x,y in zip(switches,switches[1:])if x['data']['OldThreadId']==tid and y['data']['NewThreadId']==tid
           and x['qpc_ticks']+1<lo<=hi<y['qpc_ticks']-1]
    need(len(found)==1,'each entire raw data interval strictly inside one real off interval')
    x,y=found[0];margins.append(min(lo-x['qpc_ticks'],y['qpc_ticks']-hi));waits.add(tuple(claim['global_syscall_pair']))
    settle=snap['timing_diagnostic']['suspension_settling']
    need(0<settle['qpc_begin']<=settle['qpc_end']<=lo and settle['descheduling_assumed']is False,'actual earlier held settling')
need(len(waits)==61 and not review['QPC_crossing_snapshots'],'same independently counted finite waits')
need(all(review[k]is False for k in ('accepted','fullABI','fullstate','PTDcleanup','long_capture_preflight_passed')),'no upgraded acceptance')
out=R/'analysis/terminal-battle-wait-clock-main-review-v1-20261109.json'
result=dict(kind='main_agent_raw_QPC_boundary_review',references=[ident(p)for p in (sp,up,rp,cp,Path(__file__))],
    actual_snapshots_checked=218,distinct_waits_checked=len(waits),minimum_single_interval_margin_ticks=min(margins),
    raw_QPC_crossings=0,all_original_selected_headers_checked=1501,accepted=False,
    old_four_frames_remain_unproved=True,full_context_interval_proved=False,
    continuous_result_consumption_proved=False,PTDcleanup=False,full_resource_lifetime_proved=False,
    implementation_review='Reviewed exact collector/adapter, original held-context restoration, raw reader, supplemental raw stack verification, guest-only logon recovery and bounded transfer cleanup; existing frozen production files unchanged.',
    blocking_capabilities=['context acquisition plus data full-state/ABI/instruction coverage','actual original allocator/free result and TLS-clear observation','original handle/resource cleanup','new production-collector qualification before a representative full replay'],
    first_next_capability='bounded owned WOW64 PID-targeted heap observation plus complete context/state observation design; no repeated battle prefix yet')
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps(result))
