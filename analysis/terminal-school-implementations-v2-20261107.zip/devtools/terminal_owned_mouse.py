"""Exact game-coordinate feedback correction for bounded owned mouse input.

The original endpoint mapping is retained for the first movement. A same-window,
same-desktop feedback error of at most two pixels permits at most three small
normalized corrections. Final exact game coordinates and all guards still apply.
"""
import time
from devtools import terminal_menu_input as original
from devtools.terminal_scene_resources import clone

TARGETS=original.TARGETS
packet=original.packet
absolute_coordinates=original.absolute_coordinates

def guarded_click(api,guard,target,sleep=time.sleep,*,absolute=False):
    """Feedback from actual game coordinates is mandatory before button-down."""
    if target not in TARGETS.values():raise ValueError('only reviewed original main-menu targets')
    receipt=dict(target=list(target),moves=[],down_submitted=False,released=False,error=None,
                 game_memory_written=False,transition_proved=False,guard_observations=[],
                 movement_mode='absolute_virtual_desktop_feedback' if absolute else 'relative_feedback')
    def checked():receipt['guard_observations'].append(guard())
    last_movement=None
    try:
        checked()
        if api.left_button_down():raise ValueError('left button already held; no action')
        for attempt in range(4):
            checked();position=api.position()
            if position==target:break
            if absolute:
                geometry=api.geometry(target)
                dx,dy=absolute_coordinates(geometry['screen_target'],geometry['virtual_desktop'])
                entry=dict(before=list(position),geometry=geometry,flags=0xC001)
                if last_movement and geometry==last_movement['geometry']:
                    error=[target[i]-position[i]for i in range(2)]
                    if max(abs(v)for v in error)<=2:
                        left,top,right,bottom=geometry['window_rect'];sx,sy=geometry['screen_target']
                        if not (left+8<=sx<right-8 and top+8<=sy<bottom-8):
                            raise ValueError('feedback target lacks bounded movement margin')
                        width,height=geometry['virtual_desktop'][2:]
                        correction=[round(error[0]*65536/width),round(error[1]*65536/height)]
                        previous=last_movement['normalized'];dx,dy=[previous[i]+correction[i]for i in range(2)]
                        if not (0<=dx<=65535 and 0<=dy<=65535):raise ValueError('feedback outside normalized desktop')
                        entry['feedback_correction']=dict(error=error,previous_normalized=list(previous),delta=correction)
                entry['normalized']=[dx,dy]
                movement=packet(dx,dy,0xC001)
            else:
                dx=max(-512,min(512,target[0]-position[0]));dy=max(-512,min(512,target[1]-position[1]))
                movement=packet(dx,dy);entry=dict(before=list(position),delta=[dx,dy])
            checked();sent=api.submit(movement)
            receipt['moves'].append(dict(**entry,submitted=sent))
            if sent!=1:raise ValueError('mouse movement submission failed')
            if absolute:last_movement=receipt['moves'][-1]
            sleep(.05)
        checked();receipt['before_click']=list(api.position())
        if tuple(receipt['before_click'])!=target:raise ValueError('original game cursor did not reach reviewed target')
        if api.left_button_down():raise ValueError('left button changed before click')
        checked()
        if absolute:
            receipt['click_geometry']=api.geometry(target)
            absolute_coordinates(receipt['click_geometry']['screen_target'],receipt['click_geometry']['virtual_desktop'])
        receipt['down_wall_time_ns']=time.time_ns()
        receipt['down_result']=api.submit(packet(flags=2))
        if receipt['down_result']!=1:raise ValueError('left down was not submitted')
        receipt['down_submitted']=True
        sleep(.08)
        receipt['up_results']=[api.submit(packet(flags=4))]
        receipt['released']=receipt['up_results'][-1]==1
        receipt['up_wall_time_ns']=time.time_ns()
        if not receipt['released']:raise ValueError('left up was not submitted')
        # Post-input guard checks only the owned foreground target: the menu may
        # legitimately retire after the click, which is observed separately.
        api.final_guard()
    except Exception as exc:
        receipt['error']=repr(exc)
    finally:
        if receipt['down_submitted'] and not receipt['released']:
            try:
                receipt.setdefault('up_results',[]).append(api.submit(packet(flags=4)))
                receipt['released']=receipt['up_results'][-1]==1
            except Exception as exc:
                receipt['release_error']=repr(exc)
    return receipt


def owned_main_menu_click(c,hwnd,index,*,explicit_user_override=False):
    return clone(original.owned_main_menu_click,guarded_click=guarded_click)(
        c,hwnd,index,explicit_user_override=explicit_user_override)
