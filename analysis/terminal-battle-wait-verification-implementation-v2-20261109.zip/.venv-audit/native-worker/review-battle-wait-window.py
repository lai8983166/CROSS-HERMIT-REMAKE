"""Independent raw-byte recomputation of an existing bounded window proof."""
import gzip,hashlib,json,struct,sys,uuid
from pathlib import Path
R=Path('F:/project/chaomofa');W=R/'.venv-audit/native-worker'
def need(x,m):
 if not x:raise ValueError(m)
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sp=W/f'terminal-battle-wait-window-{sys.argv[1]}.json.gz'
dp=W/f'terminal-battle-wait-decode-{sys.argv[2]}.json'
rp=W/f'terminal-battle-wait-decode-{sys.argv[2]}.records.json.gz'
s=json.loads(gzip.decompress(sp.read_bytes()));d=json.loads(dp.read_text());rows=json.loads(gzip.decompress(rp.read_bytes()))['records']
need(not d['errors'] and d['analysis']['accepted']is False,'existing bounded verification without errors')
for p,reference in ((sp,d['source']),(rp,d['selected_records']),(W/sp.name.removesuffix('.json.gz')/'trace.etl',d['ETL'])):
 need(all(ident(p)[k]==reference[k]for k in ('bytes','sha256')),'actual source/ETL/records identity')
tid=s['subject']['tid'];active=None;pending=None;pairs={};partial=[];previous=(-1,-1)
for i,row in enumerate(rows):
 h=bytes.fromhex(row['record_header_hex']);bc=bytes.fromhex(row['buffer_context_hex']);p=bytes.fromhex(row['payload_hex'])
 need(len(h)==80 and len(bc)==4,'complete raw header')
 ns=(struct.unpack_from('<q',h,16)[0]-116444736000000000)*100
 need(ns==row['ns'] and str(uuid.UUID(bytes_le=h[24:40]))==row['guid'] and h[45]==row['opcode'],'actual event identity/time')
 need(struct.unpack_from('<II',h,8)==(row['tid'],row['pid']),'actual raw owner')
 cpu=struct.unpack_from('<H',bc)[0]if struct.unpack_from('<H',h,4)[0]&0x200 else bc[0]
 need(cpu==row['cpu'] and cpu in (0,1) and row['index']>previous[0] and ns>=previous[1],'ordered raw CPU flow')
 previous=row['index'],ns
 if h[45]==36:
  new,old=struct.unpack_from('<II',p)
  need((new,old)==(row['data']['NewThreadId'],row['data']['OldThreadId']) and old==row['decoder_cpu_tid_before'],'raw context switch')
  if old==tid:
   # The first retained switch may leave an already-running target.
   need(active in (None,cpu),'single target CPU out');active=None
  if new==tid:need(active is None,'single target CPU in');active=cpu
 else:
  need(active==cpu and row['decoder_cpu_tid_before']==tid,'actual syscall CPU owner')
  if h[45]==51:
   need(pending is None and int.from_bytes(p,'little')==row['data']['SysCallAddress'],'unambiguous syscall entry');pending=i
  else:
   need(h[45]==52 and len(p)==4 and int.from_bytes(p,'little')==row['data']['SysCallNtStatus'],'actual syscall exit')
   if pending is None:
    need(not pairs and not partial,'only first unpaired boundary exit');partial.append(i)
   else:pairs[(pending,i)]=(rows[pending]['index'],row['index']);pending=None
nt=next(x for x in s['API_exports']if x['name']=='NtWaitForSingleObject');checked=[]
for group in d['analysis']['waits']:
 a,b=group['selected_indices'];need(pairs[(a,b)]==tuple(group['global_indices']),'same raw syscall pair')
 need(rows[a]['data']['SysCallAddress']==s['kernel_wait_export']['target'] and rows[b]['data']['SysCallNtStatus']==0,'actual successful wait')
 for index in group['snapshot_indices']:
  snap=s['window_snapshots'][index];lo,hi=snap['snapshot_begin_ns'],snap['snapshot_end_ns']
  need(rows[a]['ns']<lo<=hi<rows[b]['ns'],'entire original snapshot inside actual wait')
  ctx=bytes.fromhex(snap['frame']['context_hex']);eip=struct.unpack_from('<I',ctx,184)[0];esp=struct.unpack_from('<I',ctx,196)[0]
  need(eip==nt['target']+12,'raw NtWait return PC')
  def mem(addr,n):
   vals=[bytes.fromhex(r['hex'])[addr-r['pointer']:addr-r['pointer']+n]for r in snap['stack_regions']if r['pointer']<=addr and addr+n<=r['pointer']+len(bytes.fromhex(r['hex']))]
   need(vals and len(set(vals))==1,'consistent actual stack bytes');return vals[0]
  event=struct.unpack_from('<I',bytes.fromhex(snap['node_hex']),0x1c)[0]
  need(struct.unpack('<III',mem(esp+4,12))==(event,0,0),'raw NT handle, alertable, timeout')
  api=next(x for x in snap['frame']['chain']if x['return_va']==0x42240d)
  need(struct.unpack('<IIII',mem(api['bp'],16))==(api['saved_bp'],0x42240d,event,0xffffffff),'raw original Win32 wait arguments')
  caller=next(x for x in snap['frame']['chain']if x['bp']==api['saved_bp'])
  need(caller['return_va']==group['semantic']['wait_return_site'],'actual original wait caller')
  sem=group['semantic'];returns={x['return_va']:x for x in snap['frame']['chain']}
  for name,ret,offset in (('callback_result',0x421f8a,0x0c),('dispatcher_result',0x451716,8),('inner_result',0x451abc,8)):
   if name in sem['result_locals']:
    frame=returns[ret];need(struct.unpack('<I',mem(frame['bp']-offset,4))[0]==sem['result_locals'][name],'actual original result local '+name)
  if sem['tail_counter']is not None:need(struct.unpack('<I',mem(returns[0x421f8a]['bp']-8,4))[0]==sem['tail_counter'],'actual tail counter')
 checked.append(dict(global_indices=group['global_indices'],site=hex(group['semantic']['wait_return_site']),samples=len(group['snapshot_indices']),result_locals=group['semantic']['result_locals'],tail_counter=group['semantic']['tail_counter']))
need(len(checked)==d['analysis']['distinct_successful_waits'],'all counted waits independently checked')
out=R/f'analysis/terminal-battle-wait-main-review-{sys.argv[3]}.json'
result=dict(source=ident(sp),proof=ident(dp),records=ident(rp),method='raw EVENT_HEADER/payload/CPU pair and raw original stack/local recomputation, no verifier imports',checked_waits=checked,initial_partial_exits=partial,final_partial_entry=pending,accepted=False,fullABI=False,fullstate=False,PTDcleanup=False,continuous_result_consumption=False)
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps(dict(review=ident(out),waits=len(checked))))
