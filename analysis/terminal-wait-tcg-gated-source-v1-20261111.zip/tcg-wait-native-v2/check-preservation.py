import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
root=Path('F:/project/chaomofa');out=root/'.venv-audit/native-worker/tcg-wait-native-v2/preservation.json'
parent=root/'analysis/reverse-validation-preservation-v1-20261106.json'
r=json.loads(parent.read_text());small=r['small_frozen_fresh_SHA'];large=r.get('large_size_only',r.get('large_frozen_size_only',[]));bad=[]
if len(small)!=832 or len(large)!=13:raise ValueError('frozen category')
for a in small:
 p=root/a['path']
 if not p.exists()or p.stat().st_size!=a['bytes']or hashlib.sha256(p.read_bytes()).hexdigest()!=a['sha256']:bad.append(a['path'])
for a in large:
 p=root/a['path']
 if not p.exists()or p.stat().st_size!=a['bytes']:bad.append(a['path'])
data=dict(checked_utc=datetime.now(timezone.utc).isoformat(),small_fresh_SHA_count=832,large_size_only_count=13,large_fresh_SHA=False,mismatches=bad)
with out.open('x',encoding='utf8')as f:json.dump(data,f,indent=2)
print(json.dumps(data))
if bad:raise SystemExit(1)
