import hashlib,json,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,ROOT,identity
cap=ROOT/'analysis/terminal-wait-bounded-query-support-v1-20261110.zip'
out=ROOT/'analysis/terminal-wait-bounded-query-closeout-v1-20261110.json'
if cap.exists()or out.exists():raise ValueError('fresh evidence')
paths=[]
for v in(1,2,3):paths.extend(p for p in(WORKER/('bounded-query-v%d-20261110'%v)).iterdir()if p.is_file())
paths.extend(WORKER.glob('build-bounded-query-v*.py'));paths.append(Path(__file__))
secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password'];needles=[secret.encode(),secret.encode('utf-16le')]
rows=[]
with zipfile.ZipFile(cap,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(paths):
  b=p.read_bytes()
  if any(n in b for n in needles)or len(b)>1024*1024:raise ValueError('bounded secret-free evidence')
  member=p.relative_to(WORKER).as_posix();z.writestr(member,b);rows.append(dict(member=member,**identity(p)))
 z.writestr('manifest.json',json.dumps(dict(baseline='e545f423e8df3dab4fdb1b3b3bead1b478062cb9',files=rows),indent=2))
with zipfile.ZipFile(cap)as z:
 for a in rows:
  if hashlib.sha256(z.read(a['member'])).hexdigest()!=a['sha256']:raise ValueError('capsule bytes')
final=json.loads((WORKER/'bounded-query-v3-20261110/report.json').read_text())
pres=json.loads((WORKER/'bounded-query-v3-20261110/preservation.json').read_text())
if final['errors']or pres['mismatches']or not final['host_deadline_preflight_passed']or final['running_after']!='Total running VMs: 0':raise ValueError('final checks')
reports=[identity(WORKER/('bounded-query-v%d-20261110'%v)/'report.json')for v in(1,2,3)]
tests=[identity(p)for p in(ROOT/'devtools/tests').glob('test_isolated_vm_bounded_query*.py')]
review=ROOT/'analysis/terminal-wait-bounded-query-review-v1-20261110.json'
r=dict(schema=1,created_utc=datetime.now(timezone.utc).isoformat(),baseline='e545f423e8df3dab4fdb1b3b3bead1b478062cb9',accepted=False,fullstate=False,fullABI=False,change='connect-terminal-wait-and-battle-exit',tasks_completed=2,tasks_total=8,
 functional_result=dict(new_read_only_host_deadline_preflight=True,normal_response_and_same_boot_after_timeout=True,remote_cancellation_proven=False,old_callers_replaced=False,original_game_starts=0,qualified_game_wait_returns=0,first_consumer=False,three_game_handshakes=False,resource_PTD_release=False),
 native_result=dict(final_report=reports[-1],initial_boot_timeout_seconds=final['boot_queries'][0]['elapsed_seconds'],requested_timeout_seconds=2,actual_timeout_seconds=final['deadline_query']['elapsed_seconds'],host_job_active_after=0,remote_completion='unknown',subsequent_query_seconds=final['after_query']['elapsed_seconds'],preflight_elapsed_seconds=final['elapsed_seconds']),
 validation=dict(unittest_runs=[dict(module='test_isolated_vm_bounded_query',reported_tests=5,passed=True),dict(module='test_isolated_vm_bounded_query_v2',reported_tests=4,passed=True),dict(module='test_isolated_vm_bounded_query_v3',reported_tests=7,passed=True,note='Includes four imported v2 cases and a case reusing four behaviors against v3; counts are not unique requirements.')],test_sources=tests,strict_openspec_passed=True,preservation=pres,independent_review=identity(review)),
 environment=dict(all_new_data_F=True,cpu=2,memory=final['before']['memory'],host_input_actions=0,new_download_bytes=0,host_BCD_changes=0,VMX_unchanged=final['vmx_before']==final['vmx_after'],final_soft_stop=True,running_VMs=0,snapshots=0,vmem_files=[],VMDK_growth_bytes=final['vmdk_after_bytes']-final['vmdk_before_bytes']),
 limits=['Operation deadline plus separately budgeted host cleanup; not an OS hard-real-time upper bound.','Only read-only status/owned bounded JSON/short sleep diagnostics are exposed; no launch, input, gate write or cancellation semantics.','Timed-out guest command remains unknown; no next mutating/native task is authorized by host cleanup.','Complete57 and transparent all-vCPU precise stop remain unproven. WHP field definitions are only a static candidate; no new monitor/VM was created.'],
 evidence=dict(reports=reports,support_capsule=identity(cap),source_files=rows,host_logical_bytes_before_final_audit=0,guest_artifact_files_created=0,same_disk_recovery_copy_not_independent_backup=True,cleanup='Temporary query output files close/delete automatically; no historical evidence, original assets, saves or retained QEMU environment removed. Final audit records all new local evidence and Git objects.'))
for _ in range(8):
 out.write_text(json.dumps(r,ensure_ascii=False,indent=2))
 size=sum(p.stat().st_size for p in paths)+cap.stat().st_size+out.stat().st_size+review.stat().st_size
 if size==r['evidence']['host_logical_bytes_before_final_audit']:break
 r['evidence']['host_logical_bytes_before_final_audit']=size
print(json.dumps(dict(capsule=identity(cap),closeout=identity(out),host_evidence_logical_bytes=size),indent=2))
