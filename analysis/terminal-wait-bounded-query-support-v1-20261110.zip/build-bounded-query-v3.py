from pathlib import Path
p=Path('devtools/isolated_vm_bounded_query_v2.py');s=p.read_text()
s=s.replace("    env=environment();job=Job();process=None", "    env=environment();job=None;process=None")
start=s.index('    # Direct base interpreter, -S/-I:')
end=s.index('        with tempfile.TemporaryFile',start)
part=s[start:end].replace('    try:\n','')
s=s[:start]+'    try:\n        job=Job()\n'+''.join('    '+line+'\n' for line in part.splitlines())+s[end:]
s=s.replace('from devtools.isolated_vm_bounded_query_v2 import _worker;', 'from devtools.isolated_vm_bounded_query_v3 import _worker;')
start=s.index('    finally:\n        # Close kills')
end=s.index('\n    return report',start)
s=s[:start]+'''    finally:
        # Each cleanup is attempted even if an earlier Win32 operation fails.
        if job:
            try:
                job.terminate()
            except Exception as exc:report['errors'].append('job termination: '+type(exc).__name__)
            try:
                job.close()
            except Exception as exc:report['errors'].append('job close: '+type(exc).__name__)
        try:
            if process and process.poll() is None:
                process.kill();process.wait(timeout=2)
        except Exception as exc:report['errors'].append('direct child cleanup: '+type(exc).__name__)
        report['elapsed_seconds']=time.monotonic()-started
''' +s[end:]
s += '''

def completed(report):
    return (not report.get('errors') and not report.get('timed_out')
            and report.get('host_job_active_after')==0
            and report.get('host_exit_code')==0
            and report.get('remote_completion')=='observed'
            and report.get('response',{}).get('ok') is True)
'''
q=p.with_name('isolated_vm_bounded_query_v3.py')
if q.exists():raise ValueError('fresh v3')
q.write_text(s)
p=Path('devtools/isolated_vm_bounded_query_preflight_v2.py');s=p.read_text().replace('from devtools.isolated_vm_bounded_query_v2 import query','from devtools.isolated_vm_bounded_query_v3 import query,completed')
s=s.replace("if q.get('response',{}).get('ok'):","if completed(q):")
s=s.replace("if r['completed_query'].get('response',{}).get('value','').strip()!='bounded-query-finished':", "if not completed(r['completed_query']) or r['completed_query'].get('response',{}).get('value','').strip()!='bounded-query-finished':")
s=s.replace("if not r['after_query'].get('response',{}).get('ok'):","if not completed(r['after_query']):")
q=p.with_name('isolated_vm_bounded_query_preflight_v3.py')
if q.exists():raise ValueError('fresh v3 preflight')
q.write_text(s)
