import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_kd import run_guest
D=WORKER/'kd-thread-v4-20261110';G=PureWindowsPath('C:/ChaomofaWorker/kd-thread-v4-20261110');parent=WORKER/'kd-thread-v2-20261110'
if D.exists():raise ValueError('fresh source')
D.mkdir();(D/'fixture').mkdir();r=dict(errors=[],parent=str(parent))
try:
 run_guest("if(@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue).Count){throw 'busy'};if(Test-Path -LiteralPath '"+G.as_posix()+"'){throw 'fresh'};New-Item -ItemType Directory -Path '"+G.as_posix()+"'|Out-Null;'ready'")
 for name in('fixture.bin','manifest.json','terminal_vm_wait_fixture.cs'):
  (D/'fixture'/name).write_bytes((parent/'fixture'/name).read_bytes())
 source=D/'fixture/terminal_vm_wait_fixture.cs';s=source.read_text()
 old='System.Diagnostics.Stopwatch start=System.Diagnostics.Stopwatch.StartNew();while(!File.Exists(path)){Need(start.Elapsed.TotalSeconds<150,"bounded owned gate");Thread.Sleep(10);}'
 new='int attempts=0;while(!File.Exists(path)){Need(++attempts<15000,"bounded owned gate iterations");Thread.Sleep(10);}'
 if s.count(old)!=1:raise ValueError('exact fixture gate source')
 source.write_text(s.replace(old,new))
 manifest=D/'fixture/manifest.json';m=json.loads(manifest.read_text());m['source_sha256']=identity(source)['sha256'];m['gate_change']='v3 own-fixture only: bounded 15000 gate polls; host supervisor/watchdog lifetime unchanged; target native wait instructions/timeouts unchanged';manifest.write_text(json.dumps(m,indent=2))
 if json.loads(manifest.read_text())['source_sha256']!=identity(source)['sha256']:raise ValueError('source identity before guest launch')
 for name in('fixture.bin','manifest.json','terminal_vm_wait_fixture.cs'):
  vmrun(['CopyFileFromHostToGuest',VMX,D/'fixture'/name,G/name],guest=True,timeout=10)
 compiler=PureWindowsPath('C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe')
 script="$env:TEMP='C:/ChaomofaWorker/temp';$env:TMP=$env:TEMP;$output=& '"+str(compiler)+"' /nologo /platform:x86 /r:System.Web.Extensions.dll '/out:"+str(G/'fixture.exe')+"' '"+str(G/'terminal_vm_wait_fixture.cs')+"' 2>&1;$rc=$LASTEXITCODE;[pscustomobject]@{exit_code=$rc;compiler_output=($output -join [Environment]::NewLine)}|ConvertTo-Json -Compress"
 r['compile']=json.loads(run_guest(script))
 if r['compile']['exit_code']!=0:raise ValueError('compiler refused source')
 vmrun(['CopyFileFromGuestToHost',VMX,G/'fixture.exe',D/'fixture/fixture.exe'],guest=True,timeout=10)
 s=(parent/'supervisor.py').read_text().replace('kd-thread-v2-20261110','kd-thread-v4-20261110')
 (D/'supervisor.py').write_text(s);vmrun(['CopyFileFromHostToGuest',VMX,D/'supervisor.py',G/'supervisor.py'],guest=True,timeout=10)
 r['files']=[identity(p)for p in(D/'fixture').iterdir()];r['supervisor']=identity(D/'supervisor.py')
except Exception as e:r['errors'].append(repr(e))
(D/'prepare.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(errors=r['errors'])))
if r['errors']:raise SystemExit(1)
