import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_vm_kd import SETTINGS,validate_kd_vmx
D=WORKER/'kd-thread-v1-20261110';G=PureWindowsPath('C:/ChaomofaWorker/kd-thread-v1-20261110');out=D/'prepare-continuation.json'
if out.exists():raise ValueError('fresh continuation')
r=dict(errors=[])
try:
 compiler=PureWindowsPath('C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe')
 script="$env:TEMP='C:/ChaomofaWorker/temp';$env:TMP=$env:TEMP;$output=& '"+str(compiler)+"' /nologo /platform:x86 /r:System.Web.Extensions.dll '/out:"+str(G/'fixture.exe')+"' '"+str(G/'terminal_vm_wait_fixture.cs')+"' 2>&1;$rc=$LASTEXITCODE;[pscustomobject]@{exit_code=$rc;compiler_output=($output -join [Environment]::NewLine)}|ConvertTo-Json -Compress"
 r['compile']=json.loads(run_script(script))
 if r['compile']['exit_code']!=0:raise ValueError('compiler refused source')
 vmrun(['CopyFileFromGuestToHost',VMX,G/'fixture.exe',D/'fixture/fixture.exe'],guest=True)
 r['fixture_exe']=identity(D/'fixture/fixture.exe')
 r['debug_settings']=run_script("& bcdedit /dbgsettings serial debugport:1 baudrate:115200;if($LASTEXITCODE){throw 'serial settings'};& bcdedit /debug '{current}' on;if($LASTEXITCODE){throw 'debug enable'};bcdedit /enum '{current}';bcdedit /dbgsettings")
 r['stop']=vmrun(['stop',VMX,'soft'],timeout=40)
 if str(VMX).lower()in vmrun(['list']).lower():raise ValueError('must be off')
 raw=VMX.read_bytes();validate_vmx(raw.decode());(D/'vmx-before.txt').write_bytes(raw)
 new=raw+bytes([13,10])+''.join(k+' = "'+v+'"'+chr(13)+chr(10)for k,v in SETTINGS.items()).encode()
 validate_kd_vmx(new.decode());VMX.write_bytes(new);r['vmx_kd']=identity(VMX)
 r['start']=vmrun(['start',VMX,'nogui'],timeout=20)
except Exception as exc:r['errors'].append(repr(exc))
out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
if r['errors']:raise SystemExit(1)
