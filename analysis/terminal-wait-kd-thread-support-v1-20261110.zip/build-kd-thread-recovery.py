from pathlib import Path
p=Path('.venv-audit/native-worker/recover-kd-cli-v2.py')
s=p.read_text().replace("d=WORKER/'kd-worker';log=d/'cli-recovery-v2.log';out=d/'cli-recovery-v2.json'", "d=WORKER/'kd-thread-v2-20261110';log=d/'recovery-v1.log';out=d/'recovery-v1.json'")
q=Path('.venv-audit/native-worker/recover-kd-thread-v2.py')
if q.exists():raise ValueError('fresh recovery code')
q.write_text(s)
