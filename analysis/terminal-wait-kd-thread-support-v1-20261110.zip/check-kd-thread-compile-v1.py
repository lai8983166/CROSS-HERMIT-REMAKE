import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_guest_admin import run_script
from devtools.isolated_windows_vm import WORKER
s=r"""$env:TEMP='C:ChaomofaWorkerTemp';$env:TMP=$env:TEMP;
$output=(& C:WindowsMicrosoft.NETFramework4.0.30319csc.exe /nologo /target:exe /platform:x86 /r:System.Web.Extensions.dll /out:C:ChaomofaWorkerkd-thread-v1-20261110ixture.exe C:ChaomofaWorkerkd-thread-v1-20261110	erminal_vm_wait_fixture.cs 2>&1 |Out-String);
[pscustomobject]@{exit_code=$LASTEXITCODE;output=$output}|ConvertTo-Json -Compress"""
r=json.loads(run_script(s));(WORKER/'kd-thread-v1-20261110/compile-path-check.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
