import hashlib,json,sys,zipfile
from pathlib import Path
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,identity
R=WORKER.parents[1];out=R/'analysis/terminal-wait-kd-thread-support-v1-20261110.zip'
if out.exists():raise ValueError('fresh capsule')
paths=set()
for v in (1,2,3,4):paths.update(p for p in(WORKER/('kd-thread-v%d-20261110'%v)).rglob('*')if p.is_file())
for pat in ('*kd-thread*.py','kd-thread-*.json','boot-kd-thread-*.json','inspect-kd-unrequested-stop-v1.py'):
 paths.update(p for p in WORKER.glob(pat)if p.is_file())
secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password'];needles=[secret.encode(),secret.encode('utf-16le')]
rows=[]
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(paths):
  b=p.read_bytes()
  if len(b)>2*1024*1024 or any(n in b for n in needles):raise ValueError('bounded private-free support')
  member=p.relative_to(WORKER).as_posix();z.writestr(member,b);rows.append(dict(path=str(p),member=member,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 z.writestr('manifest.json',json.dumps(dict(accepted=False,baseline='bbc626f3530690d32bdc39ee1c0b46ac179ed0e2',files=rows),indent=2))
with zipfile.ZipFile(out)as z:
 for row in rows:
  b=z.read(row['member'])
  if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('capsule exact bytes')
target=WORKER/'kd-thread-v1-20261110/state-no-module-query.json'
retire=dict(reason='new derived PowerShell ETS metadata expansion; exact original bytes recoverable from the verified small support capsule; no original game/save/checkpoint/history removed',file=identity(target),capsule=identity(out),member=target.relative_to(WORKER).as_posix())
(WORKER/'kd-thread-retire-expanded-json-v1.json').write_text(json.dumps(retire,indent=2))
print(json.dumps(dict(capsule=identity(out),members=len(rows),uncompressed_bytes=sum(r['bytes']for r in rows),retire=retire['file']),indent=2))
