import json,sys
from pathlib import PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_kd import run_guest
D=WORKER/'kd-thread-v2-20261110';G=PureWindowsPath('C:/ChaomofaWorker/kd-thread-v2-20261110');parent=WORKER/'kd-thread-v1-20261110'
if D.exists():raise ValueError('fresh source')
D.mkdir();(D/'fixture').mkdir();r=dict(errors=[],parent=str(parent))
try:
 run_guest("if(@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue).Count){throw 'busy'};if(Test-Path -LiteralPath '"+G.as_posix()+"'){throw 'fresh'};New-Item -ItemType Directory -Path '"+G.as_posix()+"'|Out-Null;'ready'")
 for name in('fixture.bin','fixture.exe','manifest.json','terminal_vm_wait_fixture.cs'):
  b=(parent/'fixture'/name).read_bytes();(D/'fixture'/name).write_bytes(b)
  vmrun(['CopyFileFromHostToGuest',VMX,D/'fixture'/name,G/name],guest=True,timeout=10)
 s=(parent/'supervisor.py').read_text().replace('kd-thread-v1-20261110','kd-thread-v2-20261110')
 (D/'supervisor.py').write_text(s);vmrun(['CopyFileFromHostToGuest',VMX,D/'supervisor.py',G/'supervisor.py'],guest=True,timeout=10)
 r['files']=[identity(p)for p in(D/'fixture').iterdir()];r['supervisor']=identity(D/'supervisor.py')
except Exception as e:r['errors'].append(repr(e))
(D/'prepare.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(errors=r['errors'])))
