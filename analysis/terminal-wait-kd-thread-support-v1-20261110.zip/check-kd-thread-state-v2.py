import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_vm_guest_admin import STATUS
from devtools.isolated_windows_vm import WORKER
r={}
try:
 r['status']=json.loads(run_guest(STATUS))
 r['fixture_state']=json.loads(run_guest("[pscustomobject]@{processes=@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,ProcessName);files=@(Get-ChildItem -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110' -File|Select-Object Name,Length);progress=if(Test-Path -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110/supervisor-progress.json'){Get-Content -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110/supervisor-progress.json' -Raw};result=if(Test-Path -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110/supervisor.json'){Get-Content -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110/supervisor.json' -Raw}}|ConvertTo-Json -Depth 4 -Compress"))
except Exception as e:r['error']=repr(e)
(WORKER/'kd-thread-v1-20261110/state-no-module-query.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
