from pathlib import Path
s=Path('devtools/terminal_kd_thread_probe.py').read_text().replace('kd-thread-v1-20261110','kd-thread-v2-20261110')
# Running code remains frozen. The launch result is separate from authenticated
# readiness; VIX may time out after it has already created the owned supervisor.
s=s.replace("    s=None;pool=cf.ThreadPoolExecutor(max_workers=2);pending=[];t=time.monotonic()", "    s=None;pool=cf.ThreadPoolExecutor(max_workers=3);pending=[];launch=None;t=time.monotonic()")
s=s.replace("        vmrun(['runProgramInGuest',VMX,'-noWait',PureWindowsPath('C:/ChaomofaWorker/Python/pythonw.exe'),'-B',G/'supervisor.py',G],guest=True,timeout=10)", "        launch=pool.submit(vmrun,['runProgramInGuest',VMX,'-noWait',PureWindowsPath('C:/ChaomofaWorker/Python/pythonw.exe'),'-B',G/'supervisor.py',G],guest=True,timeout=15)")
start=s.index('def collect(name,seconds):')
end=s.index('\n\ndef main():',start)
s=s[:start]+'''def collect(name,seconds):
    target=D/('guest-'+name);need(not target.exists(),'fresh guest transfer')
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        value=run_guest("if(Test-Path -LiteralPath '"+(G/name).as_posix()+"'){[IO.File]::ReadAllText('"+(G/name).as_posix()+"')}else{'NOT_READY'}").strip()
        if value!='NOT_READY':
            obj=json.loads(value);target.write_text(value);return obj
        time.sleep(.1)
    raise TimeoutError('bounded file '+name)
''' +s[end:]
s=s.replace("        pending.append(pool.submit(vmrun,['CopyFileFromHostToGuest',VMX,gate,G/'go'],guest=True,timeout=15))", "        pending.append(pool.submit(run_guest,\"[IO.File]::WriteAllText('\"+(G/'go').as_posix()+\"','continue');'go written'\"))")
s=s.replace("        pool.shutdown(wait=True)", "        pool.shutdown(wait=True)\n        if launch:\n            try:r['launch_command_result']=launch.result()\n            except Exception as exc:r['launch_command_error']=repr(exc)")
p=Path('devtools/terminal_kd_thread_probe_v2.py')
if p.exists():raise ValueError('fresh version')
p.write_text(s)
