import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_kd import run_guest
out=WORKER/'kd-thread-batch-final-v1.json'
if out.exists():raise ValueError('fresh collection')
script="$rows=@();foreach($v in @(1,2,3,4)){$d='C:/ChaomofaWorker/kd-thread-v'+$v+'-20261110';foreach($n in @('supervisor.json','supervisor-progress.json','result.json','result.json.watchdog.json','ready.json','supervisor-ready.json','returned-0.json','returned-1.json','returned-2.json','returned-3.json')){$p=$d+'/'+$n;if(Test-Path -LiteralPath $p){$rows+=[pscustomobject]@{version=$v;name=$n;value=[IO.File]::ReadAllText($p)}}}};[pscustomobject]@{active=@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,ProcessName);files=$rows}|ConvertTo-Json -Depth 5 -Compress"
r=json.loads(run_guest(script));out.write_text(json.dumps(r,indent=2))
print(json.dumps(dict(active=r['active'],summary=[dict(version=a['version'],name=a['name'],fields={k:v for k,v in json.loads(a['value']).items()if k in('error','errors','returns','handles_closed','buffers_released','forced_own_fixture_exit','forced_self_exit','exit_code','elapsed_seconds')})for a in r['files'] if a['name'] in('supervisor.json','result.json','result.json.watchdog.json')]),indent=2))
