import json,sys,time
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_kd import validate_kd_vmx
out=WORKER/'kd-thread-power-recovery-v1.json'
if out.exists():raise ValueError('fresh recovery')
validate_kd_vmx(VMX.read_text());r=dict(accepted=False,errors=[],reason='v4 own fixture only; no original game; both guest control transports unavailable; collection process bounded and stopped',original_game_starts=0)
log=WORKER/'kd-thread-v4-20261110/vmware-before-recovery.log';log.write_bytes((WORKER/'vmware.log').read_bytes());r['log']=identity(log)
try:r['soft_stop']=vmrun(['stop',VMX,'soft'],timeout=20)
except Exception as e:r['soft_stop_error']=repr(e)
if str(VMX).lower()in vmrun(['list']).lower():r['hard_stop']=vmrun(['stop',VMX,'hard'],timeout=15)
r['off']=vmrun(['list'])
if str(VMX).lower()in r['off'].lower():raise ValueError('failed owned power off')
r['start']=vmrun(['start',VMX,'nogui'],timeout=20)
r['started_monotonic']=time.monotonic();out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
