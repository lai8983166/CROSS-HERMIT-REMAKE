import hashlib,json,sys
from pathlib import Path,PureWindowsPath
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity,validate_vmx
from devtools.isolated_vm_guest_admin import run_script,STATUS
from devtools.isolated_vm_kd import SETTINGS,validate_kd_vmx
from devtools.terminal_vm_wait_fixture import prepare
D=WORKER/'kd-thread-v1-20261110';G=PureWindowsPath('C:/ChaomofaWorker/kd-thread-v1-20261110');q=G.as_posix()
if D.exists():raise ValueError('fresh bounded experiment')
D.mkdir();r=dict(accepted=False,original_game_starts=0,host_input_actions=0,errors=[])
try:
 validate_vmx(VMX.read_text(encoding='utf8'));r['guest_before']=json.loads(run_script(STATUS))
 r['prepare']=run_script("if(@(Get-Process fixture,pythonw,'CROSS HERMIT' -ErrorAction SilentlyContinue).Count){throw 'busy'};if(Test-Path -LiteralPath '"+q+"'){throw 'fresh'};New-Item -ItemType Directory -Path '"+q+"'|Out-Null;$s=(& bcdedit /enum '{current}'|Out-String);if($s -match '(?im)^debug\\s+Yes'){throw 'preexisting debug boot'};& bcdedit /export '"+q+"/bcd-before';if($LASTEXITCODE){throw 'backup failed'};'prepared'")
 vmrun(['CopyFileFromGuestToHost',VMX,G/'bcd-before',D/'bcd-before'],guest=True)
 r['backup']=identity(D/'bcd-before')
 r['before_settings']=run_script("bcdedit /enum '{current}';bcdedit /dbgsettings")
 fixture=D/'fixture';meta=prepare(fixture)
 source=(fixture/'terminal_vm_wait_fixture.cs').read_text()
 old='DateTime start=DateTime.UtcNow;while(!File.Exists(path)){Need((DateTime.UtcNow-start).TotalSeconds<150'
 new='System.Diagnostics.Stopwatch start=System.Diagnostics.Stopwatch.StartNew();while(!File.Exists(path)){Need(start.Elapsed.TotalSeconds<150'
 if old not in source:raise ValueError('exact own gate deadline replacement')
 source=source.replace(old,new);(fixture/'terminal_vm_wait_fixture.cs').write_text(source)
 meta['source_sha256']=identity(fixture/'terminal_vm_wait_fixture.cs')['sha256']
 meta['gate_change']='Only own test gate deadline uses Stopwatch, not adjustable UTC; original wait machine code unchanged.'
 (fixture/'manifest.json').write_text(json.dumps(meta,indent=2))
 supervisor=Path('F:/project/chaomofa/devtools/terminal_kd_fixture_supervisor.py').read_text().replace('kd-cli-wait-v3-20261110','kd-thread-v1-20261110').replace('p.wait(timeout=60)','p.wait(timeout=140)')
 (D/'supervisor.py').write_text(supervisor)
 for name in('fixture.bin','manifest.json','terminal_vm_wait_fixture.cs'):
  vmrun(['CopyFileFromHostToGuest',VMX,fixture/name,G/name],guest=True)
 vmrun(['CopyFileFromHostToGuest',VMX,D/'supervisor.py',G/'supervisor.py'],guest=True)
 compile_script="$env:TEMP='C:/ChaomofaWorker/Temp';$env:TMP=$env:TEMP;New-Item -ItemType Directory -Force -Path $env:TEMP|Out-Null;& C:/Windows/Microsoft.NET/Framework/v4.0.30319/csc.exe /nologo /target:exe /platform:x86 /r:System.Web.Extensions.dll /out:"+q+"/fixture.exe "+q+"/terminal_vm_wait_fixture.cs;if($LASTEXITCODE){throw 'compile failed'};'compiled'"
 r['compile']=run_script(compile_script)
 vmrun(['CopyFileFromGuestToHost',VMX,G/'fixture.exe',fixture/'fixture.exe'],guest=True)
 r['fixture_files']=[identity(p)for p in fixture.iterdir()]
 r['debug_settings']=run_script("& bcdedit /dbgsettings serial debugport:1 baudrate:115200;if($LASTEXITCODE){throw 'serial settings'};& bcdedit /debug '{current}' on;if($LASTEXITCODE){throw 'enable guest debug'};bcdedit /enum '{current}';bcdedit /dbgsettings")
 r['stop']=vmrun(['stop',VMX,'soft'],timeout=40)
 if str(VMX).lower()in vmrun(['list']).lower():raise ValueError('off required')
 raw=VMX.read_bytes();validate_vmx(raw.decode());(D/'vmx-before.txt').write_bytes(raw)
 new=raw+b'\r\n'+''.join(k+' = "'+v+'"\r\n'for k,v in SETTINGS.items()).encode()
 validate_kd_vmx(new.decode());VMX.write_bytes(new);r['vmx_kd']=identity(VMX)
 r['start']=vmrun(['start',VMX,'nogui'],timeout=20)
except Exception as e:r['errors'].append(repr(e))
(D/'prepare.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k not in ('before_settings','debug_settings','fixture_files')},indent=2))
if r['errors']:raise SystemExit(1)
