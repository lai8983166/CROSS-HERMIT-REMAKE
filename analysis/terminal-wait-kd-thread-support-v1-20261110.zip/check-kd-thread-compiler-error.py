import sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_guest_admin import run_script
print(run_script(r"""$ErrorActionPreference='Continue';$Error.Clear();$p='C:WindowsMicrosoft.NETFramework4.0.30319csc.exe';$a=Test-Path -LiteralPath $p;$output=& $p /nologo /platform:x86 /r:System.Web.Extensions.dll '/out:C:ChaomofaWorkerkd-thread-v1-20261110ixture.exe' 'C:ChaomofaWorkerkd-thread-v1-20261110	erminal_vm_wait_fixture.cs' 2>&1;$rc=$LASTEXITCODE;[pscustomobject]@{exists=$a;exit_code=$rc;output=($output -join "`n");errors=@($Error|ForEach-Object {$_.Exception.Message})}|ConvertTo-Json -Compress;exit 0"""))
