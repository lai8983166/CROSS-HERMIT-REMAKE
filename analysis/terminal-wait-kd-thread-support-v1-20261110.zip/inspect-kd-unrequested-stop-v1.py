import concurrent.futures as cf,json,sys,time
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,identity
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_vm_guest_admin import STATUS
from devtools.terminal_kd_session_v2 import Session
from devtools.terminal_kd_session import at_prompt
D=WORKER/'kd-thread-v1-20261110';out=D/'passive-stop.json'
if out.exists():raise ValueError('fresh passive inspection')
r=dict(errors=[],break_on_connect=False);s=None
try:
 s=Session(D/'passive-stop.log',break_on_connect=False);s.wait_prompt(10)
 r['first_event']=s.execute('.lastevent');r['registers']=s.execute('r');r['module']=s.execute('lm m nt')
 s.execute('bc *');s.go()
 end=time.monotonic()+8
 while time.monotonic()<end:
  stop=s.poll_stop()
  if stop is not None:r['unexpected_stop']=stop;raise ValueError('unexpected non-debugger stop')
  time.sleep(.05)
 r['guest']=json.loads(run_guest(STATUS));r['test_processes']=run_guest("@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,Path)|ConvertTo-Json -Compress")
 s.close_after_resume();r['resumed_and_client_closed']=True
except Exception as e:r['errors'].append(repr(e))
finally:
 if s:
  r['log']=identity(s.log);r['commands']=s.rows;r['pending_breaks']=s.pending_breaks
  if s.process.poll()is None:s.process.terminate();s.process.wait(timeout=5);s.file.close();r['emergency_client_close']=True
 out.write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
