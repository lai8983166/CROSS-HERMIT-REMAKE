import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_kd import run_guest
r={}
for version in (1,2):
 d=WORKER/('kd-thread-v%d-20261110'%version)
 names=['supervisor.json','supervisor-progress.json','result.json','returned-0.json','returned-1.json','returned-2.json','returned-3.json']
 for n in names:
  p=d/('final-guest-'+n)
  if p.exists():raise ValueError('fresh collection')
  s=run_guest("$p='C:/ChaomofaWorker/"+d.name+'/'+n+"';if(Test-Path -LiteralPath $p){[IO.File]::ReadAllText($p)}else{'null'}")
  v=json.loads(s);p.write_text(json.dumps(v,indent=2));r[str(version)+':'+n]=v
print(json.dumps({k:({a:b for a,b in v.items()if a in ('errors','error','returns','cleanup_errors','handles_closed','buffers_released','forced_own_fixture_exit','exit_code','phases','elapsed_seconds')} if isinstance(v,dict) else v)for k,v in r.items()},indent=2))
print(run_guest("@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,ProcessName)|ConvertTo-Json -Compress"))
