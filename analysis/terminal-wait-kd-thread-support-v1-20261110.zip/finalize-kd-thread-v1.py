import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,validate_vmx,identity
from devtools.isolated_vm_guest_admin import run_script,STATUS
out=WORKER/'kd-thread-final-worker-v1.json';r=dict(accepted=False,errors=[])
if out.exists():raise ValueError('fresh final worker')
try:
 validate_vmx(VMX.read_text(encoding='utf8'))
 r['guest_after_cold_boot']=json.loads(run_script(STATUS))
 r['boot_settings']=run_script("bcdedit /enum '{current}';bcdedit /dbgsettings")
 if 'debug                   Yes' in r['boot_settings']or 'debugtype               Local' not in r['boot_settings']:raise ValueError('original debug boot not restored')
 r['active_test_processes']=run_script("@(Get-Process fixture,pythonw,'CROSS HERMIT' -ErrorAction SilentlyContinue|Select-Object Id,ProcessName)|ConvertTo-Json -Compress")
 if r['active_test_processes'].strip():raise ValueError('test processes remain')
 script="$rows=@();foreach($v in @(1,2,3,4)){$d='C:/ChaomofaWorker/kd-thread-v'+$v+'-20261110';$rows+=@(Get-ChildItem -LiteralPath $d -File|ForEach-Object {[pscustomobject]@{path=$_.FullName;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}})};$rows|ConvertTo-Json -Depth 4 -Compress"
 r['guest_evidence_files']=json.loads(run_script(script))
 r['soft_stop']=vmrun(['stop',VMX,'soft'],timeout=40)
 r['running_after']=vmrun(['list']);r['snapshots']=vmrun(['listSnapshots',VMX]);r['vmem_files']=[str(x)for x in WORKER.glob('*.vmem')]
 if str(VMX).lower()in r['running_after'].lower()or r['snapshots']!='Total snapshots: 0'or r['vmem_files']:raise ValueError('final isolated cleanup')
 validate_vmx(VMX.read_text(encoding='utf8'));r['vmx_after']=identity(VMX)
 r['vmdk_bytes']=sum(p.stat().st_size for p in WORKER.glob('worker*.vmdk'))
except Exception as exc:r['errors'].append(repr(exc))
out.write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k not in ('guest_evidence_files','boot_settings')},indent=2))
if r['errors']:raise SystemExit(1)
