import json,sys
sys.path.insert(0,'F:/project/chaomofa')
from devtools.isolated_vm_kd import run_guest
from devtools.isolated_windows_vm import WORKER,VMX,vmrun
r={}
r['guest']=json.loads(run_guest("[pscustomobject]@{processes=@(Get-Process fixture,pythonw -ErrorAction SilentlyContinue|Select-Object Id,Path);tools=(Get-Service VMTools|Select-Object Name,Status);files=@(Get-ChildItem -LiteralPath 'C:/ChaomofaWorker/kd-thread-v1-20261110' -File|Select-Object Name,Length)}|ConvertTo-Json -Depth 5 -Compress"))
try:r['tools_processes']=vmrun(['listProcessesInGuest',VMX],guest=True,timeout=10)
except Exception as e:r['tools_error']=repr(e)
(WORKER/'kd-thread-v1-20261110/launch-inspection.json').write_text(json.dumps(r,indent=2));print(json.dumps(r['guest'],indent=2));print(r.get('tools_error','Tools processes read'))
