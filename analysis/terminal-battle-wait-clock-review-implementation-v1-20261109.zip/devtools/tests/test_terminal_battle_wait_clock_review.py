import copy
import struct
import unittest
from devtools import terminal_battle_wait_clock_review as c


class RawClockComparisonTests(unittest.TestCase):
    def row(self,ns,ticks):
        a=bytearray(80);b=bytearray(80)
        struct.pack_into('<q',a,16,ns);struct.pack_into('<q',b,16,ticks)
        return dict(index=1,ns=ns,record_header_hex=a.hex(),payload_hex='01020304'),dict(index=1,qpc_ticks=ticks,record_header_hex=b.hex(),payload_hex='01020304')

    def test_only_timestamp_bytes_may_differ(self):
        left,right=self.row(100000,100);c.bind_raw([left],[right])
        for key,value in [('payload_hex','01020305'),('index',2),('qpc_ticks',101)]:
            bad=dict(right,**{key:value})
            with self.assertRaises(ValueError):c.bind_raw([left],[bad])
        h=bytearray.fromhex(right['record_header_hex']);h[10]=1
        with self.assertRaises(ValueError):c.bind_raw([left],[dict(right,record_header_hex=h.hex())])

    def test_raw_sequence_cannot_be_truncated_or_reordered(self):
        a,b=self.row(100000,100);x,y=self.row(100001,99)
        with self.assertRaises(ValueError):c.bind_raw([a,x],[b])
        with self.assertRaises(ValueError):c.bind_raw([a,x],[b,y])

    def rows(self):
        return [dict(qpc_ticks=10,opcode=51),dict(qpc_ticks=20,opcode=36,data=dict(OldThreadId=7,NewThreadId=8)),
                dict(qpc_ticks=80,opcode=36,data=dict(OldThreadId=8,NewThreadId=7)),dict(qpc_ticks=90,opcode=52)]

    def test_complete_interval_and_cross_cpu_one_tick_guard(self):
        rows=self.rows()
        self.assertTrue(c.interval_check(rows,(0,3),7,22,78,'qpc_ticks',1))
        for lo,hi in [(20,70),(21,70),(22,79),(22,80),(15,85),(22,91)]:
            self.assertFalse(c.interval_check(rows,(0,3),7,lo,hi,'qpc_ticks',1))

    def test_middle_switch_cannot_be_bridged(self):
        rows=self.rows();rows[2:2]=[dict(qpc_ticks=40,opcode=36,data=dict(OldThreadId=8,NewThreadId=7)),dict(qpc_ticks=50,opcode=36,data=dict(OldThreadId=7,NewThreadId=8))]
        self.assertFalse(c.interval_check(rows,(0,5),7,25,75,'qpc_ticks',1))


if __name__=='__main__':unittest.main()
