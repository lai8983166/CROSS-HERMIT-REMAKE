import json,sys
from pathlib import Path,PureWindowsPath
ROOT=Path('F:/project/chaomofa');sys.path.insert(0,str(ROOT))
from devtools.isolated_windows_vm import WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script
label=sys.argv[1]
if not label.replace('-','').isalnum():raise ValueError('simple label')
stem='terminal-wait-etw-decode-'+label
out=WORKER/(stem+'.json');receipt=WORKER/(stem+'.run.json')
if out.exists()or receipt.exists():raise ValueError('immutable new report')
if run_script("$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*'});if($p.Count){throw 'guest busy'};'idle'").strip()!='idle':raise ValueError('guest not idle')
guest=PureWindowsPath('C:/ChaomofaWorker/project');source=ROOT/'devtools/terminal_wait_etw_probe.py';before=identity(source)
source_name='terminal-wait-etw-capability-v1-20261109.json'
source_id=identity(WORKER/source_name)
etl_id=identity(WORKER/'terminal-wait-etw-capability-v1-20261109/trace.etl')
args=['devtools.terminal_wait_etw_probe','--decode-source',str(guest/'analysis'/source_name),'--source-sha',source_id['sha256'],
      '--etl',str(guest/'analysis'/'terminal-wait-etw-capability-v1-20261109'/'trace.etl'),'--etl-sha',etl_id['sha256'],'--out',str(guest/'analysis'/out.name)]
log=PureWindowsPath('C:/ChaomofaWorker')/(stem+'.log');driver=WORKER/(stem+'-driver.py');remote_driver=PureWindowsPath('C:/ChaomofaWorker')/driver.name
text=('import os,sys,runpy,traceback\nos.chdir('+repr(str(guest))+');sys.path.insert(0,'+repr(str(guest))+')\nsys.argv='+repr(args)+'\nwith open('+repr(str(log))+',"x",encoding="utf8")as log:\n sys.stdout=sys.stderr=log\n try:runpy.run_module("devtools.terminal_wait_etw_probe",run_name="__main__")\n except BaseException:traceback.print_exc();raise\n')
with driver.open('x',encoding='utf8')as f:f.write(text)
r=dict(implementation=before,driver=identity(driver),source=source_id,etl=etl_id,accepted=False,new_capture=False,host_input_actions=0,errors=[])
try:
 vmrun(['CopyFileFromHostToGuest',VMX,source,guest/'devtools'/source.name],guest=True)
 vmrun(['CopyFileFromHostToGuest',VMX,driver,remote_driver],guest=True)
 vmrun(['runProgramInGuest',VMX,'-activeWindow','-interactive',PureWindowsPath('C:/ChaomofaWorker/Python/pythonw.exe'),'-B',remote_driver],guest=True,timeout=65)
except Exception as e:r['errors'].append(str(e))
finally:
 for remote,local in ((guest/'analysis'/out.name,out),(log,WORKER/log.name)):
  try:vmrun(['CopyFileFromGuestToHost',VMX,remote,local],guest=True)
  except Exception as e:r['errors'].append(str(e))
 r['implementation_unchanged']=before==identity(source)
 if out.exists():
  d=json.loads(out.read_text());r['report']=identity(out);r['result']={k:d.get(k)for k in ('status','errors','elapsed_seconds','total_records','retained_helper_records','process_trace_status','close_trace_status','analysis')}
 with receipt.open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
print(json.dumps(r.get('result',r),indent=2))
