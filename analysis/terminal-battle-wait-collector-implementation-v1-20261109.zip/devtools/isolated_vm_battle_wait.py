"""Single-scheduler host transport for bounded original battle wait evidence."""
import argparse
import gzip
import json
from pathlib import Path,PureWindowsPath
import re
from devtools.isolated_windows_vm import ROOT,WORKER,VMX,vmrun,identity
from devtools.isolated_vm_guest_admin import run_script


def capture(label,phase='startup_preflight'):
    if not re.fullmatch('[a-z0-9-]+',label):raise ValueError('simple fresh label')
    if phase not in ('startup_preflight','battle_retreat'):raise ValueError('declared phase only')
    stem='terminal-battle-wait-window-'+label
    out=WORKER/(stem+'.json.gz');receipt=WORKER/(stem+'.run.json')
    driver=WORKER/(stem+'-driver.py');log=WORKER/(stem+'.log')
    if any(p.exists()for p in (out,receipt,driver,log,WORKER/stem)):raise ValueError('fresh immutable run required')
    idle="$p=@(Get-CimInstance Win32_Process|Where-Object {$_.Name -eq 'CROSS HERMIT.EXE' -or $_.Name -like 'python*'});if($p.Count){throw 'guest busy'};'idle'"
    if run_script(idle).strip()!='idle':raise ValueError('guest busy before deployment')
    guest=PureWindowsPath('C:/ChaomofaWorker/project');remote=guest/'analysis'/out.name
    remote_driver=PureWindowsPath('C:/ChaomofaWorker')/driver.name;remote_log=remote_driver.parent/log.name
    modules=[ROOT/'devtools'/name for name in ('terminal_battle_wait_window.py','terminal_original_wait_etw.py','terminal_wait_etw_probe.py')]
    before=[identity(p)for p in modules]+[identity(Path(__file__))]
    script=('import os,sys,runpy,traceback\nos.chdir('+repr(str(guest))+');sys.path.insert(0,'+repr(str(guest))+')\n'
        'sys.argv='+repr(['devtools.terminal_battle_wait_window','--out',str(remote),'--phase',phase])+'\n'
        'with open('+repr(str(remote_log))+',"x",encoding="utf8")as f:\n'
        ' sys.stdout=sys.stderr=f\n'
        ' try:runpy.run_module("devtools.terminal_battle_wait_window",run_name="__main__")\n'
        ' except BaseException:traceback.print_exc();raise\n')
    with driver.open('x',encoding='utf8')as f:f.write(script)
    result=dict(phase=phase,accepted=False,new_native_lifetime=True,host_input_actions=0,
        sources=before,driver=identity(driver),errors=[])
    try:
        for p in modules:vmrun(['CopyFileFromHostToGuest',VMX,p,guest/'devtools'/p.name],guest=True)
        vmrun(['CopyFileFromHostToGuest',VMX,driver,remote_driver],guest=True)
        vmrun(['runProgramInGuest',VMX,'-activeWindow','-interactive',
            PureWindowsPath('C:/ChaomofaWorker/Python/pythonw.exe'),'-B',remote_driver],
            guest=True,timeout=240 if phase=='startup_preflight'else 1800)
    except Exception as exc:result['errors'].append(str(exc))
    finally:
        for src,dst in ((remote,out),(remote_log,log)):
            try:vmrun(['CopyFileFromGuestToHost',VMX,src,dst],guest=True)
            except Exception as exc:result['errors'].append('retrieve: '+str(exc))
        try:
            if not out.exists()or out.stat().st_size>2*1024*1024:raise ValueError('bounded source required')
            with gzip.open(out,'rb')as f:raw=f.read(8*1024*1024+1)
            if len(raw)>8*1024*1024:raise ValueError('expanded source limit')
            source=json.loads(raw);result['source_report']=identity(out)
            result['observed']=dict(error=source.get('error'),lifecycle_error=source.get('lifecycle',{}).get('error'),
                snapshots=len(source.get('window_snapshots',[])),subject=source.get('subject'),stop_reason=source.get('stop_reason'))
            if source.get('ETL'):
                row=source['ETL'];expected=guest/'analysis'/stem/'trace.etl'
                if PureWindowsPath(row['path'])!=expected or not 0<row['bytes']<64*1024*1024:raise ValueError('exact bounded window ETL')
                folder=WORKER/stem;folder.mkdir();local=folder/'trace.etl'
                vmrun(['CopyFileFromGuestToHost',VMX,expected,local],guest=True)
                got=identity(local)
                if any(got[k]!=row[k]for k in ('bytes','sha256')):raise ValueError('ETL transfer identity')
                result['ETL']=got
        except Exception as exc:result['errors'].append('source validation: '+str(exc))
        result['sources_unchanged']=before==[identity(p)for p in modules]+[identity(Path(__file__))]
        with receipt.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--label',required=True)
    p.add_argument('--phase',choices=['startup_preflight','battle_retreat'],default='startup_preflight')
    a=p.parse_args();r=capture(a.label,a.phase)
    print(json.dumps({k:v for k,v in r.items()if k not in ('sources','driver')},indent=2))
    observed=r.get('observed',{})
    raise SystemExit(1 if r['errors']or not r['sources_unchanged']or not observed or observed.get('error')or observed.get('lifecycle_error')else 0)
