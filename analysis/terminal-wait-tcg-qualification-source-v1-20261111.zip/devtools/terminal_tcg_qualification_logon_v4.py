"""Bounded one-logon setup/status/clear only in authenticated dedicated QEMU guest.
Private credential is read in the disposable host process, never saved in command files/logs.
"""
import json,re,sys,base64
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths

def worker():
 req=json.loads(sys.stdin.readline())
 try:
  case=WORKER/req['case'];action=req['action']
  if case.name not in ('tcg-wait-native-v10','tcg-wait-native-v11') or action not in ('arm','status','clear'):raise ValueError('fixed case/action')
  if not(case/'vm-ready.json').exists()or(case/'vm-stop').exists()or(case/'report.json').exists():raise ValueError('active owned VM')
  import winrm
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  s=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER\Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=10,read_timeout_sec=20)
  original=s.protocol.open_shell
  s.protocol.open_shell=lambda *args,**kwargs:original(*args,**dict(kwargs,noprofile=True))
  raw=s.run_cmd('wmic.exe',['csproduct','get','UUID','/value'])
  if raw.status_code or '626d1a20-6383-4cd3-85d5-6c9831d6f941' not in raw.std_out.decode(errors='replace').lower():raise ValueError('actual QEMU UUID')
  script=r"""$ErrorActionPreference='Stop';if($env:COMPUTERNAME -ne 'CHAOMOFA-WORKER'){throw 'guest identity'};
$k='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon';$r=Get-ItemProperty -LiteralPath $k;$desktop=@(Get-Process explorer -ErrorAction SilentlyContinue);
if(@(Get-Process 'CROSS HERMIT','probe' -ErrorAction SilentlyContinue).Count){throw 'guest busy'};
"""
  if action=='arm':
   if len(secret)<16:raise ValueError('credential length')
   literal="'"+secret.replace("'","''")+"'"
   script+="if($desktop.Count -or $r.AutoAdminLogon -ne '0' -or $r.DefaultPassword){throw 'only expired idle logon'};"
   script+="New-ItemProperty -LiteralPath $k -Name DefaultUserName -Value 'Administrator' -PropertyType String -Force|Out-Null;New-ItemProperty -LiteralPath $k -Name DefaultDomainName -Value 'CHAOMOFA-WORKER' -PropertyType String -Force|Out-Null;"
   script+="New-ItemProperty -LiteralPath $k -Name DefaultPassword -Value "+literal+" -PropertyType String -Force|Out-Null;New-ItemProperty -LiteralPath $k -Name AutoLogonCount -Value 1 -PropertyType DWord -Force|Out-Null;New-ItemProperty -LiteralPath $k -Name AutoAdminLogon -Value '1' -PropertyType String -Force|Out-Null;"
  elif action=='clear':
   script+="if($desktop.Count -ne 1 -or $desktop[0].SessionId -eq 0){throw 'actual desktop required'};New-ItemProperty -LiteralPath $k -Name AutoAdminLogon -Value '0' -PropertyType String -Force|Out-Null;Remove-ItemProperty -LiteralPath $k -Name DefaultPassword,AutoLogonCount -ErrorAction SilentlyContinue;"
  script+="$r=Get-ItemProperty -LiteralPath $k;[pscustomobject]@{uuid='626d1a20-6383-4cd3-85d5-6c9831d6f941';enabled=$r.AutoAdminLogon;count=$r.AutoLogonCount;password_configured=[bool]$r.DefaultPassword;desktop_sessions=@($desktop|ForEach-Object SessionId)}|ConvertTo-Json -Compress"
  value=s.run_ps(script)
  if value.status_code:raise ValueError('guest command rejected')
  print(json.dumps(dict(ok=True,value=json.loads(value.std_out.decode('utf-8-sig')),remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,remote_completion='unknown')))
if __name__=='__main__':
 boot='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_logon_v4 import worker;worker()'
 print(json.dumps(_supervise(dict(case=sys.argv[1],action=sys.argv[2]),60,boot)))
