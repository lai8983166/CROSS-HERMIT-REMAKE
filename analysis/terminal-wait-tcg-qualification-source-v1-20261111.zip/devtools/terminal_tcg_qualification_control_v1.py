"""Fixed task start, report read, task status and removal; no host input API."""
import json,sys
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths
CASE='tcg-wait-native-v11';TASK='Chaomofa-TCG-qualification-v11'
def worker():
 req=json.loads(sys.stdin.readline())
 try:
  case=WORKER/CASE;auth=json.loads((case/'boot-auth.json').read_bytes());challenge=json.loads((case/'challenge.json').read_bytes())
  v=auth['response']['value']
  if not auth['response']['ok']or v.get('task')!=TASK or v.get('nonce')!=challenge['nonce']or v.get('executable_sha256')!=challenge['guest_executable']['sha256']or v.get('uuid','').lower()!='626d1a20-6383-4cd3-85d5-6c9831d6f941'or(case/'vm-stop').exists()or(case/'report.json').exists():raise ValueError('current authenticated task')
  import winrm
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  s=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER'+chr(92)+'Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=10,read_timeout_sec=20)
  action=req['action']
  if action=='start':
   with(case/'start-issued.json').open('x')as f:json.dump(dict(task=TASK,nonce=challenge['nonce']),f)
   r=s.run_cmd('schtasks.exe',['/run','/tn',TASK])
  elif action=='read':r=s.run_cmd('cmd.exe',['/d','/c','type','C:/ChaomofaWorker/'+CASE+'/probe.json'])
  elif action=='info':
   script="DOLLARs=New-Object -ComObject Schedule.Service;DOLLARs.Connect();DOLLARt=DOLLARs.GetFolder('ROOTSEP').GetTask('TASKNAME');[pscustomobject]@{state=[int]DOLLARt.State;last_result=DOLLARt.LastTaskResult;last_run=DOLLARt.LastRunTime.ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress"
   r=s.run_ps(script.replace('DOLLAR',chr(36)).replace('ROOTSEP',chr(92)).replace('TASKNAME',TASK))
  elif action=='remove':
   info=json.loads((case/'task-info-response.json').read_bytes())
   data=json.loads(info['response']['stdout'])
   if info['remote_completion']!='observed'or data['state']==4 or data['last_result']not in(0,1):raise ValueError('completed task required')
   r=s.run_cmd('schtasks.exe',['/delete','/tn',TASK,'/f'])
  else:raise ValueError('fixed action')
  print(json.dumps(dict(ok=True,status_code=r.status_code,stdout=r.std_out.decode('utf-8',errors='replace'),stderr=r.std_err.decode('utf-8',errors='replace'),remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,remote_completion='unknown')))
if __name__=='__main__':
 boot='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_control_v1 import worker;worker()'
 print(json.dumps(_supervise(dict(action=sys.argv[1]),35,boot)))
