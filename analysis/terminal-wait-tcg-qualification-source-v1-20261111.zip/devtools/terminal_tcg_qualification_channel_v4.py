"""Single owned WINRS_NOPROFILE shell, separately bounded requests and durable stages."""
import gzip,base64,hashlib,json,sys,time
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths
CASE='tcg-wait-native-v12'
def worker():
 req=json.loads(sys.stdin.readline());case=WORKER/CASE;secret=''
 try:
  if not(case/'vm-ready.json').exists()or(case/'report.json').exists()or(case/'vm-stop').exists():raise ValueError('inactive case')
  action=req['action'];name=req.get('name','')
  if action not in ('open','run','receive','cleanup','close'):raise ValueError('action')
  if action not in ('open','close')and not __import__('re').fullmatch('direct-[a-z0-9-]{1,32}',name):raise ValueError('fixed command')
  import winrm
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  p=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER'+chr(92)+'Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=40,read_timeout_sec=50).protocol
  if action=='open':
   from devtools.terminal_tcg_control_verify import completed
   closes=list(case.glob('channel-close--*.json'))
   if len(closes)!=1 or not completed(json.loads(closes[0].read_bytes())):raise ValueError('prior owned shell closed')
   with(case/'direct-open-issued.json').open('x')as f:json.dump(dict(case=CASE,time=time.time()),f)
   shell=p.open_shell(noprofile=True)
   with(case/'direct-shell-owned.json').open('x')as f:json.dump(dict(shell=shell,case=CASE,vm_ready_sha256=hashlib.sha256((case/'vm-ready.json').read_bytes()).hexdigest()),f)
   result=dict(shell=shell)
  else:
   owner=json.loads((case/'direct-shell-owned.json').read_bytes());shell=owner['shell']
   if owner['vm_ready_sha256']!=hashlib.sha256((case/'vm-ready.json').read_bytes()).hexdigest():raise ValueError('boot ownership')
   if action=='close':p.close_shell(shell);result=dict(closed=True)
   elif action=='run':
    raw=(case/(name+'.ps1')).read_bytes()
    with(case/(name+'-issued.json')).open('x')as f:json.dump(dict(script_sha256=hashlib.sha256(raw).hexdigest()),f)
    payload=base64.b64encode(gzip.compress(raw,mtime=0)).decode()
    script="DOLLARm=New-Object IO.MemoryStream(,[Convert]::FromBase64String('"+payload+"'));DOLLARg=New-Object IO.Compression.GZipStream(DOLLARm,[IO.Compression.CompressionMode]::Decompress);DOLLARr=New-Object IO.StreamReader(DOLLARg);try{Invoke-Expression DOLLARr.ReadToEnd()}finally{DOLLARr.Dispose();DOLLARg.Dispose();DOLLARm.Dispose()}"
    script=script.replace('DOLLAR',chr(36))
    if len(script)>28000:raise ValueError('bounded direct compressed command')
    command=p.run_command(shell,'powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-Command',chr(34)+script+chr(34)],skip_cmd_shell=True,console_mode_stdin=False)
    with(case/(name+'-owned.json')).open('x')as f:json.dump(dict(command=command,shell=shell),f)
    result=dict(command=command)
   else:
    owned=json.loads((case/(name+'-owned.json')).read_bytes());command=owned['command']
    if owned['shell']!=shell:raise ValueError('command ownership')
    if action=='send':
     raw=(case/(name+'.ps1')).read_bytes()
     if hashlib.sha256(raw).hexdigest()!=json.loads((case/(name+'-issued.json')).read_bytes())['script_sha256']:raise ValueError('script mutation')
     with(case/(name+'-send-issued.json')).open('x')as f:json.dump(dict(command=command),f)
     p.send_command_input(shell,command,base64.b64encode(raw),end=True);result=dict(sent=True)
    elif action=='receive':
     out,err,code,done=p.get_command_output_raw(shell,command)
     result=dict(stdout_base64=base64.b64encode(out).decode(),stderr_base64=base64.b64encode(err).decode(),stdout_bytes=len(out),stderr_bytes=len(err),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),status_code=code,done=done)
     with(case/(name+'-chunk-'+str(time.time_ns())+'.json')).open('x')as f:json.dump(result,f)
    else:p.cleanup_command(shell,command);result=dict(cleaned=True)
  print(json.dumps(dict(ok=True,value=result,remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,diagnostic=str(e).replace(secret,'[redacted]')[:1000]if secret else '',remote_completion='unknown')))
def request(action,name='',seconds=60):
 boot='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_channel_v4 import worker;worker()'
 return _supervise(dict(action=action,name=name),seconds,boot)
if __name__=='__main__':print(json.dumps(request(*sys.argv[1:])))
