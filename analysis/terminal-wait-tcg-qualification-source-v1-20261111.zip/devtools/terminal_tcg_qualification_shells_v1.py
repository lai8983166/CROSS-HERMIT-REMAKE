"""Bounded WSMan enumeration, no shell creation and no mutation."""
import json,sys,xml.etree.ElementTree as E
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths

def worker():
 try:
  import winrm,xmltodict
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  p=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER'+chr(92)+'Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=10,read_timeout_sec=20).protocol
  req={'env:Envelope':p.build_wsman_header(resource_uri='http://schemas.microsoft.com/wbem/wsman/1/windows/shell',action='http://schemas.xmlsoap.org/ws/2004/09/enumeration/Enumerate')}
  req['env:Envelope']['env:Body']={'n:Enumerate':{'w:OptimizeEnumeration':None,'w:MaxElements':'64'}}
  raw=p.send_message(xmltodict.unparse(req));root=E.fromstring(raw)
  fields={'ShellId','Owner','State','ProcessId','IdleTimeOut','RunTime','EnumerationContext','ResourceUri'}
  rows=[dict(field=x.tag.split('}')[-1],value=x.text)for x in root.iter()if x.tag.split('}')[-1]in fields]
  print(json.dumps(dict(ok=True,rows=rows,response_bytes=len(raw),remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,message=str(e)[:1500],remote_completion='unknown')))
if __name__=='__main__':
 bootstrap='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_shells_v1 import worker;worker()'
 print(json.dumps(_supervise({},35,bootstrap)))
