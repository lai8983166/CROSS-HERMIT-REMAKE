"""Bounded qualification over a single owned shell; guest input only in guarded probe."""
import base64,hashlib,json,subprocess,sys,time
from pathlib import Path
from devtools.terminal_tcg_qualification_channel_v2 import request
from devtools.isolated_vm_preflight import observe_host
from devtools.terminal_tcg_qualification_verify_v1 import verify
CASE=Path(__file__).resolve().parents[1]/'.venv-audit/native-worker/tcg-wait-native-v12'
def save(name,r):
 with(CASE/name).open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
def call(action,name='',deadline=None):
 remaining=60 if deadline is None else min(60,deadline-time.monotonic())
 if remaining<1:raise TimeoutError('operation budget')
 r=request(action,name,remaining);save('channel-'+action+'-'+name+'-'+str(time.time_ns())+'.json',r)
 if action=='receive' and r.get('response',{}).get('error_type')=='WinRMOperationTimeoutError':return dict(pending=True)
 if r.get('remote_completion')!='observed' or not r.get('response',{}).get('ok'):raise RuntimeError('channel '+action+' '+name+': '+str(r.get('response',{}).get('error_type',r.get('errors'))))
 return r['response']['value']
def command(name,seconds):
 start=time.monotonic();deadline=start+seconds;call('run',name,deadline);call('send',name,deadline)
 out=[];err=[]
 while time.monotonic()-start<seconds:
  r=call('receive',name,deadline)
  if r.get('pending'):continue
  for key,parts in (('stdout',out),('stderr',err)):
   raw=base64.b64decode(r[key+'_base64'],validate=True)
   if len(raw)!=r[key+'_bytes']or hashlib.sha256(raw).hexdigest()!=r[key+'_sha256']:raise ValueError('stream identity')
   parts.append(raw)
  if r['done']:
   call('cleanup',name,deadline)
   if r['status_code']:raise RuntimeError('guest '+name+' exit '+str(r['status_code'])+': '+b''.join(err).decode('utf8',errors='replace')[:1500])
   return b''.join(out).decode('utf-8-sig')
 raise TimeoutError(name+' budget')
def main():
 report=dict(accepted=False,errors=[],game_executed=False)
 try:
  opened=json.loads((CASE/'open-ready-response.json').read_bytes())
  if not opened.get('response',{}).get('ok'):raise RuntimeError('open not confirmed')
  ready=json.loads(command('prepare',180));save('prepared.json',ready)
  if not ready['prepared'] or not ready['logon_credential_cleared']:raise ValueError('preparation')
  ch=json.loads((CASE/'challenge.json').read_bytes());boot=ready['boot_utc']
  cmd='[pscustomobject]@{uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID}|ConvertTo-Json -Compress'
  host=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command',cmd],creationflags=subprocess.CREATE_NO_WINDOW,timeout=20))
  report.update(schema='terminal-tcg-qualification-v1',nonce=ch['nonce'],source_sha256=ch['source_sha256'],guest_executable=ch['guest_executable'],host=host,expected_boot_utc=boot)
  def execute():
   started=time.monotonic()
   try:
    command('start',35)
    raw=base64.b64decode(command('result',max(1,145-(time.monotonic()-started))).strip(),validate=True)
    with(CASE/'probe.json').open('xb')as f:f.write(raw)
    report['guest']=json.loads(raw)
   except Exception as e:
    report['errors'].append('observation callback: '+str(e))
    # A dispatched task may still run. Preserve passive coverage through its
    # 120-second cap even if start/receive completion is unknown.
    while time.monotonic()-started<165:time.sleep(.2)
  report['host_observation']=observe_host(ch['nonce'],execute,seconds=180)
  if 'guest'in report:
   report['verification']=verify(report,expected_source_sha256=ch['source_sha256'],expected_executable_sha256=ch['guest_executable']['sha256'],expected_boot_utc=boot,expected_nonce=ch['nonce'])

 except Exception as e:report['errors'].append(type(e).__name__+': '+str(e))
 finally:
  if 'guest'in report:
   try:report['task_cleanup']=json.loads(command('cleanup',80))
   except Exception as e:report['errors'].append('task cleanup: '+str(e))
  try:report['shell_cleanup']=call('close')
  except Exception as e:report['errors'].append('close: '+str(e))
  save('qualification.json',report)
 print(json.dumps(dict(verification=report.get('verification'),errors=report['errors'])))
if __name__=='__main__':main()
