"""Frozen authenticated control with WINRS_NOPROFILE for the command shell only."""
import hashlib,json,sys
from pathlib import Path
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths

def worker():
 import winrm.protocol
 original=winrm.protocol.Protocol.open_shell
 def open_shell(self,*args,**kwargs):
  kwargs['noprofile']=True
  return original(self,*args,**kwargs)
 winrm.protocol.Protocol.open_shell=open_shell
 from devtools.terminal_tcg_wait_control_v6 import _worker
 _worker()
def request(case,name):
 raw=(case/name).read_bytes();bootstrap='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_request_v1 import worker;worker()'
 return _supervise(dict(case=case.name,name=name,mode='run',sha256=hashlib.sha256(raw).hexdigest()),55,bootstrap)
if __name__=='__main__':print(json.dumps(request(Path(sys.argv[1]),sys.argv[2])))
