"""One bounded authenticated read-only inventory of the dedicated QEMU guest."""
import json,subprocess,sys,time
from pathlib import Path
from devtools.terminal_tcg_wait_control_v6 import request
from devtools.terminal_cr2_receipt_poll import poll
from devtools.isolated_vm_bounded_query_v3 import completed
ROOT=Path(__file__).resolve().parents[1]
CASE=ROOT/'.venv-audit/native-worker/tcg-wait-native-v10'
def save(n,v):
 with (CASE/n).open('x',encoding='utf8')as f:json.dump(v,f,indent=2)
def read(i):
 p=subprocess.run([sys.executable,'-B','-m','devtools.terminal_tcg_qualification_read_v1','prepare-receipt.json'],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
 r=json.loads(p.stdout);save('inventory-durable-'+str(i)+'.json',r);return r
def main():
 start=time.monotonic()
 while not(CASE/'vm-ready.json').exists():
  if(CASE/'report.json').exists()or time.monotonic()-start>210:raise TimeoutError('boot budget')
  time.sleep(.5)
 r=request(CASE,'prepare.ps1','run');save('inventory-response.json',r)
 if not completed(r):r,_=poll(read,lambda v:v.get('prepared')is True,150)
 if not completed(r)or r['response']['value'].get('prepared')is not True:raise ValueError('inventory unconfirmed')
 save('boot-auth.json',r);print(json.dumps(r['response']['value']))
if __name__=='__main__':main()
