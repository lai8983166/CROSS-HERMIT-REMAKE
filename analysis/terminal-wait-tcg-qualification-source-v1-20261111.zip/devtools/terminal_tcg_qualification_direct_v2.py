"""Bounded small direct scripts on the second, explicitly owned shell."""
import base64,json,sys,time
from pathlib import Path
from devtools.terminal_tcg_qualification_channel_v4 import request
from devtools.terminal_tcg_control_verify import completed
CASE=Path(__file__).resolve().parents[1]/'.venv-audit/native-worker/tcg-wait-native-v12'
def call(action,name,deadline):
 remaining=min(60,deadline-time.monotonic())
 if remaining<1:raise TimeoutError('direct deadline')
 r=request(action,name,remaining)
 with(CASE/('direct-response-'+action+'-'+name+'-'+str(time.time_ns())+'.json')).open('x')as f:json.dump(r,f,indent=2)
 clean=not r.get('errors')and not r.get('timed_out')and r.get('host_job_active_after')==0 and r.get('host_exit_code')==0
 if clean and action=='receive'and r.get('response',{}).get('error_type')=='WinRMOperationTimeoutError':return dict(pending=True)
 if not completed(r):raise RuntimeError(action+': '+str(r.get('response')))
 return r['response']['value']
def command(name,seconds=100):
 deadline=time.monotonic()+seconds
 if not completed(json.loads((CASE/'direct-open-response.json').read_bytes())):raise ValueError('direct shell ownership')
 call('run',name,deadline);out=[];err=[]
 while time.monotonic()<deadline:
  r=call('receive',name,deadline)
  if r.get('pending'):continue
  out.append(base64.b64decode(r['stdout_base64'],validate=True));err.append(base64.b64decode(r['stderr_base64'],validate=True))
  if r['done']:
   call('cleanup',name,deadline)
   raw=b''.join(out)
   with(CASE/(name+'-stdout.bin')).open('xb')as f:f.write(raw)
   with(CASE/(name+'-stderr.bin')).open('xb')as f:f.write(b''.join(err))
   if r['status_code']:raise RuntimeError('guest exit '+str(r['status_code']))
   return raw.decode('utf-8-sig')
 raise TimeoutError('direct command')
if __name__=='__main__':print(command(sys.argv[1]))
