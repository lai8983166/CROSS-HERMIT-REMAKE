"""Fixed read-only cmd queries in the current isolated VM; never guest input."""
import json,sys
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths

def worker():
 req=json.loads(sys.stdin.readline())
 try:
  case=WORKER/req['case']
  if case.name not in ('tcg-wait-native-v10','tcg-wait-native-v11')or not(case/'vm-ready.json').exists()or(case/'report.json').exists()or(case/'vm-stop').exists():raise ValueError('current case')
  commands={'boot':['/d','/c','wmic','os','get','LastBootUpTime','/value'],'video':['/d','/c','wmic','path','Win32_VideoController','get','Name,DriverVersion,PNPDeviceID,Status','/value'],'probe':['/d','/c','type','C:/ChaomofaWorker/'+case.name+'/probe.json'],'machine':['/d','/c','wmic','computersystem','get','Name,Manufacturer,NumberOfLogicalProcessors,TotalPhysicalMemory','/value'],'uuid':['/d','/c','wmic','csproduct','get','UUID','/value'],'sessions':['/d','/c','quser'],'processes':['/d','/c','tasklist','/fi','imagename eq powershell.exe','/fo','csv'],'receipt':['/d','/c','type','C:/ChaomofaWorker/'+case.name+'/prepare-receipt.json']}
  args=commands[req['action']]
  import winrm
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  s=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER\Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=10,read_timeout_sec=20)
  original=s.protocol.open_shell
  s.protocol.open_shell=lambda *args,**kwargs:original(*args,**dict(kwargs,noprofile=True))
  value=s.run_cmd('cmd.exe',args)
  print(json.dumps(dict(ok=True,status_code=value.status_code,stdout=value.std_out.decode('utf-8',errors='replace'),stderr=value.std_err.decode('utf-8',errors='replace'),remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,remote_completion='unknown')))
if __name__=='__main__':
 bootstrap='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_fast_v5 import worker;worker()'
 print(json.dumps(_supervise(dict(case=sys.argv[1],action=sys.argv[2]),35,bootstrap)))
