"""Single owned WINRS_NOPROFILE shell, separately bounded requests and durable stages."""
import base64,hashlib,json,sys,time
from devtools.isolated_windows_vm import WORKER
from devtools.isolated_vm_bounded_query_v3 import _supervise,runtime_paths
CASE='tcg-wait-native-v12'
def worker():
 req=json.loads(sys.stdin.readline());case=WORKER/CASE;secret=''
 try:
  if not(case/'vm-ready.json').exists()or(case/'report.json').exists()or(case/'vm-stop').exists():raise ValueError('inactive case')
  action=req['action'];name=req.get('name','')
  if action not in ('open','run','send','receive','cleanup','close'):raise ValueError('action')
  if action not in ('open','close')and name not in ('prepare','start','result','cleanup'):raise ValueError('fixed command')
  import winrm
  secret=json.loads((WORKER/'credentials.private.json').read_bytes())['password']
  p=winrm.Session('http://127.0.0.1:15985/wsman',auth=('CHAOMOFA-WORKER'+chr(92)+'Administrator',secret),transport='ntlm',message_encryption='always',operation_timeout_sec=40,read_timeout_sec=50).protocol
  if action=='open':
   with(case/'shell-open-issued.json').open('x')as f:json.dump(dict(case=CASE,time=time.time()),f)
   shell=p.open_shell(noprofile=True)
   with(case/'shell-owned.json').open('x')as f:json.dump(dict(shell=shell,case=CASE,vm_ready_sha256=hashlib.sha256((case/'vm-ready.json').read_bytes()).hexdigest()),f)
   result=dict(shell=shell)
  else:
   owner=json.loads((case/'shell-owned.json').read_bytes());shell=owner['shell']
   if owner['vm_ready_sha256']!=hashlib.sha256((case/'vm-ready.json').read_bytes()).hexdigest():raise ValueError('boot ownership')
   if action=='close':p.close_shell(shell);result=dict(closed=True)
   elif action=='run':
    raw=(case/(name+'.ps1')).read_bytes()
    with(case/(name+'-issued.json')).open('x')as f:json.dump(dict(script_sha256=hashlib.sha256(raw).hexdigest()),f)
    boot="DOLLARs=[Console]::In.ReadToEnd();Invoke-Expression ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(DOLLARs)))".replace('DOLLAR',chr(36))
    command=p.run_command(shell,'powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(boot.encode('utf-16-le')).decode()])
    with(case/(name+'-owned.json')).open('x')as f:json.dump(dict(command=command,shell=shell),f)
    result=dict(command=command)
   else:
    owned=json.loads((case/(name+'-owned.json')).read_bytes());command=owned['command']
    if owned['shell']!=shell:raise ValueError('command ownership')
    if action=='send':
     raw=(case/(name+'.ps1')).read_bytes()
     if hashlib.sha256(raw).hexdigest()!=json.loads((case/(name+'-issued.json')).read_bytes())['script_sha256']:raise ValueError('script mutation')
     with(case/(name+'-send-issued.json')).open('x')as f:json.dump(dict(command=command),f)
     p.send_command_input(shell,command,base64.b64encode(raw),end=True);result=dict(sent=True)
    elif action=='receive':
     out,err,code,done=p.get_command_output_raw(shell,command)
     result=dict(stdout=out.decode('utf-8-sig',errors='replace'),stderr=err.decode('utf-8-sig',errors='replace'),status_code=code,done=done)
     with(case/(name+'-chunk-'+str(time.time_ns())+'.json')).open('x')as f:json.dump(result,f)
    else:p.cleanup_command(shell,command);result=dict(cleaned=True)
  print(json.dumps(dict(ok=True,value=result,remote_completion='observed')))
 except Exception as e:print(json.dumps(dict(ok=False,error_type=type(e).__name__,diagnostic=str(e).replace(secret,'[redacted]')[:1000]if secret else '',remote_completion='unknown')))
def request(action,name=''):
 boot='import sys;sys.path[:0]='+repr(runtime_paths())+';from devtools.terminal_tcg_qualification_channel_v1 import worker;worker()'
 return _supervise(dict(action=action,name=name),60,boot)
if __name__=='__main__':print(json.dumps(request(*sys.argv[1:])))
