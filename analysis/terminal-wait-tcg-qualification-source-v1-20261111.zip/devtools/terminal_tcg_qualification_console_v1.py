"""Confirm actual console, clear one-logon settings, then read boot/display identity."""
import json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];CASE=ROOT/'.venv-audit/native-worker/tcg-wait-native-v11'
def call(module,action,name,limit=70):
 p=subprocess.run([sys.executable,'-B','-m',module,CASE.name,action],capture_output=True,timeout=limit,creationflags=subprocess.CREATE_NO_WINDOW)
 r=json.loads(p.stdout)
 with (CASE/name).open('x',encoding='utf8')as f:json.dump(r,f,indent=2)
 if r.get('remote_completion')!='observed' or not r.get('response',{}).get('ok'):raise ValueError(name+' unconfirmed')
 return r['response']
def main():
 start=time.monotonic()
 while not(CASE/'vm-ready.json').exists():
  if(CASE/'report.json').exists()or time.monotonic()-start>210:raise TimeoutError('boot')
  time.sleep(.5)
 status=call('devtools.terminal_tcg_qualification_logon_v3','status','console-status-response.json')['value']
 if len(status['desktop_sessions'])!=1 or status['desktop_sessions'][0]<=0:raise ValueError('actual logged-in console')
 cleared=call('devtools.terminal_tcg_qualification_logon_v3','clear','console-clear-response.json')['value']
 if cleared['enabled']!='0' or cleared['password_configured']or cleared['count']is not None:raise ValueError('transient logon not cleared')
 for action in ('boot','video'):
  r=call('devtools.terminal_tcg_qualification_fast_v4',action,action+'-response.json',45)
  if r['status_code']:raise ValueError(action+' failed')
 print(json.dumps(dict(console_confirmed=True,logon_cleared=True)))
if __name__=='__main__':main()
