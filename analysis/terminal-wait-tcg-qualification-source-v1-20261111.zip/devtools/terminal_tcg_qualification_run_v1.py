"""Bounded host pass-through observation around the actual guest-only challenge."""
import datetime,json,re,subprocess,sys,time
from pathlib import Path
from devtools.isolated_vm_preflight import observe_host
from devtools.terminal_tcg_qualification_verify_v1 import verify
ROOT=Path(__file__).resolve().parents[1];CASE=ROOT/'.venv-audit/native-worker/tcg-wait-native-v11'
def save(name,value):
 with(CASE/name).open('x',encoding='utf8')as f:json.dump(value,f,indent=2)
def call(action,name):
 p=subprocess.run([sys.executable,'-B','-m','devtools.terminal_tcg_qualification_control_v1',action],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
 r=json.loads(p.stdout);save(name,r);return r

def main():
 ch=json.loads((CASE/'challenge.json').read_bytes());b=json.loads((CASE/'boot-response.json').read_bytes())
 raw=b['response']['stdout'];match=re.search(r'LastBootUpTime=(\d{14})\.(\d{6})([+-]\d{3})',raw)
 if b['remote_completion']!='observed'or not match:raise ValueError('independent boot identity')
 dt=datetime.datetime.strptime(match[1]+match[2],'%Y%m%d%H%M%S%f').replace(tzinfo=datetime.timezone(datetime.timedelta(minutes=int(match[3])))).astimezone(datetime.timezone.utc)
 boot=dt.strftime('%Y-%m-%dT%H:%M:%S.')+format(dt.microsecond,'06d')+'0Z'
 cmd="[pscustomobject]@{uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID}|ConvertTo-Json -Compress"
 host=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command',cmd],creationflags=subprocess.CREATE_NO_WINDOW,timeout=20))
 r=dict(schema='terminal-tcg-qualification-v1',accepted=False,nonce=ch['nonce'],source_sha256=ch['source_sha256'],guest_executable=ch['guest_executable'],host=host,expected_boot_utc=boot,errors=[])
 def execute():
  started=time.monotonic();result=call('start','start-response.json')
  # Unknown start completion is never resent. Only the exact nonce report can prove effect.
  for i in range(12):
   if time.monotonic()-started>120:raise TimeoutError('guest report deadline')
   value=call('read','probe-read-'+str(i)+'.json')
   if value.get('remote_completion')=='observed' and value.get('response',{}).get('ok') and value['response']['status_code']==0:
    r['guest']=json.loads(value['response']['stdout']);return
   time.sleep(1)
  raise TimeoutError('guest report attempts')
 r['host_observation']=observe_host(ch['nonce'],execute,seconds=170)
 try:r['verification']=verify(r,expected_source_sha256=ch['source_sha256'],expected_executable_sha256=ch['guest_executable']['sha256'],expected_boot_utc=boot,expected_nonce=ch['nonce'])
 except Exception as e:r['errors'].append(type(e).__name__+': '+str(e))
 save('qualification.json',r)
 if 'guest'in r:
  info=call('info','task-info-response.json')
  if info.get('remote_completion')=='observed' and info.get('response',{}).get('ok') and info['response']['status_code']==0:
   data=json.loads(info['response']['stdout'])
   if data['state']!=4 and data['last_result']in(0,1):call('remove','task-remove-response.json')
 print(json.dumps(dict(verification=r.get('verification'),errors=r['errors'],guest_error=r.get('guest',{}).get('error'))))
if __name__=='__main__':main()
