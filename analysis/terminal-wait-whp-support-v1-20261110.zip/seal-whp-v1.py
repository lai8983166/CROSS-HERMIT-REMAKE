import hashlib,json,subprocess,zipfile
from datetime import datetime,timezone
from pathlib import Path
from devtools.isolated_windows_vm import WORKER as W,VMX,vmrun,identity
from devtools.terminal_whp_return_verify import authenticate

R=W.parents[1];base='807f57bb84966e72a8f9ea074949c1a55ac70b85'
out=R/'analysis/terminal-wait-whp-closeout-v1-20261110.json'
if out.exists():raise ValueError('fresh seal')
proofs=[]
for v in (1,2):
 p=W/('whp-return-v%d-20261110'%v)/'report.json'
 sha=identity(p)['sha256'];result=authenticate(p,sha)
 q=R/('analysis/terminal-wait-whp-proof-v%d-20261110.json'%v)
 with q.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
 proofs.append(identity(q))
preservation=W/'whp-preservation-v1-20261110.json'
code=(W/'check-kd-preservation-v1.py').read_text().replace("out=root/'.venv-audit/native-worker/kd-worker/preservation-v1.json'","out=root/'.venv-audit/native-worker/whp-preservation-v1-20261110.json'")
exec(compile(code,'preservation-frozen-logic-with-new-output','exec'),{})
running=vmrun(['list'],timeout=10);snapshots=vmrun(['listSnapshots',str(VMX)],timeout=10)
if 'Total running VMs: 0' not in running or 'Total snapshots: 0' not in snapshots:raise ValueError('environment not idle')
vmem=list(W.glob('*.vmem'));disk=sum(p.stat().st_size for p in W.glob('*.vmdk'))
if vmem or disk!=16761683968:raise ValueError('unexpected VM backing state')
review=R/'analysis/terminal-wait-whp-review-v1-20261110.json'
if identity(review)['sha256']!='d40aebc5703fcff4421920341e1282e311be336ed8c1fe2b91a73da838a344d0':raise ValueError('review changed')
rr=json.loads(review.read_text());reports=[]
for v in rr['versions']:
 for row in [v['source'],v['runner'],v['supervision'],*v['files']]:
  p=R/row['path'];i=identity(p)
  if i['bytes']!=row['bytes'] or i['sha256']!=row['sha256']:raise ValueError('independent source identity mismatch')
for v in (1,2):
 p=W/('whp-return-v%d-20261110'%v)/'report.json';r=json.loads(p.read_bytes())
 s=json.loads((W/('whp-return-v%d-supervision-20261110.json'%v)).read_bytes())
 reports.append(dict(version=v,report=identity(p),native_seconds=r['elapsed_seconds'],supervision=s))
files=[p for v in (1,2)for p in sorted((W/('whp-return-v%d-20261110'%v)).iterdir())if p.is_file()]
files+=sorted(p for p in W.glob('*whp*')if p.is_file())
files=sorted(set(files));rows=[dict(member=p.relative_to(W).as_posix(),**identity(p))for p in files]
capsule=R/'analysis/terminal-wait-whp-support-v1-20261110.zip'
with zipfile.ZipFile(capsule,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for row in rows:z.write(row['path'],row['member'])
with zipfile.ZipFile(capsule)as z:
 if z.testzip()is not None:raise ValueError('corrupt capsule')
 for row in rows:
  b=z.read(row['member'])
  if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('capsule identity')
result=dict(schema=1,created_utc=datetime.now(timezone.utc).isoformat(),baseline=base,accepted=False,fullstate=False,fullABI=False,
 change='connect-terminal-wait-and-battle-exit',tasks_completed=2,tasks_total=8,
 functional_result=dict(owned_two_vp_natural_return_and_one_consumer=True,raw_FP_XMM_guest_and_monitor_agree=True,
 nonzero_pending_exception_FOP_FDP=True,complete_flags_transparency=False,windows_wow64_qualified=False,
 original_game_starts=0,qualified_game_wait_returns=0,first_game_consumer=False,three_game_handshakes=False,resource_PTD_release=False),
 native=reports,validation=dict(offline_proofs=proofs,unittest_normal=7,unittest_optimized=7,
 strict_openspec_passed=True,preservation=json.loads(preservation.read_bytes()),independent_review=identity(review)),
 environment=dict(all_new_data_F=True,windows_vm_running=False,windows_boots=0,VMX_current=identity(VMX),running=running.strip(),snapshots=snapshots.strip(),
 vmem_files=[],VMDK_total_bytes=disk,VMDK_growth_bytes=0,new_download_bytes=0,new_guest_files=0,host_input_actions=0,host_BCD_changes=0,
 synthetic_each=dict(vp_count=2,reserved_address_bytes=2**32,committed_mapped_bytes=65536,OS_boots=0,devices=0,disks=0)),
 next_gate=['Prove original RF provenance and resumed debug semantics, or use a stop mechanism preserving the missing original flag; never silently clear RF.',
 'Qualify 64-bit/WOW64 mode and complete state before considering Windows/game migration; WHP cannot attach the existing VMware partition.',
 'Then capture real wait return to 453CB5/4967B0 and three original handshakes, before resource/PTD and two fresh full native replays.'],
 evidence=dict(source_files=rows,support_capsule=identity(capsule),source_logical_bytes=sum(x['bytes']for x in rows),
 same_disk_recovery_copy_not_independent_backup=True,cleanup='Both owned WHP partitions/VPs/mappings/reservations explicitly released; host Jobs report zero active processes. Existing Windows VM never booted. Tiny raw evidence plus one compressed recovery copy retained; no historical evidence/assets or existing QEMU files removed. Final volume audit includes code, raw originals, recovery copy, audit files and new Git object bytes.'))
with out.open('x',encoding='utf8')as f:json.dump(result,f,indent=2)
print(json.dumps(dict(closeout=identity(out),capsule=identity(capsule),raw_bytes=result['evidence']['source_logical_bytes'],vm_running=False)))
