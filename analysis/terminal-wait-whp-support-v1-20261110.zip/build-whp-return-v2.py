from pathlib import Path
p=Path('devtools/terminal_whp_return_probe.py');s=p.read_text().replace('whp-return-v1-20261110','whp-return-v2-20261110')
old="""    start=bytes.fromhex('b80700000031c90fa2')
    for mod,offset in((0x87,0x240),(0x9f,0x244),(0x8f,0x248),(0x97,0x24c)):
        start+=bytes([0x89,mod])+u32(offset)
"""
new="""    start=b''
    for leaf,offset_base in((7,0x240),(1,0x250)):
        start+=b'\\xb8'+u32(leaf)+bytes.fromhex('31c90fa2')
        for mod,delta in((0x87,0),(0x9f,4),(0x8f,8),(0x97,12)):
            start+=bytes([0x89,mod])+u32(offset_base+delta)
"""
if old not in s:raise ValueError('exact CPUID block')
s=s.replace(old,new)
s=s.replace("    helper+=bytes.fromhex('d9b3')+u32(0x300) # fnstenv; FCW already all-masked", "    helper+=bytes.fromhex('d9ab')+u32(0x284) # fldcw: unmask only divide by zero\n    last_fp=0x2000+len(helper);helper+=bytes.fromhex('dcb3')+u32(8) # pending unmasked FDIV by zero; no FWAIT/FNSTENV")
s=s.replace("        memory[data+0x280:data+0x284]=u32(0x3f80)", "        memory[data+0x280:data+0x284]=u32(0x3f80)\n        memory[data+0x284:data+0x286]=bytes.fromhex('7b03')")
s=s.replace("        row['stable_registers_and_memory']=True;progress();return row", "        row['xsave_reread']=[xsave(vp,name+'-vp%d-reread.xsave'%vp)for vp in(0,1)]\n        need(all(a['file']['sha256']==b['file']['sha256']for a,b in zip(row['xsave'],row['xsave_reread'])),'unchanged all-stopped raw XSAVE reread')\n        row['stable_registers_memory_xsave']=True;progress();return row")
s=s.replace("        r['natural_return_execute_gate_passed']=True", "        for vp in(0,1):\n            for n in list(range(0x1000,0x1008))+list(range(0x1010,0x101a)):\n                need(returned['registers'][vp][str(n)]==consumed['registers'][vp][str(n)],'FP/XMM unchanged through integer-only consumer')\n        r['full_rflags_transparency']=False\n        r['rf_saved_as_one_at_execute_exit']=True\n        r['natural_return_execute_gate_passed']=True")
q=p.with_name('terminal_whp_return_probe_v2.py')
if q.exists():raise ValueError('fresh v2')
q.write_text(s)
p=Path('devtools/terminal_whp_return_runner.py');s=p.read_text().replace('whp-return-v1','whp-return-v2').replace('from devtools.terminal_whp_return_probe import run','from devtools.terminal_whp_return_probe_v2 import run')
q=p.with_name('terminal_whp_return_runner_v2.py')
if q.exists():raise ValueError('fresh v2 runner')
q.write_text(s)
